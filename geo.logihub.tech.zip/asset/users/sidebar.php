<?php
// Espera $brand=['name','logo','primary'], $active (string), $user=['name','avatar'] opcional
if (!function_exists('esc')) { function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); } }

$brand = $brand ?? ['name'=>'ClienteHub','logo'=>'/asset/logo.png','primary'=>'#2563eb'];
$active = $active ?? '';
$user = $user ?? ['name'=>'Usuario','avatar'=>'https://placehold.co/40x40/7c3aed/ffffff?text=U'];

$items = [
  ['key'=>'panel',   'text'=>'Dashboard',    'href'=>'/users/panel/index.php',  'icon'=>function(){ ?>
    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>
  <?php }],
  ['key'=>'proyectos','text'=>'Mis Proyectos','href'=>'/users/proyectos/',     'icon'=>function(){ ?>
    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/></svg>
  <?php }],
  ['key'=>'facturas','text'=>'Facturación',  'href'=>'/users/facturas/',       'icon'=>function(){ ?>
    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><path d="M14 2v6h6"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/></svg>
  <?php }],
  ['key'=>'apikeys', 'text'=>'API Keys',     'href'=>'/users/api/index.php',   'icon'=>function(){ ?>
    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M2 18v3c0 .6.4 1 1 1h4v-3h3v-3h2l1.4-1.4a6.5 6.5 0 1 0-4-4Z"/><circle cx="16.5" cy="7.5" r=".5"/></svg>
  <?php }],
  ['key'=>'planes',  'text'=>'Mi Plan',      'href'=>'/users/planes/index.php','icon'=>function(){ ?>
    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M6 3h12l4 6-10 13L2 9Z"/><path d="M12 22V9"/><path d="m3.29 8.71 8.71 8.71"/><path d="m20.71 8.71-8.71 8.71"/></svg>
  <?php }],
  ['key'=>'soporte', 'text'=>'Soporte',      'href'=>'/users/soporte/',        'icon'=>function(){ ?>
    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h10"/><path d="M16 5h2"/><path d="M19 8h-2"/></svg>
  <?php }],
  ['key'=>'config',  'text'=>'Configuración','href'=>'/users/settings/',       'icon'=>function(){ ?>
    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 0 2.23l-.15.08a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l-.22-.38a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1 0-2.23l.15-.08a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
  <?php }],
];
?>
<style>
  /* ocultar scroll en sidebar */
  .sidebar-scroll::-webkit-scrollbar{display:none}
  .sidebar-scroll{-ms-overflow-style:none;scrollbar-width:none}
</style>

<aside id="sidebar"
  class="bg-gray-900 text-gray-100 w-64 space-y-6 pt-6 px-4 fixed md:sticky inset-y-0 left-0 transform -translate-x-full md:translate-x-0 md:top-0 md:h-screen z-30 flex flex-col justify-between transition-all duration-300 ease-in-out">

  <!-- Top -->
  <div>
    <!-- Brand -->
    <div class="flex items-center justify-between px-2 mb-6">
      <a href="/users/panel/index.php" class="flex items-center space-x-2">
        <div class="p-2 rounded-lg" style="background: <?=esc($brand['primary'])?>">
          <svg class="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>
        </div>
        <span id="logo-text" class="text-lg font-bold"><?=esc($brand['name'])?></span>
      </a>
      <!-- close mobile -->
      <button id="close-sidebar-mobile" class="md:hidden text-gray-400 hover:text-white p-2 rounded">
        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
      </button>
    </div>

    <!-- Nav -->
    <nav class="sidebar-scroll overflow-y-auto pr-1">
      <?php foreach ($items as $it): $isActive = ($active === $it['key']); ?>
        <a href="<?=esc($it['href'])?>"
           class="flex items-center py-2.5 px-4 my-2 rounded-lg transition
                  <?= $isActive
                      ? 'bg-gradient-to-r from-blue-500 to-blue-600 shadow-lg'
                      : 'hover:bg-gray-800' ?>">
          <?php $it['icon'](); ?>
          <span class="ml-3 nav-text"><?=esc($it['text'])?></span>
        </a>
      <?php endforeach; ?>

      <!-- Salir -->
      <a href="/users/auth/logout.php" class="flex items-center py-2.5 px-4 mt-6 rounded-lg hover:bg-gray-800">
        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
        <span class="ml-3 nav-text">Salir</span>
      </a>
    </nav>
  </div>

  <!-- Bottom -->
  <div class="border-t border-gray-800">
    <!-- Collapse (desktop) -->
    <button id="toggle-sidebar" class="hidden md:flex items-center justify-center w-full py-3 px-4 text-gray-400 hover:bg-gray-800 hover:text-white">
      <svg id="toggle-icon-collapse" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m11 17-5-5 5-5"/><path d="m18 17-5-5 5-5"/></svg>
      <svg id="toggle-icon-expand" class="w-5 h-5 hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m6 17 5-5-5-5"/><path d="m13 17 5-5-5-5"/></svg>
      <span class="ml-3 nav-text">Colapsar</span>
    </button>

    <!-- User -->
    <div class="p-4 border-t border-gray-800">
      <div class="flex items-center space-x-3">
        <img src="<?=esc($user['avatar'])?>" alt="avatar" class="w-10 h-10 rounded-full">
        <div class="nav-text">
          <div class="font-semibold leading-tight"><?=esc($user['name'])?></div>
          <a href="/users/settings/" class="text-sm text-gray-400 hover:text-blue-400">Ver perfil</a>
        </div>
      </div>
    </div>
  </div>
</aside>

<script>
(function(){
  const sidebar = document.getElementById('sidebar');
  const logoText = document.getElementById('logo-text');
  const navTexts = document.querySelectorAll('.nav-text');
  const collapseIcon = document.getElementById('toggle-icon-collapse');
  const expandIcon = document.getElementById('toggle-icon-expand');
  const toggleSidebarBtn = document.getElementById('toggle-sidebar');
  const closeSidebarMobileBtn = document.getElementById('close-sidebar-mobile');

  // abrir desde botón externo (en header): #open-sidebar-mobile
  const openSidebarMobileBtn = document.getElementById('open-sidebar-mobile');

  function toggleDesktop(){
    sidebar.classList.toggle('w-64');
    sidebar.classList.toggle('w-20');
    logoText.classList.toggle('opacity-0');
    logoText.classList.toggle('w-0');
    navTexts.forEach(t=>{ t.classList.toggle('hidden'); t.classList.toggle('opacity-0'); });
    collapseIcon.classList.toggle('hidden');
    expandIcon.classList.toggle('hidden');
  }
  if (toggleSidebarBtn) toggleSidebarBtn.addEventListener('click', toggleDesktop);

  // móvil
  function openMobile(){ sidebar.classList.remove('-translate-x-full'); }
  function closeMobile(){ sidebar.classList.add('-translate-x-full'); }
  if (openSidebarMobileBtn) openSidebarMobileBtn.addEventListener('click', openMobile);
  if (closeSidebarMobileBtn) closeSidebarMobileBtn.addEventListener('click', closeMobile);

  // estado inicial
  function init(){
    if (window.innerWidth < 768) { sidebar.classList.add('-translate-x-full'); }
    else { sidebar.classList.remove('-translate-x-full'); sidebar.classList.add('w-64'); }
  }
  init(); window.addEventListener('resize', init);
})();
</script>
