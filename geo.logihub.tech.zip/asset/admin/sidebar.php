<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) session_start();
$rol = $_SESSION['user_rol'] ?? 'cliente';

require_once __DIR__ . '/../../config/db.php';

/* ------------------------- util: kv loader seguro ------------------------- */
function kvLoad(PDO $pdo, string $table, string $kcol, string $vcol, array $want): array {
  $in  = implode(',', array_fill(0, count($want), '?'));
  $sql = "SELECT {$kcol} AS k, {$vcol} AS v FROM {$table} WHERE {$kcol} IN ({$in})";
  $st = $pdo->prepare($sql);
  $st->execute($want);
  $out = [];
  foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
    if ($r['v'] !== null && $r['v'] !== '') $out[$r['k']] = (string)$r['v'];
  }
  return $out;
}

/* --------- lee marca/logo desde config_global o fallback app_settings ----- */
$cfg = [
  'brand_name'      => 'GeoLogiHub',
  'brand_logo_url'  => '/assets/logo.svg',
  'allow_zip_upload'=> '0',
];

try {
  // preferencia: tabla config_global con (key,value)
  $got = kvLoad($pdo, 'config_global', 'key', 'value', ['brand_name','brand_logo_url','allow_zip_upload']);
  $cfg = array_replace($cfg, $got);
} catch (Throwable $e) {
  // fallback: tabla app_settings con (k,v) -> mapeo a las claves esperadas
  try {
    $got = kvLoad($pdo, 'app_settings', 'k', 'v', ['site_name','site_logo_url','allow_zip_upload']);
    if (isset($got['site_name']))     $cfg['brand_name'] = $got['site_name'];
    if (isset($got['site_logo_url'])) $cfg['brand_logo_url'] = $got['site_logo_url'];
    if (isset($got['allow_zip_upload'])) $cfg['allow_zip_upload'] = $got['allow_zip_upload'];
  } catch (Throwable $e2) {
    // usa defaults
  }
}

$brandName = $cfg['brand_name'];
$logoUrl   = $cfg['brand_logo_url'];
$canUpload = ($cfg['allow_zip_upload'] === '1');

/* ----------------------- ruta actual sin querystring ---------------------- */
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

/* ----------------------------- iconos (hero) ------------------------------ */
$ICONS = [
  'home'      => 'M3 12l2-2m0 0 7-7 7 7M13 5v6m-9 7a2 2 0 002 2h4a2 2 0 002-2v-5h4v5a2 2 0 002 2h2a2 2 0 002-2V10',
  'userPlus'  => 'M12 4v4m0 0H8m4 0h4M8 14a4 4 0 108 0 4 4 0 10-8 0z',
  'users'     => 'M17 20h5v-2a4 4 0 00-3-3.87M9 7a4 4 0 110 8M7 20H3v-2a4 4 0 013-3.87',
  'upload'    => 'M12 4v8m0 0l-3-3m3 3l3-3M4 16h16',
  'plans'     => 'M9 17v-4a4 4 0 014-4h4',
  'zones'     => 'M9 12l2 2 4-4',
  'api'       => 'M5 13l4 4L19 7',
  'pay'       => 'M12 8v4l3 3M5 12a7 7 0 1114 0 7 7 0 01-14 0',
  'settings'  => 'M12 8v4l3 3M4 12a8 8 0 1016 0 8 8 0 00-16 0',
  'logout'    => 'M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1',
];

/* --------------------------- helper de item nav --------------------------- */
function isActive(string $href, string $path): bool {
  return str_starts_with($path, rtrim($href,'/'));
}
function item(string $href, string $label, string $iconPath, bool $active): string {
  $cls = $active ? 'bg-indigo-50 text-indigo-700' : 'text-gray-700';
  return <<<HTML
  <a href="{$href}" class="flex items-center px-3 py-2 rounded-lg hover:bg-indigo-50 font-medium {$cls}">
    <svg class="w-5 h-5 mr-3 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="{$iconPath}"></path>
    </svg>
    {$label}
  </a>
HTML;
}

/* ------------------------------ menú dinámico ----------------------------- */
$MENU = [
  // visible para todos
  ['href'=>'/admin/panel',       'label'=>'Dashboard',       'icon'=>$ICONS['home'],   'roles'=>['admin','cliente'], 'show'=>true],
  // solo admin
  ['href'=>'/admin/nuevo/usuario','label'=>'Nuevo Usuario',  'icon'=>$ICONS['userPlus'],'roles'=>['admin'],           'show'=>true],
  ['href'=>'/admin/users',       'label'=>'Usuarios',        'icon'=>$ICONS['users'],  'roles'=>['admin'],           'show'=>true],
  ['href'=>'/admin/subir',       'label'=>'Subir ZIP/CSV',   'icon'=>$ICONS['upload'], 'roles'=>['admin'],           'show'=>$canUpload],
  ['href'=>'/admin/planes',      'label'=>'Planes',          'icon'=>$ICONS['plans'],  'roles'=>['admin'],           'show'=>true],
  // mixtos
  ['href'=>'/admin/zonas',       'label'=>'Zonas',           'icon'=>$ICONS['zones'],  'roles'=>['admin','cliente'], 'show'=>true],
  ['href'=>'/admin/api',         'label'=>'API Tokens',      'icon'=>$ICONS['api'],    'roles'=>['admin','cliente'], 'show'=>true],
  ['href'=>'/admin/metodo',      'label'=>'Método de Pago',  'icon'=>$ICONS['pay'],    'roles'=>['admin','cliente'], 'show'=>true],
  // solo admin
  ['href'=>'/admin/settings',    'label'=>'Configuración',   'icon'=>$ICONS['settings'],'roles'=>['admin'],           'show'=>true],
];

?>
<aside class="w-64 min-h-screen bg-white border-r border-gray-200 flex flex-col shadow-lg">
  <div class="px-6 py-6">
    <a href="/admin/panel/index.php" class="flex items-center space-x-2">
      <img src="<?=htmlspecialchars($logoUrl)?>" alt="Logo" class="h-10 w-10" onerror="this.src='/assets/logo.svg'">
      <span class="text-2xl font-bold text-indigo-700"><?=htmlspecialchars($brandName)?></span>
    </a>
  </div>

  <nav class="flex-1 px-4 space-y-2 mt-4">
    <?php foreach ($MENU as $m):
      if (!$m['show']) continue;
      if (!in_array($rol, $m['roles'], true)) continue;
      echo item($m['href'], $m['label'], $m['icon'], isActive($m['href'], $path));
    endforeach; ?>

    <a href="/admin/auth/logout.php"
       class="flex items-center px-3 py-2 rounded-lg font-medium mt-4 hover:bg-red-100 text-red-700">
      <svg class="w-5 h-5 mr-3 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?= $ICONS['logout'] ?>"></path>
      </svg>
      Cerrar sesión
    </a>
  </nav>

  <div class="px-6 py-4 border-t text-xs text-gray-500">
    Conectado como: <b><?=htmlspecialchars($_SESSION['user_name'] ?? 'Invitado')?></b> (<?=htmlspecialchars($rol)?>)
  </div>
</aside>
