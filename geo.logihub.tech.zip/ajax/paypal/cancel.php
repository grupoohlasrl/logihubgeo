<?php
declare(strict_types=1);
header('Location: /users/planes/?cancel=1');
