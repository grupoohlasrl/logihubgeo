<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../lib/paypal.php';

$subId=(string)($_GET['subscription_id'] ?? $_GET['token'] ?? '');
if($subId===''){ header('Location: /users/planes/?e=missing'); exit; }

$pp=new PayPal();
try{
  $info=$pp->getSubscription($subId);

  $custom=(string)($info['custom_id']??'');
  parse_str(str_replace(['|',':'],['&','='],$custom),$kv);
  $uid=isset($kv['usr'])?(int)$kv['usr']:(int)($_SESSION['uid']??0);
  $plan_id=(int)($kv['plan']??0);

  $st=pdo()->prepare(
    "UPDATE payments
       SET status=?,
           amount_usd=COALESCE(amount_usd,0),
           details=JSON_SET(COALESCE(details,'{}'),'$.subscription_status',?)
     WHERE provider='paypal' AND provider_subscription_id=?"
  );
  $st->execute([strtolower((string)($info['status']??'approved')),(string)($info['status']??''),$subId]);

  if(($info['status']??'')==='ACTIVE' && $uid>0 && $plan_id>0){
    $next=$info['billing_info']['next_billing_time']??null;
    $end=$next?(new DateTimeImmutable($next))->format('Y-m-d H:i:s'):(new DateTimeImmutable('+1 month'))->format('Y-m-d H:i:s');

    $ex=pdo()->prepare("SELECT id FROM subscriptions WHERE usuario_id=? ORDER BY id DESC LIMIT 1");
    $ex->execute([$uid]); $cur=$ex->fetch();

    if($cur){
      $u=pdo()->prepare("UPDATE subscriptions SET plan_id=?, status='active', current_period_end=? WHERE id=?");
      $u->execute([$plan_id,$end,$cur['id']]);
    }else{
      $i=pdo()->prepare("INSERT INTO subscriptions(usuario_id,plan_id,status,current_period_end) VALUES(?,?,'active',?)");
      $i->execute([$uid,$plan_id,$end]);
    }
  }
  header('Location: /users/planes/?ok=1');
}catch(Throwable $e){
  header('Location: /users/planes/?e=pp');
}
