<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../../config/db.php';

function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
  return $db;
}
function tbl_exists(PDO $pdo, string $t): bool {
  $st=$pdo->prepare("SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=? AND TABLE_NAME=?");
  $st->execute([DB_NAME,$t]); return (bool)$st->fetchColumn();
}
function getCfg(string $k, ?string $def=null): ?string {
  $pdo=pdo();
  if (tbl_exists($pdo,'config_global')) {
    $st=$pdo->prepare("SELECT `value` FROM config_global WHERE `key`=?"); $st->execute([$k]);
    $v=$st->fetchColumn(); if ($v!==false) return (string)$v;
  }
  return $def;
}

$out = [
  'vendor_autoload' => is_file(__DIR__.'/../../vendor/autoload.php'),
  'lib_paypal'      => is_file(__DIR__.'/../../lib/paypal.php'),
  'curl'            => function_exists('curl_init'),
  'paypal_active'   => (int)(getCfg('paypal_active','0') ?? '0'),
  'env'             => getCfg('paypal_env','sandbox'),
  'client_id_set'   => (bool)(getCfg('paypal_client_id_sandbox','') ?: getCfg('paypal_client_id_live','')),
  'secret_set'      => (bool)(getCfg('paypal_client_secret_sandbox','') ?: getCfg('paypal_client_secret_live','')),
  'webhook_id_set'  => (bool)(getCfg('paypal_webhook_id_sandbox','') ?: getCfg('paypal_webhook_id_live','')),
  'plan_map_raw'    => getCfg('paypal_plan_map','{}'),
];
echo json_encode($out, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
