<?php
// /ajax/paypal/create.php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors','0'); error_reporting(E_ERROR|E_PARSE);
ob_start();

require_once __DIR__.'/../../config/db.php';
require_once __DIR__.'/../../lib/paypal.php';

function pdo2(): PDO { // nombre distinto para NO chocar
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  return $db=new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
}
function cfg(string $k,?string $def=null): ?string {
  $st=pdo2()->prepare("SELECT `value` FROM config_global WHERE `key`=?"); $st->execute([$k]); $v=$st->fetchColumn();
  return $v!==false ? (string)$v : $def;
}
function jout(array $a,int $code=200): void { if(ob_get_length()) ob_clean(); http_response_code($code); echo json_encode($a,JSON_UNESCAPED_SLASHES); exit; }
function jbody(): array { $j=json_decode(file_get_contents('php://input'),true); return is_array($j)?$j:[]; }

if(empty($_SESSION['uid'])) jout(['ok'=>false,'error'=>'AUTH'],401);

$in=jbody();
$plan_id=(int)($in['plan_id']??0);
$period=(($in['period']??'monthly')==='annual')?'annual':'monthly';
$csrf=(string)($in['csrf']??'');
if(!$plan_id || $csrf!==($_SESSION['csrf_api']??'')) jout(['ok'=>false,'error'=>'BAD_REQUEST'],400);

if((int)(cfg('paypal_active','0')??'0')!==1) jout(['ok'=>false,'error'=>'PAYPAL_OFF'],400);
$env = (cfg('paypal_env','sandbox')==='live')?'live':'sandbox';
$currency = strtoupper(cfg('paypal_currency','USD')??'USD');
$return_url = cfg('paypal_return_url','https://geo.logihub.tech/paypal/return.php')??'';
$cancel_url = cfg('paypal_cancel_url','https://geo.logihub.tech/paypal/cancel.php')??'';
$client_id  = cfg($env==='live'?'paypal_client_id_live':'paypal_client_id_sandbox','');
$secret     = cfg($env==='live'?'paypal_client_secret_live':'paypal_client_secret_sandbox','');
if(!$client_id || !$secret) jout(['ok'=>false,'error'=>'MISSING_CREDENTIALS'],400);

$st=pdo2()->prepare("SELECT id,code,name,price_usd FROM plans WHERE id=? AND active=1"); $st->execute([$plan_id]); $plan=$st->fetch();
if(!$plan) jout(['ok'=>false,'error'=>'BAD_PLAN'],400);

// resolver plan P-...
$map=json_decode(cfg('paypal_plan_map','{}')?:'{}',true)?:[];
$code=strtoupper((string)$plan['code']); $pp_plan='';
if(isset($map[$code]) && is_string($map[$code])) $pp_plan=$map[$code];
if(!$pp_plan && isset($map[$code][$period]) && is_string($map[$code][$period])) $pp_plan=$map[$code][$period];
if(!$pp_plan && isset($map[$code][$period]['plan_id'])) $pp_plan=(string)$map[$code][$period]['plan_id'];
if(!$pp_plan && isset($map[(string)$plan['id']][$period])) $pp_plan=is_array($map[(string)$plan['id']][$period])?($map[(string)$plan['id']][$period]['plan_id']??''):(string)$map[(string)$plan['id']][$period];
if(!$pp_plan) jout(['ok'=>false,'error'=>'MAP_MISSING'],400);

try{
  $pp = new PayPal($env,$client_id,$secret,$currency);
  $custom='usr:'.(int)$_SESSION['uid'].'|plan:'.$plan['id'].'|per:'.$period;
  $resp = $pp->createSubscription($pp_plan,$return_url,$cancel_url,$custom);

  $subId = (string)($resp['id']??''); $approve='';
  foreach(($resp['links']??[]) as $ln){ if(($ln['rel']??'')==='approve'){ $approve=(string)$ln['href']; break; } }
  if(!$subId || !$approve) throw new RuntimeException('Missing approve link');

  $ins=pdo2()->prepare("INSERT INTO payments (usuario_id, plan_id, provider, provider_subscription_id, status, currency, amount_usd, details, created_at)
                        VALUES (?,?,?,?, 'created', ?, 0, JSON_OBJECT('period', ?), NOW())");
  $ins->execute([(int)$_SESSION['uid'],$plan['id'],'paypal',$subId,$currency,$period]);

  jout(['ok'=>true,'approve_url'=>$approve,'subscription_id'=>$subId]);
}catch(Throwable $e){
  // registra y devuelve un mensaje depurable
  $msg = substr($e->getMessage(),0,500); // corta por seguridad
  @file_put_contents('/tmp/paypal_create.log', date('c')." PP_CREATE {$msg}\n", FILE_APPEND);
  jout(['ok'=>false,'error'=>'PP_CREATE','detail'=>$msg],500);
}
