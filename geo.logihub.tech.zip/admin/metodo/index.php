<?php
// /admin/metodo/index.php
declare(strict_types=1);
session_start();
if (!isset($_SESSION['user_id']) || (($_SESSION['user_rol'] ?? '') !== 'admin')) {
  header('Location: /admin/auth/login/index.php'); exit;
}
require_once __DIR__ . '/../../config/db.php';

/* ---------- DB ---------- */
try {
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $pdo = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]);
} catch (Throwable $e) { http_response_code(500); echo 'DB_ERROR'; exit; }

/* ---------- helpers ---------- */
function jout($a){ header('Content-Type: application/json; charset=utf-8'); echo json_encode($a); exit; }
function getCfg(PDO $pdo, string $k, ?string $def=null): ?string {
  $st=$pdo->prepare("SELECT value FROM config_global WHERE `key`=?"); $st->execute([$k]);
  $v=$st->fetchColumn(); return $v!==false ? (string)$v : $def;
}
function setCfg(PDO $pdo, string $k, ?string $v): void {
  $st=$pdo->prepare("INSERT INTO config_global(`key`,`value`) VALUES(?,?)
                     ON DUPLICATE KEY UPDATE `value`=VALUES(`value`), updated_at=CURRENT_TIMESTAMP()");
  $st->execute([$k, $v]);
}
function mask(?string $s): string {
  $s = (string)($s ?? '');
  if ($s==='') return '';
  $len = strlen($s);
  if ($len<=8) return str_repeat('•', max(0,$len-2)).substr($s,-2);
  return substr($s,0,4).str_repeat('•', $len-8).substr($s,-4);
}
function h($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function chip(string $label, bool $ok): string {
  return '<span class="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs '.($ok?'bg-emerald-50 text-emerald-700':'bg-rose-50 text-rose-700').'"><span class="w-2 h-2 rounded-full '.($ok?'bg-emerald-500':'bg-rose-500').'"></span>'.h($label).'</span>';
}

/* ---------- AJAX: status ---------- */
if (($_GET['action'] ?? '') === 'status') {
  $env = (string)(getCfg($pdo,'paypal_env','sandbox') ?? 'sandbox');
  $active = (int)((string)(getCfg($pdo,'paypal_active','0') ?? '0'));

  $cid = $env==='live' ? ((string)(getCfg($pdo,'paypal_client_id_live','') ?? '')) : ((string)(getCfg($pdo,'paypal_client_id_sandbox','') ?? ''));
  $sec = $env==='live' ? ((string)(getCfg($pdo,'paypal_client_secret_live','') ?? '')) : ((string)(getCfg($pdo,'paypal_client_secret_sandbox','') ?? ''));
  $wh  = $env==='live' ? ((string)(getCfg($pdo,'paypal_webhook_id_live','') ?? '')) : ((string)(getCfg($pdo,'paypal_webhook_id_sandbox','') ?? ''));
  $return_url = (string)((getCfg($pdo,'paypal_return_url','') ?? ''));
  $cancel_url = (string)((getCfg($pdo,'paypal_cancel_url','') ?? ''));

  $vendor_file = __DIR__.'/../../vendor/autoload.php';
  $vendor_ok = is_readable($vendor_file);
  $cfg_ok = ($cid!=='' && $sec!=='' && filter_var($return_url, FILTER_VALIDATE_URL) && filter_var($cancel_url, FILTER_VALIDATE_URL));
  $webhook_set = ($wh!=='');
  $oauth_ok=false; $oauth_err=null;

  if ($vendor_ok && $cfg_ok) {
    try{
      require_once $vendor_file;
      $base = $env==='live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
      $client = new \GuzzleHttp\Client(['base_uri'=>$base,'timeout'=>12]);
      $res = $client->post('/v1/oauth2/token',['auth'=>[$cid,$sec],'form_params'=>['grant_type'=>'client_credentials']]);
      $oauth_ok = ($res->getStatusCode()===200);
    }catch(Throwable $e){ $oauth_ok=false; $oauth_err=$e->getMessage(); }
  }

  $map_json = (string)((getCfg($pdo,'paypal_plan_map','{}')) ?? '{}');
  $map = json_decode($map_json,true) ?: [];
  $planes = $pdo->query("SELECT id, code, name FROM plans WHERE active=1 ORDER BY price_usd ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);
  $missing=[];
  foreach($planes as $p){
    $pid=(string)$p['id'];
    $m=$map[$pid]['monthly']['plan_id']??'';
    $a=$map[$pid]['annual']['plan_id']??'';
    if($m===''||$a===''){ $missing[]=['plan_id'=>$p['id'],'code'=>$p['code'],'name'=>$p['name'],'monthly_set'=>$m!=='','annual_set'=>$a!=='']; }
  }
  $plan_map_ok = (count($missing)===0);

  $connected = ($vendor_ok && $cfg_ok && $oauth_ok);

  jout(['ok'=>true,'active'=>$active,'env'=>$env,'vendor_ok'=>$vendor_ok,'cfg_ok'=>$cfg_ok,'oauth_ok'=>$oauth_ok,'webhook_set'=>$webhook_set,'plan_map_ok'=>$plan_map_ok,'connected'=>$connected,'details'=>['oauth_err'=>$oauth_err,'missing_plan_map'=>$missing,'webhook_id'=>$wh]]);
}

/* ---------- AJAX: save ---------- */
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='save_all') {
  $env = in_array($_POST['paypal_env']??'sandbox',['sandbox','live'],true) ? (string)$_POST['paypal_env'] : 'sandbox';
  $active = isset($_POST['paypal_active']) ? '1' : '0';
  $currency = strtoupper(trim((string)($_POST['paypal_currency'] ?? 'USD')));
  if (!preg_match('/^[A-Z]{3}$/',$currency)) $currency='USD';
  $return_url = trim((string)($_POST['paypal_return_url'] ?? ''));
  $cancel_url = trim((string)($_POST['paypal_cancel_url'] ?? ''));

  $cid_sb = trim((string)($_POST['paypal_client_id_sandbox'] ?? ''));
  $sec_sb = trim((string)($_POST['paypal_client_secret_sandbox'] ?? ''));
  $wh_sb  = trim((string)($_POST['paypal_webhook_id_sandbox'] ?? ''));

  $cid_lv = trim((string)($_POST['paypal_client_id_live'] ?? ''));
  $sec_lv = trim((string)($_POST['paypal_client_secret_live'] ?? ''));
  $wh_lv  = trim((string)($_POST['paypal_webhook_id_live'] ?? ''));

  $map=[];
  if (isset($_POST['plan_map']) && is_array($_POST['plan_map'])) {
    foreach($_POST['plan_map'] as $id=>$row){
      $id=(int)$id; if($id<=0) continue;
      $mon=trim((string)($row['monthly']??'')); $ann=trim((string)($row['annual']??''));
      if($mon!==''||$ann!==''){ $map[(string)$id]=[]; if($mon!=='') $map[(string)$id]['monthly']=['plan_id'=>$mon]; if($ann!=='') $map[(string)$id]['annual']=['plan_id'=>$ann]; }
    }
  }
  $map_json = json_encode($map, JSON_UNESCAPED_SLASHES);

  try{
    $pdo->beginTransaction();
    setCfg($pdo,'paypal_active',$active);
    setCfg($pdo,'paypal_env',$env);
    setCfg($pdo,'paypal_currency',$currency);
    setCfg($pdo,'paypal_return_url',$return_url);
    setCfg($pdo,'paypal_cancel_url',$cancel_url);

    setCfg($pdo,'paypal_client_id_sandbox',$cid_sb!==''?$cid_sb:null);
    setCfg($pdo,'paypal_client_secret_sandbox',$sec_sb!==''?$sec_sb:null);
    setCfg($pdo,'paypal_webhook_id_sandbox',$wh_sb!==''?$wh_sb:null);

    setCfg($pdo,'paypal_client_id_live',$cid_lv!==''?$cid_lv:null);
    setCfg($pdo,'paypal_client_secret_live',$sec_lv!==''?$sec_lv:null);
    setCfg($pdo,'paypal_webhook_id_live',$wh_lv!==''?$wh_lv:null);

    setCfg($pdo,'paypal_plan_map',$map_json);
    $pdo->commit();
    jout(['ok'=>true,'msg'=>'Guardado']);
  }catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    jout(['ok'=>false,'error'=>'No se pudo guardar']);
  }
}

/* ---------- Load cfg (defaults + overrides) ---------- */
$cfg = [
  'paypal_active' => 0,
  'paypal_env' => 'sandbox',
  'paypal_currency' => 'USD',
  'paypal_return_url' => 'https://geo.logihub.tech/paypal/return.php',
  'paypal_cancel_url' => 'https://geo.logihub.tech/paypal/cancel.php',
  'paypal_client_id_sandbox' => '',
  'paypal_client_secret_sandbox' => '',
  'paypal_webhook_id_sandbox' => '',
  'paypal_client_id_live' => '',
  'paypal_client_secret_live' => '',
  'paypal_webhook_id_live' => '',
  'paypal_plan_map' => '{}',
];
/* override con DB si existen */
$cfg['paypal_active'] = (int)((string)(getCfg($pdo,'paypal_active',(string)$cfg['paypal_active']) ?? (string)$cfg['paypal_active']));
$cfg['paypal_env'] = (string)(getCfg($pdo,'paypal_env',$cfg['paypal_env']) ?? $cfg['paypal_env']);
$cfg['paypal_currency'] = (string)(getCfg($pdo,'paypal_currency',$cfg['paypal_currency']) ?? $cfg['paypal_currency']);
$cfg['paypal_return_url'] = (string)(getCfg($pdo,'paypal_return_url',$cfg['paypal_return_url']) ?? $cfg['paypal_return_url']);
$cfg['paypal_cancel_url'] = (string)(getCfg($pdo,'paypal_cancel_url',$cfg['paypal_cancel_url']) ?? $cfg['paypal_cancel_url']);
$cfg['paypal_client_id_sandbox'] = (string)(getCfg($pdo,'paypal_client_id_sandbox',$cfg['paypal_client_id_sandbox']) ?? '');
$cfg['paypal_client_secret_sandbox'] = (string)(getCfg($pdo,'paypal_client_secret_sandbox',$cfg['paypal_client_secret_sandbox']) ?? '');
$cfg['paypal_webhook_id_sandbox'] = (string)(getCfg($pdo,'paypal_webhook_id_sandbox',$cfg['paypal_webhook_id_sandbox']) ?? '');
$cfg['paypal_client_id_live'] = (string)(getCfg($pdo,'paypal_client_id_live',$cfg['paypal_client_id_live']) ?? '');
$cfg['paypal_client_secret_live'] = (string)(getCfg($pdo,'paypal_client_secret_live',$cfg['paypal_client_secret_live']) ?? '');
$cfg['paypal_webhook_id_live'] = (string)(getCfg($pdo,'paypal_webhook_id_live',$cfg['paypal_webhook_id_live']) ?? '');
$cfg['paypal_plan_map'] = (string)(getCfg($pdo,'paypal_plan_map',$cfg['paypal_plan_map']) ?? $cfg['paypal_plan_map']);

$map_current = json_decode($cfg['paypal_plan_map'] ?: '{}', true) ?: [];
$planes = $pdo->query("SELECT id, code, name FROM plans WHERE active=1 ORDER BY price_usd ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);
$cur_webhook_id = ($cfg['paypal_env']==='live' ? $cfg['paypal_webhook_id_live'] : $cfg['paypal_webhook_id_sandbox']) ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Métodos de Pago - PayPal</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Inter,Arial,sans-serif}</style>
</head>
<body class="bg-gray-100 flex min-h-screen">
  <?php include __DIR__ . '/../../asset/admin/sidebar.php'; ?>

  <main class="flex-1 flex flex-col">
    <header class="bg-white shadow p-4">
      <div class="flex items-center justify-between">
        <div>
          <h1 class="text-2xl font-semibold text-gray-800">Métodos de Pago · PayPal</h1>
          <p class="text-sm text-gray-500">Suscripciones automáticas.</p>
        </div>
        <div class="flex items-center gap-2">
          <button id="btnCheck" class="px-3 py-1.5 rounded bg-indigo-600 text-white text-sm">Probar conexión</button>
          <button id="btnWebhookList" class="px-3 py-1.5 rounded bg-gray-700 text-white text-sm">Listar webhooks</button>
        </div>
      </div>
      <div id="statusBar" class="flex flex-wrap items-center gap-2 mt-3 text-sm"></div>
    </header>

    <div class="p-6 space-y-6">
      <section class="bg-white rounded-xl shadow p-6">
        <h2 class="text-lg font-semibold mb-4">Configuración</h2>
        <form id="frmPayPal" class="space-y-6">
          <input type="hidden" name="action" value="save_all">

          <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <label class="flex items-center gap-2">
              <input type="checkbox" name="paypal_active" <?=((int)($cfg['paypal_active'] ?? 0) ? 'checked' : '')?> class="w-4 h-4">
              <span>Activar PayPal</span>
            </label>

            <div>
              <label class="block text-sm text-gray-700 mb-1">Entorno</label>
              <select name="paypal_env" class="border rounded px-3 py-2 w-full">
                <?php $envSel = (string)($cfg['paypal_env'] ?? 'sandbox'); ?>
                <option value="sandbox" <?=($envSel==='sandbox'?'selected':'')?>>Sandbox</option>
                <option value="live" <?=($envSel==='live'?'selected':'')?>>Live</option>
              </select>
            </div>

            <div>
              <label class="block text-sm text-gray-700 mb-1">Moneda</label>
              <input name="paypal_currency" maxlength="3" value="<?=h($cfg['paypal_currency'] ?? 'USD')?>" class="border rounded px-3 py-2 w-full" placeholder="USD">
            </div>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label class="block text-sm text-gray-700 mb-1">Return URL</label>
              <input name="paypal_return_url" value="<?=h($cfg['paypal_return_url'] ?? '')?>" class="border rounded px-3 py-2 w-full" placeholder="https://geo.logihub.tech/paypal/return.php">
            </div>
            <div>
              <label class="block text-sm text-gray-700 mb-1">Cancel URL</label>
              <input name="paypal_cancel_url" value="<?=h($cfg['paypal_cancel_url'] ?? '')?>" class="border rounded px-3 py-2 w-full" placeholder="https://geo.logihub.tech/paypal/cancel.php">
            </div>
          </div>

          <hr class="my-4">

          <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="md:col-span-3"><h3 class="font-semibold">Credenciales Sandbox</h3></div>
            <div>
              <label class="block text-sm text-gray-700 mb-1">Client ID</label>
              <input name="paypal_client_id_sandbox" value="<?=h($cfg['paypal_client_id_sandbox'] ?? '')?>" class="border rounded px-3 py-2 w-full" placeholder="A...">
            </div>
            <div>
              <label class="block text-sm text-gray-700 mb-1">Client Secret</label>
              <input name="paypal_client_secret_sandbox" value="<?=h($cfg['paypal_client_secret_sandbox'] ?? '')?>" class="border rounded px-3 py-2 w-full" placeholder="<?=h(mask($cfg['paypal_client_secret_sandbox'] ?? ''))?>">
            </div>
            <div>
              <label class="block text-sm text-gray-700 mb-1">Webhook ID</label>
              <input name="paypal_webhook_id_sandbox" value="<?=h($cfg['paypal_webhook_id_sandbox'] ?? '')?>" class="border rounded px-3 py-2 w-full" placeholder="WH-...">
            </div>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <div class="md:col-span-3"><h3 class="font-semibold">Credenciales Live</h3></div>
            <div>
              <label class="block text-sm text-gray-700 mb-1">Client ID</label>
              <input name="paypal_client_id_live" value="<?=h($cfg['paypal_client_id_live'] ?? '')?>" class="border rounded px-3 py-2 w-full" placeholder="A...">
            </div>
            <div>
              <label class="block text-sm text-gray-700 mb-1">Client Secret</label>
              <input name="paypal_client_secret_live" value="<?=h($cfg['paypal_client_secret_live'] ?? '')?>" class="border rounded px-3 py-2 w-full" placeholder="<?=h(mask($cfg['paypal_client_secret_live'] ?? ''))?>">
            </div>
            <div>
              <label class="block text-sm text-gray-700 mb-1">Webhook ID</label>
              <input name="paypal_webhook_id_live" value="<?=h($cfg['paypal_webhook_id_live'] ?? '')?>" class="border rounded px-3 py-2 w-full" placeholder="WH-...">
            </div>
          </div>

          <hr class="my-4">

          <div class="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
            <h3 class="font-semibold">Webhook</h3>
            <div class="mt-2 grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
              <div class="md:col-span-2">
                <label class="block text-sm text-gray-700 mb-1">Webhook URL</label>
                <input id="inpWebhookUrl" class="border rounded px-3 py-2 w-full" value="https://geo.logihub.tech/paypal/webhook.php">
                <p class="text-xs text-gray-500 mt-1">
                  Actual entorno: <strong><?=h(strtoupper((string)($cfg['paypal_env'] ?? 'sandbox')))?></strong>.
                  ID actual: <strong><?=h((string)$cur_webhook_id ?: '—')?></strong>
                </p>
              </div>
              <div class="flex gap-2">
                <button id="btnWebhookCreate" type="button" class="px-3 py-2 bg-indigo-600 text-white rounded">Registrar</button>
                <button id="btnWebhookDelete" type="button" class="px-3 py-2 bg-rose-600 text-white rounded">Eliminar</button>
              </div>
            </div>
            <div id="webhookMsg" class="text-sm mt-2"></div>
            <div id="webhookList" class="mt-3 text-xs text-gray-700"></div>
          </div>

          <hr class="my-4">

          <div>
            <h3 class="font-semibold mb-2">Mapeo de planes → PayPal Plan ID</h3>
            <div class="grid grid-cols-1 gap-3">
              <?php foreach($planes as $p):
                $pid=(string)$p['id'];
                $mval=$map_current[$pid]['monthly']['plan_id']??'';
                $aval=$map_current[$pid]['annual']['plan_id']??'';
              ?>
              <div class="bg-gray-50 border rounded-lg p-3">
                <div class="font-medium text-sm text-gray-800"><?=h($p['name'])?> <span class="text-gray-500">(ID <?= (int)$p['id']?> · <?=h(strtoupper((string)$p['code']))?>)</span></div>
                <div class="mt-2 grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label class="block text-xs text-gray-600 mb-1">Monthly · PayPal Plan ID</label>
                    <input class="border rounded px-3 py-2 w-full" name="plan_map[<?=$p['id']?>][monthly]" value="<?=h($mval)?>" placeholder="P-XXXXXXXXXXXX">
                  </div>
                  <div>
                    <label class="block text-xs text-gray-600 mb-1">Annual · PayPal Plan ID</label>
                    <input class="border rounded px-3 py-2 w-full" name="plan_map[<?=$p['id']?>][annual]" value="<?=h($aval)?>" placeholder="P-YYYYYYYYYYYY">
                  </div>
                </div>
              </div>
              <?php endforeach; if(!$planes): ?>
                <p class="text-sm text-gray-500">No hay planes activos.</p>
              <?php endif; ?>
            </div>
          </div>

          <div class="pt-2">
            <button class="bg-indigo-600 hover:bg-indigo-700 text-white rounded px-4 py-2">Guardar</button>
            <span id="saveMsg" class="text-sm ml-2"></span>
          </div>
        </form>
      </section>

      <section class="bg-white rounded-xl shadow p-6">
        <h2 class="text-lg font-semibold mb-2">Vendor / Composer</h2>
        <p class="text-sm text-gray-700">Debe existir <code>/vendor/autoload.php</code>. Instala Guzzle:</p>
        <pre class="bg-gray-900 text-gray-100 text-xs p-3 rounded"><code>ssh root@62.171.182.126
cd /www/wwwroot/geo.logihub.tech/
composer require guzzlehttp/guzzle:^7</code></pre>
      </section>
    </div>
  </main>

<script>
function chip(label,ok){return `<span class="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs ${ok?'bg-emerald-50 text-emerald-700':'bg-rose-50 text-rose-700'}"><span class="w-2 h-2 rounded-full ${ok?'bg-emerald-500':'bg-rose-500'}"></span>${label}</span>`;}

async function fetchStatus(){
  const bar=document.getElementById('statusBar'); bar.innerHTML='Comprobando...';
  try{
    const r=await fetch('index.php?action=status',{credentials:'same-origin'}); const j=await r.json(); if(!j.ok) throw 0;
    bar.innerHTML = `
      ${chip('Activo',!!j.active)}
      ${chip('Entorno: '+String(j.env||'SANDBOX').toUpperCase(),true)}
      ${chip('vendor',!!j.vendor_ok)}
      ${chip('config',!!j.cfg_ok)}
      ${chip('oauth',!!j.oauth_ok)}
      ${chip('webhook id',!!j.webhook_set)}
      ${chip('plan map',!!j.plan_map_ok)}
      ${chip('Conectado',!!j.connected)}
    `;
  }catch(e){ bar.innerHTML=chip('Error estado',false); }
}

document.getElementById('btnCheck').addEventListener('click',e=>{e.preventDefault();fetchStatus();});
window.addEventListener('load',fetchStatus);

document.getElementById('frmPayPal').addEventListener('submit',function(e){
  e.preventDefault(); const fd=new FormData(e.target); const msg=document.getElementById('saveMsg');
  msg.textContent='Guardando...';
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'}).then(r=>r.json()).then(d=>{
    msg.textContent=d.ok?'Guardado':(d.error||'Error'); setTimeout(()=>msg.textContent='',2000); if(d.ok) fetchStatus();
  }).catch(()=>{msg.textContent='Error'; setTimeout(()=>msg.textContent='',2000);});
});

/* Webhook UI */
const wMsg = document.getElementById('webhookMsg');
const wList = document.getElementById('webhookList');

document.getElementById('btnWebhookCreate').addEventListener('click', async ()=>{
  const url = document.getElementById('inpWebhookUrl').value.trim();
  wMsg.textContent='Registrando...';
  try{
    const fd=new FormData(); fd.append('action','create'); fd.append('url',url);
    const r=await fetch('/admin/metodo/ajax/paypal_webhook.php',{method:'POST',body:fd,credentials:'same-origin'});
    const j=await r.json();
    wMsg.textContent = j.ok ? ('Webhook creado: '+(j.webhook?.id||'')) : ('Error: '+(j.error||''));
    fetchStatus();
  }catch(e){ wMsg.textContent='Error'; }
});

document.getElementById('btnWebhookDelete').addEventListener('click', async ()=>{
  if(!confirm('Eliminar webhook actual?')) return;
  wMsg.textContent='Eliminando...';
  try{
    const fd=new FormData(); fd.append('action','delete');
    const r=await fetch('/admin/metodo/ajax/paypal_webhook.php',{method:'POST',body:fd,credentials:'same-origin'});
    const j=await r.json();
    wMsg.textContent = j.ok?'Eliminado':'Error: '+(j.error||'');
    fetchStatus();
  }catch(e){ wMsg.textContent='Error'; }
});

document.getElementById('btnWebhookList').addEventListener('click', async ()=>{
  wList.textContent='Cargando...';
  try{
    const r=await fetch('/admin/metodo/ajax/paypal_webhook.php?action=list',{credentials:'same-origin'});
    const j=await r.json();
    if(!j.ok){ wList.textContent='Error al listar'; return; }
    if(!(j.items||[]).length){ wList.textContent='Sin webhooks.'; return; }
    wList.innerHTML = (j.items).map(w=>`<div class="border rounded p-2 mb-2"><div><b>ID:</b> ${w.id}</div><div><b>URL:</b> ${w.url}</div><div><b>Eventos:</b> ${(w.event_types||[]).map(e=>e.name).join(', ')}</div></div>`).join('');
  }catch(e){ wList.textContent='Error'; }
});
</script>
</body>
</html>
