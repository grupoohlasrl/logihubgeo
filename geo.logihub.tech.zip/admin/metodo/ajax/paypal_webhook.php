<?php
// /admin/metodo/ajax/paypal_webhook.php
declare(strict_types=1);
session_start();
if (!isset($_SESSION['user_id']) || (($_SESSION['user_rol'] ?? '')!=='admin')) { http_response_code(403); exit; }
require_once __DIR__.'/../../../config/db.php';

function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]); return $db;
}
function cfg(string $k, ?string $d=null): ?string {
  $st=pdo()->prepare("SELECT `value` FROM config_global WHERE `key`=?");
  $st->execute([$k]); $v=$st->fetchColumn();
  return $v!==false ? (string)$v : $d;
}
function setcfg(string $k, ?string $v): void {
  $st=pdo()->prepare("INSERT INTO config_global(`key`,`value`) VALUES(?,?)
                      ON DUPLICATE KEY UPDATE `value`=VALUES(`value`), updated_at=CURRENT_TIMESTAMP()");
  $st->execute([$k,$v]);
}
function jout($a){ header('Content-Type: application/json; charset=utf-8'); echo json_encode($a); exit; }

$env = (cfg('paypal_env','sandbox')==='live')?'live':'sandbox';
$client_id = $env==='live' ? (cfg('paypal_client_id_live','')??'') : (cfg('paypal_client_id_sandbox','')??'');
$secret    = $env==='live' ? (cfg('paypal_client_secret_live','')??'') : (cfg('paypal_client_secret_sandbox','')??'');
if (!$client_id || !$secret){ http_response_code(400); jout(['ok'=>false,'error'=>'missing_credentials']); }

$autoload = __DIR__.'/../../../vendor/autoload.php';
if (!is_readable($autoload)) { http_response_code(500); jout(['ok'=>false,'error'=>'no_vendor']); }
require_once $autoload;

$base = $env==='live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
$http = new \GuzzleHttp\Client(['base_uri'=>$base,'timeout'=>15]);

// Token
try{
  $tokRes = $http->post('/v1/oauth2/token', ['auth'=>[$client_id,$secret],'form_params'=>['grant_type'=>'client_credentials']]);
  $tok = json_decode((string)$tokRes->getBody(), true);
  $access = $tok['access_token'] ?? '';
  if(!$access) throw new RuntimeException('no_token');
}catch(Throwable $e){ http_response_code(401); jout(['ok'=>false,'error'=>'oauth']); }

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action==='list') {
  try{
    $r=$http->get('/v1/notifications/webhooks', ['headers'=>['Authorization'=>"Bearer {$access}"]]);
    $j=json_decode((string)$r->getBody(), true);
    jout(['ok'=>true,'items'=>$j['webhooks']??[]]);
  }catch(Throwable $e){ jout(['ok'=>false,'error'=>'list_fail']); }
}

if ($action==='create') {
  $url = trim((string)($_POST['url'] ?? ''));
  if (!filter_var($url, FILTER_VALIDATE_URL)) { jout(['ok'=>false,'error'=>'bad_url']); }
  $events = [
    'BILLING.SUBSCRIPTION.CREATED','BILLING.SUBSCRIPTION.ACTIVATED','BILLING.SUBSCRIPTION.RE-ACTIVATED',
    'BILLING.SUBSCRIPTION.CANCELLED','BILLING.SUBSCRIPTION.SUSPENDED','BILLING.SUBSCRIPTION.EXPIRED',
    'PAYMENT.SALE.COMPLETED'
  ];
  $event_types = array_map(fn($e)=>['name'=>$e], $events);
  try{
    $r=$http->post('/v1/notifications/webhooks',[
      'headers'=>['Authorization'=>"Bearer {$access}",'Content-Type'=>'application/json'],
      'json'=>['url'=>$url,'event_types'=>$event_types]
    ]);
    $j=json_decode((string)$r->getBody(), true);
    $id = $j['id'] ?? '';
    if ($id) {
      if ($env==='live') setcfg('paypal_webhook_id_live',$id);
      else setcfg('paypal_webhook_id_sandbox',$id);
    }
    jout(['ok'=>true,'webhook'=>$j]);
  }catch(Throwable $e){
    jout(['ok'=>false,'error'=>'create_fail']);
  }
}

if ($action==='delete') {
  $wid = trim((string)($_POST['id'] ?? ''));
  if (!$wid) {
    $wid = $env==='live' ? (cfg('paypal_webhook_id_live','')??'') : (cfg('paypal_webhook_id_sandbox','')??'');
  }
  if (!$wid) jout(['ok'=>false,'error'=>'no_id']);
  try{
    $http->delete('/v1/notifications/webhooks/'.rawurlencode($wid), ['headers'=>['Authorization'=>"Bearer {$access}"]]);
    if ($env==='live') setcfg('paypal_webhook_id_live', null);
    else setcfg('paypal_webhook_id_sandbox', null);
    jout(['ok'=>true]);
  }catch(Throwable $e){
    jout(['ok'=>false,'error'=>'delete_fail']);
  }
}

jout(['ok'=>false,'error'=>'bad_action']);
