<?php
// /admin/settings/index.php
declare(strict_types=1);
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_rol'] !== 'admin') {
  header('Location: /admin/auth/login/index.php'); exit;
}
require_once __DIR__ . '/../../config/db.php';

/* ---- utils ---- */
function jout($a){ header('Content-Type: application/json; charset=utf-8'); echo json_encode($a); exit; }
function ensure_app_settings(PDO $pdo){
  $pdo->exec("CREATE TABLE IF NOT EXISTS app_settings(
     k VARCHAR(100) PRIMARY KEY,
     v TEXT NULL,
     updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
function ensure_config_global(PDO $pdo){
  $pdo->exec("CREATE TABLE IF NOT EXISTS config_global(
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    provider VARCHAR(50) NOT NULL UNIQUE,
    api_base_url VARCHAR(255) NOT NULL,
    api_key TEXT NULL,
    active TINYINT(1) NOT NULL DEFAULT 0,
    request_timeout_ms INT NOT NULL DEFAULT 6000,
    rate_limit_ms INT NOT NULL DEFAULT 250,
    daily_quota_limit INT NULL,
    cron_token VARCHAR(64) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
function set_setting(PDO $pdo, string $k, $v){
  $st=$pdo->prepare("INSERT INTO app_settings(k,v) VALUES(?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)");
  $st->execute([$k, is_array($v)?json_encode($v,JSON_UNESCAPED_UNICODE):$v]);
}
function get_settings(PDO $pdo, array $keys): array{
  if (!$keys) return [];
  $in = implode(',', array_fill(0,count($keys),'?'));
  $st = $pdo->prepare("SELECT k,v FROM app_settings WHERE k IN ($in)");
  $st->execute($keys);
  $rows = $st->fetchAll(PDO::FETCH_KEY_PAIR);
  $out=[]; foreach($keys as $k){ $out[$k] = $rows[$k] ?? null; } return $out;
}
ensure_app_settings($pdo);
ensure_config_global($pdo);

/* ---- AJAX ---- */
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])) {
  $a = $_POST['action'];

  if ($a==='settings.get'){
    $keys = [
      'site_name','api_base_url','support_email','status_page_url','signup_enabled',
      'default_plan_id','rate_window_seconds','allow_zip_upload','auto_rebuild_zones',
      'site_logo_url','site_logo_dark_url','favicon_url',
      'global_rpm_limit','global_daily_limit'
    ];
    $s = get_settings($pdo, $keys);
    jout(['ok'=>true,'settings'=>$s]);
  }

  if ($a==='settings.save'){
    $fields = [
      'site_name','api_base_url','support_email','status_page_url',
      'default_plan_id','rate_window_seconds','site_logo_url','site_logo_dark_url','favicon_url',
      'global_rpm_limit','global_daily_limit'
    ];
    foreach($fields as $k){
      $v = $_POST[$k] ?? '';
      if (in_array($k,['default_plan_id','rate_window_seconds','global_rpm_limit','global_daily_limit'])) {
        $v = (string)max(0,(int)$v);
      }
      set_setting($pdo,$k,$v);
    }
    set_setting($pdo,'signup_enabled', isset($_POST['signup_enabled']) ? '1':'0');
    set_setting($pdo,'allow_zip_upload', isset($_POST['allow_zip_upload']) ? '1':'0');
    set_setting($pdo,'auto_rebuild_zones', isset($_POST['auto_rebuild_zones']) ? '1':'0');
    jout(['ok'=>true]);
  }

  if ($a==='plans.list'){
    $st=$pdo->query("SELECT id,code,name,monthly_calls,rpm_limit,price_usd,overage_price_per_1k,features,active,created_at
                     FROM plans ORDER BY active DESC, price_usd ASC");
    jout(['ok'=>true,'items'=>$st->fetchAll(PDO::FETCH_ASSOC)]);
  }
  if ($a==='plans.create'){
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $name = trim($_POST['name'] ?? '');
    $monthly = (int)($_POST['monthly_calls'] ?? 0);
    $rpm = (int)($_POST['rpm_limit'] ?? 0);
    $price = (float)($_POST['price_usd'] ?? 0);
    $over = ($_POST['overage_price_per_1k']!=='') ? (float)$_POST['overage_price_per_1k'] : null;
    $features = $_POST['features'] ?? null;
    if (!$code || !$name || $monthly<=0 || $rpm<=0) jout(['ok'=>false,'error'=>'Datos de plan inválidos']);
    $st=$pdo->prepare("INSERT INTO plans(code,name,monthly_calls,rpm_limit,price_usd,overage_price_per_1k,features,active)
                       VALUES(?,?,?,?,?,?,?,1)");
    $st->execute([$code,$name,$monthly,$rpm,$price,$over,$features]);
    jout(['ok'=>true]);
  }
  if ($a==='plans.update'){
    $id=(int)($_POST['id']??0);
    $name=trim($_POST['name']??'');
    $monthly=(int)($_POST['monthly_calls']??0);
    $rpm=(int)($_POST['rpm_limit']??0);
    $price=(float)($_POST['price_usd']??0);
    $over = ($_POST['overage_price_per_1k']!=='') ? (float)$_POST['overage_price_per_1k'] : null;
    $features = $_POST['features'] ?? null;
    $st=$pdo->prepare("UPDATE plans SET name=?, monthly_calls=?, rpm_limit=?, price_usd=?, overage_price_per_1k=?, features=? WHERE id=?");
    $st->execute([$name,$monthly,$rpm,$price,$over,$features,$id]);
    jout(['ok'=>true]);
  }
  if ($a==='plans.toggle'){
    $id=(int)($_POST['id']??0); $active=(int)($_POST['active']??0);
    $st=$pdo->prepare("UPDATE plans SET active=? WHERE id=?"); $st->execute([$active,$id]);
    jout(['ok'=>true]);
  }
  if ($a==='plans.delete'){
    $id=(int)($_POST['id']??0);
    $st=$pdo->prepare("SELECT COUNT(*) FROM subscriptions WHERE plan_id=?"); $st->execute([$id]);
    if ($st->fetchColumn()>0) jout(['ok'=>false,'error'=>'Plan con suscripciones']);
    $pdo->prepare("DELETE FROM plans WHERE id=?")->execute([$id]);
    jout(['ok'=>true]);
  }

  if ($a==='subs.assign'){
    $uid=(int)($_POST['usuario_id']??0);
    $pid=(int)($_POST['plan_id']??0);
    if(!$uid||!$pid) jout(['ok'=>false,'error'=>'Parámetros requeridos']);
    $pdo->prepare("UPDATE subscriptions SET status='canceled' WHERE usuario_id=? AND status IN('trial','active','past_due')")
        ->execute([$uid]);
    $end = (new DateTime())->modify('+30 days')->format('Y-m-d 23:59:59');
    $pdo->prepare("INSERT INTO subscriptions(usuario_id, plan_id, status, current_period_end) VALUES (?,?, 'active', ?)")
        ->execute([$uid,$pid,$end]);
    jout(['ok'=>true,'current_period_end'=>$end]);
  }
  if ($a==='subs.cancel'){
    $sid=(int)($_POST['subscription_id']??0);
    $pdo->prepare("UPDATE subscriptions SET status='canceled' WHERE id=?")->execute([$sid]);
    jout(['ok'=>true]);
  }
  if ($a==='subs.list'){
    $uid=(int)($_POST['usuario_id']??0);
    $st=$pdo->prepare("SELECT s.id, s.status, s.current_period_end, p.code, p.name
                       FROM subscriptions s JOIN plans p ON p.id=s.plan_id
                       WHERE s.usuario_id=? ORDER BY s.id DESC");
    $st->execute([$uid]);
    jout(['ok'=>true,'items'=>$st->fetchAll(PDO::FETCH_ASSOC)]);
  }

  if ($a==='zones.stats'){
    $a1=(int)$pdo->query("SELECT COUNT(*) FROM Zonas_global")->fetchColumn();
    $a2=(int)$pdo->query("SELECT COUNT(*) FROM zones")->fetchColumn();
    jout(['ok'=>true,'global'=>$a1,'zones'=>$a2]);
  }
  if ($a==='zones.rebuild'){
    try { $pdo->exec("CALL sp_rebuild_zones()"); }
    catch(Throwable $e){
      $pdo->exec("CREATE TEMPORARY TABLE tmp_z AS
                  SELECT MIN(id) AS zona_global_id
                  FROM Zonas_global
                  GROUP BY country_iso2, COALESCE(region_name,''), COALESCE(province_name,''), COALESCE(province_code,''), COALESCE(city,''), postal_code");
      $pdo->beginTransaction();
      $pdo->exec("DELETE FROM zones");
      $pdo->exec("INSERT INTO zones(zona_global_id) SELECT zona_global_id FROM tmp_z");
      $pdo->commit();
      $pdo->exec("DROP TEMPORARY TABLE tmp_z");
    }
    jout(['ok'=>true]);
  }

  /* ---- PROVEEDOR ZIPCODEBASE ---- */
  if ($a==='provider.get'){
    $st=$pdo->prepare("SELECT id,provider,api_base_url,active,request_timeout_ms,rate_limit_ms,daily_quota_limit,cron_token
                       FROM config_global WHERE provider='zipcodebase' LIMIT 1");
    $st->execute();
    $row=$st->fetch(PDO::FETCH_ASSOC);
    jout(['ok'=>true,'item'=>$row]);
  }
  if ($a==='provider.save'){
    $base = trim($_POST['api_base_url'] ?? '');
    $key  = trim($_POST['api_key'] ?? '');
    $active = (int)($_POST['active'] ?? 0);
    $to_ms  = max(1000,(int)($_POST['request_timeout_ms'] ?? 6000));
    $rl_ms  = max(0,(int)($_POST['rate_limit_ms'] ?? 250));
    $daily  = ($_POST['daily_quota_limit']!=='') ? max(0,(int)$_POST['daily_quota_limit']) : null;
    $cron   = trim($_POST['cron_token'] ?? '');

    $pdo->prepare("INSERT INTO config_global(provider, api_base_url, api_key, active, request_timeout_ms, rate_limit_ms, daily_quota_limit, cron_token)
                   VALUES ('zipcodebase',?,?,?,?,?,?,?)
                   ON DUPLICATE KEY UPDATE api_base_url=VALUES(api_base_url), api_key=VALUES(api_key), active=VALUES(active),
                                           request_timeout_ms=VALUES(request_timeout_ms), rate_limit_ms=VALUES(rate_limit_ms),
                                           daily_quota_limit=VALUES(daily_quota_limit), cron_token=VALUES(cron_token)")
        ->execute([$base,$key?:null,$active,$to_ms,$rl_ms,$daily,$cron?:null]);
    jout(['ok'=>true]);
  }
  if ($a==='provider.test'){
    // prueba simple: GET /search?codes=10005&country=us
    $st=$pdo->prepare("SELECT api_base_url, api_key, request_timeout_ms FROM config_global WHERE provider='zipcodebase' AND active=1 LIMIT 1");
    $st->execute();
    $cfg=$st->fetch(PDO::FETCH_ASSOC);
    if(!$cfg) jout(['ok'=>false,'error'=>'Proveedor inactivo o sin configurar']);

    $base=rtrim($cfg['api_base_url'],'/');
    $apikey=$cfg['api_key'];
    if(!$apikey) jout(['ok'=>false,'error'=>'Falta API key']);

    $url=$base.'/search?apikey='.rawurlencode($apikey).'&codes=10005&country=us';
    $ch=curl_init($url);
    curl_setopt_array($ch,[
      CURLOPT_RETURNTRANSFER=>true,
      CURLOPT_TIMEOUT_MS => (int)$cfg['request_timeout_ms'],
      CURLOPT_FOLLOWLOCATION=>true,
      CURLOPT_SSL_VERIFYPEER=>true,
      CURLOPT_SSL_VERIFYHOST=>2
    ]);
    $resp=curl_exec($ch);
    $err =curl_error($ch);
    $code=curl_getinfo($ch,CURLINFO_HTTP_CODE);
    curl_close($ch);

    if($err) jout(['ok'=>false,'error'=>$err]);
    if($code<200 || $code>=300) jout(['ok'=>false,'error'=>"HTTP $code",'body'=>substr($resp,0,300)]);
    // respuesta JSON de zipcodebase
    jout(['ok'=>true,'body'=>substr($resp,0,300)]);
  }

  jout(['ok'=>false,'error'=>'Acción inválida']);
}

/* ---- datos para HTML ---- */
$users = $pdo->query("SELECT id,name,email FROM users ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$plans = $pdo->query("SELECT id, code, name FROM plans WHERE active=1 ORDER BY price_usd ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Configuraciones - GeologiHub</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>body{font-family:'Inter',sans-serif}</style>
</head>
<body class="bg-gray-100 flex min-h-screen">
  <?php include __DIR__ . '/../../asset/admin/sidebar.php'; ?>
  <main class="flex-1 flex flex-col">
    <header class="bg-white shadow p-4 flex items-center gap-3">
      <img id="logoTop" src="/asset/img/logo.svg" alt="logo" class="h-7 w-auto">
      <h1 class="text-2xl font-semibold text-gray-800">Configuraciones</h1>
    </header>

    <div class="p-6 space-y-6">
      <div class="bg-white rounded-xl shadow p-4">
        <div class="flex gap-2 text-sm">
          <button class="tab px-3 py-2 rounded bg-indigo-600 text-white" data-t="general">Generales</button>
          <button class="tab px-3 py-2 rounded bg-gray-100" data-t="marca">Marca</button>
          <button class="tab px-3 py-2 rounded bg-gray-100" data-t="planes">Planes</button>
          <button class="tab px-3 py-2 rounded bg-gray-100" data-t="subs">Suscripciones</button>
          <button class="tab px-3 py-2 rounded bg-gray-100" data-t="datos">Datos</button>
          <button class="tab px-3 py-2 rounded bg-gray-100" data-t="zipcodebase">Zipcodebase</button>
        </div>
      </div>

      <!-- Generales -->
      <section id="tab-general" class="bg-white rounded-xl shadow p-6">
        <h2 class="text-lg font-semibold mb-4">Ajustes generales</h2>
        <form id="formGeneral" class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm mb-1">Nombre del sitio</label>
            <input name="site_name" class="w-full border rounded px-3 py-2" placeholder="GeologiHub">
          </div>
          <div>
            <label class="block text-sm mb-1">API Base URL</label>
            <input name="api_base_url" class="w-full border rounded px-3 py-2" placeholder="https://api.logihub.tech">
          </div>
          <div>
            <label class="block text-sm mb-1">Email de soporte</label>
            <input name="support_email" type="email" class="w-full border rounded px-3 py-2" placeholder="soporte@logihub.tech">
          </div>
          <div>
            <label class="block text-sm mb-1">Status Page URL</label>
            <input name="status_page_url" class="w-full border rounded px-3 py-2" placeholder="https://status.logihub.tech">
          </div>
          <div>
            <label class="block text-sm mb-1">Plan por defecto (nuevos usuarios)</label>
            <select name="default_plan_id" class="w-full border rounded px-3 py-2">
              <option value="0">—</option>
              <?php foreach($plans as $p): ?>
                <option value="<?= (int)$p['id'] ?>"><?= htmlspecialchars($p['code'].' - '.$p['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="block text-sm mb-1">Ventana de rate-limit (segundos)</label>
            <input name="rate_window_seconds" type="number" min="1" class="w-full border rounded px-3 py-2" value="60">
          </div>
          <div>
            <label class="block text-sm mb-1">Límite global RPM (0 = sin límite)</label>
            <input name="global_rpm_limit" type="number" min="0" class="w-full border rounded px-3 py-2" value="0">
          </div>
          <div>
            <label class="block text-sm mb-1">Límite global diario (0 = sin límite)</label>
            <input name="global_daily_limit" type="number" min="0" class="w-full border rounded px-3 py-2" value="0">
          </div>
          <div class="flex items-center gap-2">
            <input id="signup_enabled" name="signup_enabled" type="checkbox" class="h-4 w-4 border rounded">
            <label for="signup_enabled" class="text-sm">Habilitar registro</label>
          </div>
          <div class="flex items-center gap-2">
            <input id="allow_zip_upload" name="allow_zip_upload" type="checkbox" class="h-4 w-4 border rounded">
            <label for="allow_zip_upload" class="text-sm">Permitir subida de ZIP</label>
          </div>
          <div class="flex items-center gap-2">
            <input id="auto_rebuild_zones" name="auto_rebuild_zones" type="checkbox" class="h-4 w-4 border rounded">
            <label for="auto_rebuild_zones" class="text-sm">Auto-rebuild de zonas tras importación</label>
          </div>
          <div class="md:col-span-2">
            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded px-4 py-2">Guardar</button>
            <span id="saveMsg" class="text-sm ml-2"></span>
          </div>
        </form>
      </section>

      <!-- Marca -->
      <section id="tab-marca" class="bg-white rounded-xl shadow p-6 hidden">
        <h2 class="text-lg font-semibold mb-4">Marca</h2>
        <form id="formMarca" class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm mb-1">Logo (claro) URL</label>
            <input name="site_logo_url" class="w-full border rounded px-3 py-2" placeholder="/asset/img/logo.svg">
          </div>
          <div>
            <label class="block text-sm mb-1">Logo (oscuro) URL</label>
            <input name="site_logo_dark_url" class="w-full border rounded px-3 py-2" placeholder="/asset/img/logo-dark.svg">
          </div>
          <div>
            <label class="block text-sm mb-1">Favicon URL</label>
            <input name="favicon_url" class="w-full border rounded px-3 py-2" placeholder="/asset/img/favicon.ico">
          </div>
          <div class="md:col-span-2">
            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded px-4 py-2">Guardar</button>
            <span id="saveMsgBrand" class="text-sm ml-2"></span>
          </div>
        </form>
        <div class="mt-6 flex items-center gap-6">
          <div>
            <div class="text-sm text-gray-700 mb-1">Preview claro</div>
            <img id="prevLight" src="/asset/img/logo.svg" class="h-12 w-auto border rounded p-2 bg-white">
          </div>
          <div>
            <div class="text-sm text-gray-700 mb-1">Preview oscuro</div>
            <div class="bg-gray-900 p-2 inline-block rounded">
              <img id="prevDark" src="/asset/img/logo-dark.svg" class="h-12 w-auto">
            </div>
          </div>
        </div>
      </section>

      <!-- Planes -->
      <section id="tab-planes" class="bg-white rounded-xl shadow p-6 hidden">
        <h2 class="text-lg font-semibold mb-4">Planes</h2>
        <form id="planCreate" class="grid grid-cols-1 md:grid-cols-6 gap-3 mb-5">
          <input name="code" placeholder="CODE" class="border rounded px-2 py-2 md:col-span-1">
          <input name="name" placeholder="Nombre" class="border rounded px-2 py-2 md:col-span-2">
          <input name="monthly_calls" type="number" placeholder="Mensuales" class="border rounded px-2 py-2">
          <input name="rpm_limit" type="number" placeholder="RPM" class="border rounded px-2 py-2">
          <input name="price_usd" type="number" step="0.01" placeholder="$/mes" class="border rounded px-2 py-2">
          <input name="overage_price_per_1k" type="number" step="0.01" placeholder="$ extra /1k" class="border rounded px-2 py-2 md:col-span-1">
          <textarea name="features" placeholder='{"support":"email"}' class="border rounded px-2 py-2 md:col-span-6"></textarea>
          <div class="md:col-span-6">
            <button class="bg-green-600 hover:bg-green-700 text-white rounded px-4 py-2">Crear plan</button>
          </div>
        </form>
        <div class="overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-gray-50 text-xs uppercase text-gray-700">
              <tr>
                <th class="px-2 py-2 text-left">Code</th>
                <th class="px-2 py-2 text-left">Nombre</th>
                <th class="px-2 py-2 text-left">Mensuales</th>
                <th class="px-2 py-2 text-left">RPM</th>
                <th class="px-2 py-2 text-left">$</th>
                <th class="px-2 py-2 text-left">$/1k extra</th>
                <th class="px-2 py-2 text-left">Activo</th>
                <th class="px-2 py-2 text-left">Acciones</th>
              </tr>
            </thead>
            <tbody id="planRows"></tbody>
          </table>
        </div>
      </section>

      <!-- Suscripciones -->
      <section id="tab-subs" class="bg-white rounded-xl shadow p-6 hidden">
        <h2 class="text-lg font-semibold mb-4">Suscripciones</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
          <div>
            <label class="block text-sm mb-1">Usuario</label>
            <select id="subUser" class="w-full border rounded px-3 py-2">
              <option value="">Selecciona</option>
              <?php foreach($users as $u): ?>
                <option value="<?= (int)$u['id'] ?>"><?= htmlspecialchars($u['name']) ?> (<?= htmlspecialchars($u['email']??'') ?>)</option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="block text-sm mb-1">Plan</label>
            <select id="subPlan" class="w-full border rounded px-3 py-2">
              <?php foreach($plans as $p): ?>
                <option value="<?= (int)$p['id'] ?>"><?= htmlspecialchars($p['code'].' - '.$p['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="flex items-end">
            <button id="assignBtn" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded px-4 py-2">Asignar/Activar</button>
          </div>
        </div>
        <div class="overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-gray-50 text-xs uppercase text-gray-700">
              <tr>
                <th class="px-2 py-2 text-left">Plan</th>
                <th class="px-2 py-2 text-left">Estado</th>
                <th class="px-2 py-2 text-left">Vence</th>
                <th class="px-2 py-2 text-left">Acciones</th>
              </tr>
            </thead>
            <tbody id="subRows"></tbody>
          </table>
        </div>
      </section>

      <!-- Datos -->
      <section id="tab-datos" class="bg-white rounded-xl shadow p-6 hidden">
        <h2 class="text-lg font-semibold mb-4">Datos / Zonas</h2>
        <div class="flex items-center gap-4 mb-4">
          <div id="zoneStats" class="text-sm text-gray-700">—</div>
          <button id="rebuildBtn" class="border rounded px-3 py-2">Reconstruir zonas</button>
        </div>
        <p class="text-xs text-gray-500">Reconstruye <code>zones</code> desde <code>Zonas_global</code>.</p>
      </section>

      <!-- Zipcodebase -->
      <section id="tab-zipcodebase" class="bg-white rounded-xl shadow p-6 hidden">
        <h2 class="text-lg font-semibold mb-4">Proveedor: Zipcodebase</h2>
        <form id="formZip" class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm mb-1">API Base URL</label>
            <input name="api_base_url" class="w-full border rounded px-3 py-2" placeholder="https://app.zipcodebase.com/api/v1">
          </div>
          <div>
            <label class="block text-sm mb-1">API Key</label>
            <input name="api_key" class="w-full border rounded px-3 py-2" placeholder="************">
          </div>
          <div>
            <label class="block text-sm mb-1">Timeout (ms)</label>
            <input name="request_timeout_ms" type="number" min="1000" class="w-full border rounded px-3 py-2" value="6000">
          </div>
          <div>
            <label class="block text-sm mb-1">Rate-limit entre llamadas (ms)</label>
            <input name="rate_limit_ms" type="number" min="0" class="w-full border rounded px-3 py-2" value="250">
          </div>
          <div>
            <label class="block text-sm mb-1">Límite diario (0 = sin límite)</label>
            <input name="daily_quota_limit" type="number" min="0" class="w-full border rounded px-3 py-2" value="0">
          </div>
          <div>
            <label class="block text-sm mb-1">Cron token (seguridad)</label>
            <input name="cron_token" class="w-full border rounded px-3 py-2" placeholder="opcional">
          </div>
          <div class="flex items-center gap-2">
            <input id="zip_active" name="active" type="checkbox" class="h-4 w-4 border rounded" value="1">
            <label for="zip_active" class="text-sm">Activo</label>
          </div>
          <div class="md:col-span-2">
            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded px-4 py-2">Guardar</button>
            <button type="button" id="testZip" class="ml-2 border rounded px-4 py-2">Probar</button>
            <span id="zipMsg" class="text-sm ml-2"></span>
          </div>
        </form>
        <pre id="zipOut" class="mt-4 p-3 bg-gray-50 border rounded text-xs overflow-x-auto"></pre>
      </section>
    </div>
  </main>

<script>
const tabs = document.querySelectorAll('.tab');
const panels = {
  general: document.getElementById('tab-general'),
  marca:   document.getElementById('tab-marca'),
  planes:  document.getElementById('tab-planes'),
  subs:    document.getElementById('tab-subs'),
  datos:   document.getElementById('tab-datos'),
  zipcodebase: document.getElementById('tab-zipcodebase'),
};
tabs.forEach(btn=>{
  btn.addEventListener('click', ()=>{
    tabs.forEach(b=>{ b.classList.remove('bg-indigo-600','text-white'); b.classList.add('bg-gray-100'); });
    btn.classList.add('bg-indigo-600','text-white'); btn.classList.remove('bg-gray-100');
    Object.values(panels).forEach(p=>p.classList.add('hidden'));
    panels[btn.dataset.t].classList.remove('hidden');
  });
});

/* Generales */
const fg = document.getElementById('formGeneral');
const saveMsg = document.getElementById('saveMsg');
function loadSettings(){
  const fd=new FormData(); fd.append('action','settings.get');
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      if(!d.ok) return;
      const s=d.settings||{};
      fg.site_name.value = s.site_name||'';
      fg.api_base_url.value = s.api_base_url||'';
      fg.support_email.value = s.support_email||'';
      fg.status_page_url.value = s.status_page_url||'';
      fg.default_plan_id.value = s.default_plan_id||'0';
      fg.rate_window_seconds.value = s.rate_window_seconds||'60';
      fg.signup_enabled.checked = s.signup_enabled==='1';
      fg.allow_zip_upload.checked = s.allow_zip_upload==='1';
      fg.auto_rebuild_zones.checked = s.auto_rebuild_zones==='1';
      fg.global_rpm_limit.value = s.global_rpm_limit||'0';
      fg.global_daily_limit.value = s.global_daily_limit||'0';

      // marca previews
      fm.site_logo_url.value = s.site_logo_url||'/asset/img/logo.svg';
      fm.site_logo_dark_url.value = s.site_logo_dark_url||'/asset/img/logo-dark.svg';
      fm.favicon_url.value = s.favicon_url||'/asset/img/favicon.ico';
      document.getElementById('prevLight').src = fm.site_logo_url.value;
      document.getElementById('prevDark').src  = fm.site_logo_dark_url.value;
      document.getElementById('logoTop').src   = fm.site_logo_url.value;
    });
}
fg.addEventListener('submit', e=>{
  e.preventDefault();
  const fd=new FormData(fg); fd.append('action','settings.save');
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      saveMsg.textContent = d.ok ? 'Guardado' : (d.error||'Error');
      setTimeout(()=>saveMsg.textContent='',2000);
      if(d.ok){ loadSettings(); }
    });
});

/* Marca */
const fm = document.getElementById('formMarca');
const saveMsgBrand = document.getElementById('saveMsgBrand');
fm.addEventListener('submit', e=>{
  e.preventDefault();
  const fd=new FormData();
  fd.append('action','settings.save');
  fd.append('site_logo_url', fm.site_logo_url.value);
  fd.append('site_logo_dark_url', fm.site_logo_dark_url.value);
  fd.append('favicon_url', fm.favicon_url.value);
  // mantener actuales para no borrarlos
  ['site_name','api_base_url','support_email','status_page_url','default_plan_id','rate_window_seconds','global_rpm_limit','global_daily_limit']
    .forEach(k=>fd.append(k, document.querySelector(`[name="${k}"]`)?.value || ''));
  ['signup_enabled','allow_zip_upload','auto_rebuild_zones'].forEach(k=>{
    if(document.querySelector(`[name="${k}"]`)?.checked) fd.append(k,'on');
  });
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      saveMsgBrand.textContent = d.ok ? 'Guardado' : (d.error||'Error');
      setTimeout(()=>saveMsgBrand.textContent='',2000);
      if(d.ok){
        document.getElementById('prevLight').src = fm.site_logo_url.value;
        document.getElementById('prevDark').src  = fm.site_logo_dark_url.value;
        document.getElementById('logoTop').src   = fm.site_logo_url.value;
      }
    });
});

/* Planes */
const planRows = document.getElementById('planRows');
function listPlans(){
  const fd=new FormData(); fd.append('action','plans.list');
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      const it=d.items||[];
      if(it.length===0){ planRows.innerHTML = `<tr><td colspan="8" class="px-3 py-4 text-center text-gray-500">Sin planes</td></tr>`; return;}
      planRows.innerHTML = it.map(p=>`
        <tr class="border-t" data-id="${p.id}">
          <td class="px-2 py-2">${escapeHtml(p.code)}</td>
          <td class="px-2 py-2"><input class="inp w-full border rounded px-2 py-1" data-k="name" value="${escapeHtml(p.name)}"></td>
          <td class="px-2 py-2"><input class="inp w-24 border rounded px-2 py-1" data-k="monthly_calls" type="number" value="${p.monthly_calls}"></td>
          <td class="px-2 py-2"><input class="inp w-20 border rounded px-2 py-1" data-k="rpm_limit" type="number" value="${p.rpm_limit}"></td>
          <td class="px-2 py-2"><input class="inp w-24 border rounded px-2 py-1" data-k="price_usd" type="number" step="0.01" value="${p.price_usd}"></td>
          <td class="px-2 py-2"><input class="inp w-28 border rounded px-2 py-1" data-k="overage_price_per_1k" type="number" step="0.01" value="${p.overage_price_per_1k??''}"></td>
          <td class="px-2 py-2">
            ${p.active ? '<span class="text-green-700 bg-green-100 text-xs px-2 py-0.5 rounded-full">Activo</span>'
                       : '<span class="text-gray-700 bg-gray-200 text-xs px-2 py-0.5 rounded-full">Inactivo</span>'}
          </td>
          <td class="px-2 py-2 flex gap-2">
            <button class="px-2 py-1 border rounded text-xs btnSave">Guardar</button>
            ${p.active
              ? `<button class="px-2 py-1 border rounded text-xs btnToggle" data-active="0">Desactivar</button>`
              : `<button class="px-2 py-1 border rounded text-xs btnToggle" data-active="1">Activar</button>`
            }
            <button class="px-2 py-1 border rounded text-xs btnDel">Eliminar</button>
          </td>
        </tr>
      `).join('');
      bindPlanRowEvents();
    });
}
function bindPlanRowEvents(){
  document.querySelectorAll('.btnSave').forEach(b=>b.addEventListener('click', ()=>{
    const tr=b.closest('tr'); const id=tr.dataset.id;
    const data={id};
    tr.querySelectorAll('.inp').forEach(i=>{ data[i.dataset.k]=i.value; });
    const fd=new FormData(); fd.append('action','plans.update');
    Object.entries(data).forEach(([k,v])=>fd.append(k,v));
    fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
      .then(r=>r.json()).then(_=>listPlans());
  }));
  document.querySelectorAll('.btnToggle').forEach(b=>b.addEventListener('click', ()=>{
    const tr=b.closest('tr'); const id=tr.dataset.id; const active=b.dataset.active;
    const fd=new FormData(); fd.append('action','plans.toggle'); fd.append('id',id); fd.append('active',active);
    fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
      .then(r=>r.json()).then(_=>listPlans());
  }));
  document.querySelectorAll('.btnDel').forEach(b=>b.addEventListener('click', ()=>{
    if(!confirm('Eliminar plan?')) return;
    const tr=b.closest('tr'); const id=tr.dataset.id;
    const fd=new FormData(); fd.append('action','plans.delete'); fd.append('id',id);
    fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
      .then(r=>r.json()).then(d=>{
        if(!d.ok) return alert(d.error||'Error');
        listPlans();
      });
  }));
}
document.getElementById('planCreate').addEventListener('submit', e=>{
  e.preventDefault();
  const fd=new FormData(e.target); fd.append('action','plans.create');
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      if(!d.ok) return alert(d.error||'Error');
      e.target.reset(); listPlans();
    });
});

/* Suscripciones */
const subUser=document.getElementById('subUser');
const subPlan=document.getElementById('subPlan');
const subRows=document.getElementById('subRows');
document.getElementById('assignBtn').addEventListener('click', ()=>{
  if(!subUser.value) return alert('Selecciona usuario');
  const fd=new FormData(); fd.append('action','subs.assign'); fd.append('usuario_id',subUser.value); fd.append('plan_id',subPlan.value);
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      if(!d.ok) return alert(d.error||'Error');
      loadSubs();
    });
});
subUser.addEventListener('change', loadSubs);
function loadSubs(){
  subRows.innerHTML = `<tr><td colspan="4" class="px-3 py-4 text-center text-gray-500">Cargando...</td></tr>`;
  if(!subUser.value){ subRows.innerHTML = `<tr><td colspan="4" class="px-3 py-4 text-center text-gray-500">Selecciona usuario</td></tr>`; return; }
  const fd=new FormData(); fd.append('action','subs.list'); fd.append('usuario_id',subUser.value);
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      const it=d.items||[];
      if(it.length===0){ subRows.innerHTML=`<tr><td colspan="4" class="px-3 py-4 text-center text-gray-500">Sin suscripciones</td></tr>`; return;}
      subRows.innerHTML = it.map(s=>`
        <tr class="border-t">
          <td class="px-2 py-2">${escapeHtml(s.code)} - ${escapeHtml(s.name)}</td>
          <td class="px-2 py-2">${escapeHtml(s.status)}</td>
          <td class="px-2 py-2">${escapeHtml(s.current_period_end||'')}</td>
          <td class="px-2 py-2">
            ${s.status==='active'
              ? `<button class="px-2 py-1 border rounded text-xs btnCancel" data-id="${s.id}">Cancelar</button>`
              : ''}
          </td>
        </tr>
      `).join('');
      document.querySelectorAll('.btnCancel').forEach(b=>b.addEventListener('click', ()=>{
        const fd=new FormData(); fd.append('action','subs.cancel'); fd.append('subscription_id', b.dataset.id);
        fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
          .then(r=>r.json()).then(_=>loadSubs());
      }));
    });
}

/* Datos */
const zoneStats=document.getElementById('zoneStats');
document.getElementById('rebuildBtn').addEventListener('click', ()=>{
  const fd=new FormData(); fd.append('action','zones.rebuild');
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(_=>loadZoneStats());
});
function loadZoneStats(){
  const fd=new FormData(); fd.append('action','zones.stats');
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      if(!d.ok){ zoneStats.textContent='—'; return; }
      zoneStats.textContent = `Zonas_global: ${d.global}  |  zones: ${d.zones}`;
    });
}

/* Zipcodebase */
const fz = document.getElementById('formZip');
const zipMsg = document.getElementById('zipMsg');
const zipOut = document.getElementById('zipOut');
function loadZip(){
  const fd=new FormData(); fd.append('action','provider.get');
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      const it=d.item||{};
      fz.api_base_url.value = it.api_base_url || 'https://app.zipcodebase.com/api/v1';
      fz.request_timeout_ms.value = it.request_timeout_ms || 6000;
      fz.rate_limit_ms.value = it.rate_limit_ms || 250;
      fz.daily_quota_limit.value = it.daily_quota_limit || 0;
      fz.cron_token.value = it.cron_token || '';
      document.getElementById('zip_active').checked = (it.active|0)===1;
    });
}
fz.addEventListener('submit', e=>{
  e.preventDefault();
  const fd=new FormData(fz); fd.append('action','provider.save');
  if(!fz.api_key.value) fd.append('api_key',''); // mantener
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      zipMsg.textContent = d.ok ? 'Guardado' : (d.error||'Error');
      setTimeout(()=>zipMsg.textContent='',2000);
    });
});
document.getElementById('testZip').addEventListener('click', ()=>{
  const fd=new FormData(); fd.append('action','provider.test');
  zipOut.textContent='Probando...';
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      if(!d.ok){ zipOut.textContent = 'Error: ' + (d.error||''); return; }
      zipOut.textContent = d.body || '(OK)';
    });
});

/* comunes */
function escapeHtml(s){ return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[m])); }

/* init */
loadSettings();
listPlans();
loadZoneStats();
loadZip();
</script>
</body>
</html>
