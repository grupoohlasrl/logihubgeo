<?php
// /admin/nuevo/usuario/index.php
declare(strict_types=1);
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['user_rol'] ?? '') !== 'admin') {
  header('Location: /admin/auth/login/index.php'); exit;
}
require_once __DIR__ . '/../../../config/db.php';

function jout($a){ header('Content-Type: application/json; charset=utf-8'); echo json_encode($a); exit; }
function strv($x){ return trim((string)($x ?? '')); }
function intv($x){ return (int)($x ?? 0); }

function token_make(PDO $pdo, int $usuario_id, string $label='Primario'): array {
  // Genera LOGEO + 12 dígitos únicos. Guarda sólo hash SHA-256.
  for ($i=0; $i<6; $i++) {
    $num = str_pad((string)random_int(0, 999999999999), 12, '0', STR_PAD_LEFT);
    $plain = "LOGEO{$num}";
    $hash = hash('sha256', $plain);
    try {
      $st = $pdo->prepare("INSERT INTO api_tokens (usuario_id, token_hash, label, active) VALUES (?,?,?,1)");
      $st->execute([$usuario_id, $hash, $label]);
      return ['plain'=>$plain, 'id'=>$pdo->lastInsertId()];
    } catch (PDOException $e) {
      if ($e->getCode()==='23000') continue; // hash duplicado, reintentar
      throw $e;
    }
  }
  throw new RuntimeException('No se pudo generar token');
}

/* ---------- AJAX ---------- */
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '') === 'create') {
  $name  = strv($_POST['name'] ?? '');
  $email = strv($_POST['email'] ?? '');
  $pass  = (string)($_POST['password'] ?? '');
  $rol   = strv($_POST['rol'] ?? 'cliente');
  $status= strv($_POST['status'] ?? 'active');
  $plan_id = intv($_POST['plan_id'] ?? 0);
  $mk_token = isset($_POST['make_token']) ? 1 : 0;
  $token_label = strv($_POST['token_label'] ?? 'Primario');

  if ($name==='' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 8)
    jout(['ok'=>false,'error'=>'Datos inválidos']);
  if (!in_array($rol, ['admin','cliente'], true)) $rol='cliente';
  if (!in_array($status, ['active','suspended'], true)) $status='active';

  try {
    $pdo->beginTransaction();

    // crea usuario
    $ph = password_hash($pass, PASSWORD_BCRYPT, ['cost'=>12]);
    $st=$pdo->prepare("INSERT INTO users(name,email,password_hash,rol,status) VALUES(?,?,?,?,?)");
    $st->execute([$name,$email,$ph,$rol,$status]);
    $uid = (int)$pdo->lastInsertId();

    // suscripción opcional
    if ($plan_id > 0) {
      // valida plan
      $st=$pdo->prepare("SELECT id FROM plans WHERE id=? AND active=1");
      $st->execute([$plan_id]);
      if ($st->fetchColumn()) {
        $pdo->prepare("INSERT INTO subscriptions(usuario_id, plan_id, status, current_period_end) VALUES(?,?, 'active', DATE_ADD(CURDATE(), INTERVAL 30 DAY))")
            ->execute([$uid, $plan_id]);
      }
    }

    // token opcional
    $token_plain = null;
    if ($mk_token) {
      $tk = token_make($pdo, $uid, $token_label !== '' ? $token_label : 'Primario');
      $token_plain = $tk['plain']; // mostrar solo una vez
    }

    $pdo->commit();
    jout(['ok'=>true, 'usuario_id'=>$uid, 'token'=>$token_plain]);
  } catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if ($e->getCode()==='23000') jout(['ok'=>false,'error'=>'Email ya existe']);
    jout(['ok'=>false,'error'=>'Error de BD']);
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    jout(['ok'=>false,'error'=>'Error interno']);
  }
}

/* planes activos para selector */
$planes = $pdo->query("SELECT id, code, name FROM plans WHERE active=1 ORDER BY price_usd ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Nuevo usuario - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>body{font-family:'Inter',sans-serif}</style>
</head>
<body class="bg-gray-100 flex min-h-screen">
  <?php include __DIR__ . '/../../../asset/admin/sidebar.php'; ?>

  <main class="flex-1 flex flex-col">
    <header class="bg-white shadow p-4">
      <h1 class="text-2xl font-semibold text-gray-800">Crear usuario</h1>
    </header>

    <div class="p-6 max-w-3xl">
      <div class="bg-white rounded-xl shadow p-6">
        <form id="frmNew" class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="md:col-span-2">
            <label class="text-sm text-gray-700">Nombre</label>
            <input name="name" class="border rounded w-full px-3 py-2" required>
          </div>
          <div>
            <label class="text-sm text-gray-700">Email</label>
            <input name="email" type="email" class="border rounded w-full px-3 py-2" required>
          </div>
          <div>
            <label class="text-sm text-gray-700">Contraseña (min 8)</label>
            <input name="password" type="password" minlength="8" class="border rounded w-full px-3 py-2" required>
          </div>
          <div>
            <label class="text-sm text-gray-700">Rol</label>
            <select name="rol" class="border rounded w-full px-3 py-2">
              <option value="cliente">Cliente</option>
              <option value="admin">Administrador</option>
            </select>
          </div>
          <div>
            <label class="text-sm text-gray-700">Estado</label>
            <select name="status" class="border rounded w-full px-3 py-2">
              <option value="active">Activo</option>
              <option value="suspended">Suspendido</option>
            </select>
          </div>
          <div class="md:col-span-2">
            <label class="text-sm text-gray-700">Plan (opcional)</label>
            <select name="plan_id" class="border rounded w-full px-3 py-2">
              <option value="0">Sin plan</option>
              <?php foreach($planes as $p): ?>
                <option value="<?=$p['id']?>"><?=htmlspecialchars($p['name'])?> (<?=htmlspecialchars(strtoupper($p['code']))?>)</option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="md:col-span-2 border-t pt-4">
            <label class="inline-flex items-center gap-2">
              <input type="checkbox" name="make_token" checked class="w-4 h-4">
              <span class="text-sm">Crear token API</span>
            </label>
            <div class="mt-2">
              <label class="text-sm text-gray-700">Etiqueta del token</label>
              <input name="token_label" class="border rounded w-full px-3 py-2" placeholder="Primario">
            </div>
          </div>

          <div class="md:col-span-2">
            <input type="hidden" name="action" value="create">
            <button class="bg-indigo-600 hover:bg-indigo-700 text-white rounded px-4 py-2">Crear</button>
            <span id="msg" class="ml-3 text-sm"></span>
          </div>
        </form>

        <div id="outToken" class="mt-6 hidden">
          <div class="text-sm text-gray-700 mb-1">Token API generado (guárdalo ahora, no se volverá a mostrar):</div>
          <code id="tokenPlain" class="block bg-gray-100 border rounded px-3 py-2 break-all"></code>
        </div>
      </div>
    </div>
  </main>

<script>
const frm = document.getElementById('frmNew');
const msg = document.getElementById('msg');
const outToken = document.getElementById('outToken');
const tokenPlain = document.getElementById('tokenPlain');

frm.addEventListener('submit', e=>{
  e.preventDefault();
  msg.textContent = 'Creando...';
  outToken.classList.add('hidden'); tokenPlain.textContent='';
  const fd = new FormData(frm);
  fetch('index.php', {method:'POST', body:fd, credentials:'same-origin'})
    .then(r=>r.json())
    .then(d=>{
      if(!d.ok){ msg.textContent = d.error || 'Error'; return; }
      msg.textContent = 'Creado';
      if (d.token) { tokenPlain.textContent = d.token; outToken.classList.remove('hidden'); }
      frm.reset();
      setTimeout(()=>{ msg.textContent=''; }, 2000);
    })
    .catch(()=>{ msg.textContent='Error'; setTimeout(()=>msg.textContent='',2000); });
});
</script>
</body>
</html>
