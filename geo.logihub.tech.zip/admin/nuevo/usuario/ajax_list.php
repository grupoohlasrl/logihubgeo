<?php
declare(strict_types=1);

if (session_status()===PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Robots-Tag: noindex');

if (!isset($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['ok'=>false,'err'=>'No autenticado']); exit; }
if (($_SESSION['user_rol'] ?? '') !== 'admin') { http_response_code(403); echo json_encode(['ok'=>false,'err'=>'Acceso denegado']); exit; }
if (!hash_equals($_SESSION['list_token'] ?? '', (string)($_GET['token'] ?? ''))) { http_response_code(403); echo json_encode(['ok'=>false,'err'=>'Token inválido']); exit; }

require_once dirname(__DIR__, 3) . '/config/db.php';

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function getInt(string $name, int $def, int $min, int $max): int {
  $v = filter_input(INPUT_GET, $name, FILTER_VALIDATE_INT);
  if ($v===false || $v===null) return $def;
  return max($min, min($max, $v));
}

$sinceAllowed = [7,14,30];
$since = getInt('since', 7, 0, 365);
if (!in_array($since, $sinceAllowed, true)) $since = 7;

$page    = getInt('page', 1, 1, 100000);
$per     = getInt('per', 20, 5, 100);
$qRaw    = trim((string)($_GET['q'] ?? ''));
$q       = mb_substr($qRaw, 0, 100);

$where = '1=1';
$params = [];

if ($since > 0) {
  $where .= ' AND u.created_at >= (NOW() - INTERVAL :since DAY)';
  $params[':since'] = $since;
}
if ($q !== '') {
  $where .= ' AND (u.user_name LIKE :q OR u.user_email LIKE :q)';
  $params[':q'] = '%'.$q.'%';
}

/* Conteo */
try {
  $st = $pdo->prepare("SELECT COUNT(*) FROM users u WHERE $where");
  foreach ($params as $k=>$v) $st->bindValue($k, $v, is_int($v)?PDO::PARAM_INT:PDO::PARAM_STR);
  $st->execute();
  $total = (int)$st->fetchColumn();
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'err'=>'Error al contar']); exit;
}

/* Datos */
$offset = ($page - 1) * $per;
$totalPages = max(1, (int)ceil($total / $per));
if ($page > $totalPages) { $page = $totalPages; $offset = ($page - 1) * $per; }

try {
  $sql = "SELECT u.id, u.user_name AS name, u.user_email AS email, u.user_rol AS rol,
                 u.is_active AS activo, u.created_at AS creado, u.last_login_at AS ultimo_login
          FROM users u
          WHERE $where
          ORDER BY u.created_at DESC, u.id DESC
          LIMIT :lim OFFSET :off";
  $st = $pdo->prepare($sql);
  foreach ($params as $k=>$v) $st->bindValue($k, $v, is_int($v)?PDO::PARAM_INT:PDO::PARAM_STR);
  $st->bindValue(':lim', $per, PDO::PARAM_INT);
  $st->bindValue(':off', $offset, PDO::PARAM_INT);
  $st->execute();
  $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'err'=>'Error al listar']); exit;
}

/* HTML de filas */
if (!$rows) {
  $rows_html = '<tr><td colspan="8" class="px-4 py-6 text-center text-gray-500">Sin resultados.</td></tr>';
} else {
  $buf = [];
  foreach ($rows as $r) {
    $ok = (int)($r['activo'] ?? 0) === 1;
    $buf[] = '<tr class="hover:bg-gray-50">'.
      '<td class="px-4 py-2 text-sm text-gray-700">'.(int)$r['id'].'</td>'.
      '<td class="px-4 py-2 text-sm">'.h((string)$r['name']).'</td>'.
      '<td class="px-4 py-2 text-sm">'.h((string)$r['email']).'</td>'.
      '<td class="px-4 py-2 text-sm">'.h((string)$r['rol']).'</td>'.
      '<td class="px-4 py-2 text-sm"><span class="inline-flex items-center px-2 py-0.5 rounded text-xs '.($ok?'bg-green-100 text-green-800':'bg-red-100 text-red-800').'">'.($ok?'Sí':'No').'</span></td>'.
      '<td class="px-4 py-2 text-sm">'.h((string)$r['creado']).'</td>'.
      '<td class="px-4 py-2 text-sm">'.h((string)$r['ultimo_login']).'</td>'.
      '<td class="px-4 py-2 text-sm text-right">'.
        '<a class="text-indigo-600 hover:underline" href="/admin/users/view.php?id='.(int)$r['id'].'">Ver</a>'.
        '<span class="mx-2 text-gray-300">|</span>'.
        '<a class="text-gray-700 hover:underline" href="/admin/users/edit.php?id='.(int)$r['id'].'">Editar</a>'.
      '</td>'.
    '</tr>';
  }
  $rows_html = implode('', $buf);
}

/* HTML de paginación */
$start = max(1, $page-2);
$end   = min($totalPages, $page+2);
$pg = [];
if ($page>1) $pg[] = '<a href="#" data-page="'.($page-1).'" class="px-3 py-1 rounded border bg-white">←</a>';
for ($i=$start; $i<=$end; $i++) {
  $cls = $i===$page ? 'bg-indigo-600 text-white' : 'bg-white';
  $pg[] = '<a href="#" data-page="'.$i.'" class="px-3 py-1 rounded border '.$cls.'">'.$i.'</a>';
}
if ($page<$totalPages) $pg[] = '<a href="#" data-page="'.($page+1).'" class="px-3 py-1 rounded border bg-white">→</a>';
$pager_html = '<div class="text-sm text-gray-600">Mostrando '.($total?($offset+1):0).'–'.min($offset+$per, $total).' de '.$total.'</div>'.
              '<div class="flex gap-1">'.implode('', $pg).'</div>';

echo json_encode([
  'ok' => true,
  'since' => $since,
  'q' => $q,
  'page' => $page,
  'per' => $per,
  'total' => $total,
  'total_pages' => $totalPages,
  'rows_html' => $rows_html,
  'pager_html'=> $pager_html,
], JSON_UNESCAPED_UNICODE);
