<?php
session_start();
require_once __DIR__ . '/../../../config/db.php';

// Generar token único de 12 caracteres
function crear_token($pdo) {
    $abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    do {
        $t = '';
        for ($i = 0; $i < 12; $i++) $t .= $abc[random_int(0, strlen($abc) - 1)];
        // ¿Ya existe?
        $stmt = $pdo->prepare("SELECT 1 FROM users WHERE token=? LIMIT 1");
        $stmt->execute([$t]);
    } while ($stmt->fetch());
    return $t;
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name   = trim($_POST['name'] ?? '');
    $email  = trim($_POST['email'] ?? '');
    $pass   = $_POST['password'] ?? '';
    $rol    = ($_POST['rol'] === 'admin') ? 'admin' : 'cliente';
    $status = ($_POST['status'] === 'suspended') ? 'suspended' : 'active';

    if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($pass) >= 6) {
        $token = crear_token($pdo);
        $hash = password_hash($pass, PASSWORD_BCRYPT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash, rol, token, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $email, $hash, $rol, $token, $status]);
            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['user_name'] = $name;
            $_SESSION['user_rol'] = $rol;
            $_SESSION['user_token'] = $token;
            header('Location: /admin/panel/index.php');
            exit;
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate') !== false) {
                $err = 'Ese correo o token ya está registrado.';
            } else {
                $err = 'Error de registro: ' . $e->getMessage();
            }
        }
    } else {
        $err = 'Completa todos los campos correctamente (contraseña mínimo 6 caracteres).';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

    <div class="w-full max-w-md p-8 space-y-8 bg-white rounded-2xl shadow-lg">
        <div class="text-center">
            <h1 class="text-3xl font-bold text-gray-800">Crear Nueva Cuenta</h1>
            <p class="mt-2 text-sm text-gray-600">Añadir un nuevo usuario al sistema GeologiHub.</p>
        </div>

        <?php if ($err): ?>
        <div class="bg-red-100 text-red-800 px-4 py-2 rounded mb-3 text-center"><?=htmlspecialchars($err)?></div>
        <?php endif; ?>

        <form class="mt-8 space-y-6" action="" method="POST" autocomplete="off">
            <input type="hidden" name="remember" value="true">
            <div class="rounded-md shadow-sm space-y-4">

                <div>
                    <input id="name" name="name" type="text" required 
                        class="appearance-none rounded-lg relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" 
                        placeholder="Nombre completo" value="<?=htmlspecialchars($_POST['name'] ?? '')?>">
                </div>
                <div>
                    <input id="email-address" name="email" type="email" required 
                        class="appearance-none rounded-lg relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" 
                        placeholder="Correo electrónico" value="<?=htmlspecialchars($_POST['email'] ?? '')?>">
                </div>
                <div>
                    <input id="password" name="password" type="password" required minlength="6"
                        class="appearance-none rounded-lg relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" 
                        placeholder="Contraseña">
                </div>
                <div>
                    <select id="rol" name="rol" class="mt-1 block w-full py-3 px-3 border border-gray-300 bg-white rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <option value="cliente" <?=(@$_POST['rol']=='cliente')?'selected':''?>>Cliente</option>
                        <option value="admin" <?=(@$_POST['rol']=='admin')?'selected':''?>>Administrador</option>
                    </select>
                </div>
                <div>
                    <select id="status" name="status" class="mt-1 block w-full py-3 px-3 border border-gray-300 bg-white rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <option value="active" <?=(@$_POST['status']=='active')?'selected':''?>>Activo</option>
                        <option value="suspended" <?=(@$_POST['status']=='suspended')?'selected':''?>>Suspendido</option>
                    </select>
                </div>
            </div>
            <div>
                <button type="submit" 
                    class="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-300">
                    <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                        <svg class="h-5 w-5 text-indigo-500 group-hover:text-indigo-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clip-rule="evenodd" />
                        </svg>
                    </span>
                    Registrar Usuario
                </button>
            </div>
        </form>
        <div class="text-center mt-4">
            <a href="/admin/auth/login/index.php" class="text-indigo-600 hover:underline">¿Ya tienes cuenta? Inicia sesión</a>
        </div>
    </div>
</body>
</html>
