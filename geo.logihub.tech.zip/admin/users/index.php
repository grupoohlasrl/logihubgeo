<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_rol'] !== 'admin') {
    header('Location: /admin/auth/login/index.php');
    exit;
}
require_once __DIR__ . '/../../config/db.php';

// Paginación
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

// Total usuarios
$total = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$pages = ceil($total / $limit);

// Usuarios
$stmt = $pdo->prepare("SELECT id, name, email, rol, status, created_at FROM users ORDER BY id DESC LIMIT ? OFFSET ?");
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();
$usuarios = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100 flex min-h-screen">

<?php include __DIR__.'/../../asset/admin/sidebar.php'; ?>

<main class="flex-1 flex flex-col">
    <header class="bg-white shadow p-4">
        <h1 class="text-2xl font-semibold text-gray-800">Usuarios</h1>
    </header>
    <div class="flex-1 overflow-y-auto p-6 bg-gray-50">
        <div class="bg-white rounded-xl shadow overflow-hidden">
            <div class="p-6 flex justify-between items-center">
                <h2 class="text-xl font-semibold text-gray-800">Listado de usuarios</h2>
                <a href="/admin/auth/register/index.php" class="bg-indigo-600 text-white rounded-lg px-4 py-2 font-medium hover:bg-indigo-700 transition">+ Nuevo usuario</a>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left text-gray-500">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr>
                            <th class="px-6 py-3">ID</th>
                            <th class="px-6 py-3">Nombre</th>
                            <th class="px-6 py-3">Email</th>
                            <th class="px-6 py-3">Rol</th>
                            <th class="px-6 py-3">Estado</th>
                            <th class="px-6 py-3">Fecha</th>
                            <th class="px-6 py-3">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach($usuarios as $u): ?>
                        <tr class="bg-white border-b">
                            <td class="px-6 py-4"><?= $u['id'] ?></td>
                            <td class="px-6 py-4 font-medium text-gray-900"><?= htmlspecialchars($u['name']) ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($u['email']) ?></td>
                            <td class="px-6 py-4"><?= ucfirst($u['rol']) ?></td>
                            <td class="px-6 py-4">
                                <?php if($u['status']=='active'): ?>
                                  <span class="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Activo</span>
                                <?php else: ?>
                                  <span class="bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Suspendido</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4"><?= htmlspecialchars($u['created_at']) ?></td>
                            <td class="px-6 py-4">
                                <!-- Aquí puedes agregar botón de editar/eliminar -->
                                <a href="/admin/users/edit.php?id=<?=$u['id']?>" class="text-blue-600 hover:underline">Editar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <!-- Paginación -->
            <div class="p-4 bg-gray-50 flex justify-center">
                <?php for($i=1;$i<=$pages;$i++): ?>
                    <a href="?page=<?=$i?>" class="mx-1 px-3 py-1 rounded <?=($i==$page)?'bg-indigo-600 text-white':'bg-white text-gray-800 border'?>"><?=$i?></a>
                <?php endfor; ?>
            </div>
        </div>
    </div>
</main>
</body>
</html>
