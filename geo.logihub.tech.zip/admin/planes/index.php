<?php
// /admin/planes/index.php
declare(strict_types=1);
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['user_rol'] ?? '') !== 'admin') {
  header('Location: /admin/auth/login/index.php'); exit;
}
require_once __DIR__ . '/../../config/db.php';

function jout($a){ header('Content-Type: application/json; charset=utf-8'); echo json_encode($a); exit; }
function intv($x){ return (int)($x ?? 0); }
function floatv($x){ return (float)($x ?? 0); }
function strv($x){ return trim((string)($x ?? '')); }

/* -------- AJAX -------- */
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])) {
  $a = $_POST['action'];

  if ($a==='plans.list') {
    // métricas por plan
    $sql = "
      SELECT
        p.id, p.code, p.name, p.monthly_calls, p.rpm_limit, p.price_usd, p.overage_price_per_1k,
        p.features, p.active, p.created_at,
        /* total subs */
        (SELECT COUNT(*) FROM subscriptions s WHERE s.plan_id=p.id) AS subs_total,
        /* subs activas/trial/past_due */
        (SELECT COUNT(*) FROM subscriptions s WHERE s.plan_id=p.id AND s.status IN ('trial','active','past_due')) AS subs_active,
        /* uso mensual agregado de usuarios del plan */
        COALESCE((
          SELECT SUM(ud.calls) FROM subscriptions s2
          JOIN usage_daily ud ON ud.usuario_id = s2.usuario_id
          WHERE s2.plan_id = p.id
            AND s2.status IN ('trial','active','past_due')
            AND ud.day >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
        ),0) AS used_calls_month
      FROM plans p
      ORDER BY p.active DESC, p.price_usd ASC, p.id ASC";
    $items = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    jout(['ok'=>true,'items'=>$items]);
  }

  if ($a==='plans.create') {
    $code = strtoupper(strv($_POST['code'] ?? ''));
    $name = strv($_POST['name'] ?? '');
    $monthly = intv($_POST['monthly_calls'] ?? 0);
    $rpm = intv($_POST['rpm_limit'] ?? 0);
    $price = floatv($_POST['price_usd'] ?? 0);
    $over = ($_POST['overage_price_per_1k']!=='') ? floatv($_POST['overage_price_per_1k']) : null;
    $features = $_POST['features'] ?? null;
    if (!$code || !$name || $monthly<=0 || $rpm<=0) jout(['ok'=>false,'error'=>'Datos inválidos']);
    $st=$pdo->prepare("INSERT INTO plans(code,name,monthly_calls,rpm_limit,price_usd,overage_price_per_1k,features,active)
                       VALUES(?,?,?,?,?,?,?,1)");
    $st->execute([$code,$name,$monthly,$rpm,$price,$over,$features]);
    jout(['ok'=>true]);
  }

  if ($a==='plans.update') {
    $id = intv($_POST['id'] ?? 0);
    $name = strv($_POST['name'] ?? '');
    $monthly = intv($_POST['monthly_calls'] ?? 0);
    $rpm = intv($_POST['rpm_limit'] ?? 0);
    $price = floatv($_POST['price_usd'] ?? 0);
    $over = ($_POST['overage_price_per_1k']!=='') ? floatv($_POST['overage_price_per_1k']) : null;
    $features = $_POST['features'] ?? null;
    if ($id<=0) jout(['ok'=>false,'error'=>'ID inválido']);
    $st=$pdo->prepare("UPDATE plans SET name=?, monthly_calls=?, rpm_limit=?, price_usd=?, overage_price_per_1k=?, features=? WHERE id=?");
    $st->execute([$name,$monthly,$rpm,$price,$over,$features,$id]);
    jout(['ok'=>true]);
  }

  if ($a==='plans.toggle') {
    $id=intv($_POST['id']??0); $active=intv($_POST['active']??0);
    $pdo->prepare("UPDATE plans SET active=? WHERE id=?")->execute([$active,$id]);
    jout(['ok'=>true]);
  }

  if ($a==='plans.delete') {
    $id=intv($_POST['id']??0);
    $st=$pdo->prepare("SELECT COUNT(*) FROM subscriptions WHERE plan_id=?");
    $st->execute([$id]);
    if ($st->fetchColumn()>0) jout(['ok'=>false,'error'=>'Plan con suscripciones']);
    $pdo->prepare("DELETE FROM plans WHERE id=?")->execute([$id]);
    jout(['ok'=>true]);
  }

  if ($a==='plans.users') {
    $pid=intv($_POST['plan_id']??0);
    if ($pid<=0) jout(['ok'=>false,'error'=>'plan_id requerido']);
    $sql = "
      SELECT
        u.id, u.name, u.email, s.status, s.current_period_end,
        /* uso del mes por usuario */
        COALESCE((
          SELECT SUM(ud.calls) FROM usage_daily ud
          WHERE ud.usuario_id = u.id
            AND ud.day >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
        ),0) AS calls_month,
        /* RPM últimas 60 min (si hay tokens) */
        COALESCE((
          SELECT SUM(um.calls) FROM api_tokens t
          JOIN usage_minute um ON um.token_id = t.id
          WHERE t.usuario_id = u.id
            AND um.minute_ts >= (NOW() - INTERVAL 60 MINUTE)
        ),0) AS calls_last_60_min
      FROM subscriptions s
      JOIN users u ON u.id = s.usuario_id
      WHERE s.plan_id = ?
      ORDER BY FIELD(s.status,'active','trial','past_due','canceled'), u.name";
    $st=$pdo->prepare($sql); $st->execute([$pid]);
    $rows=$st->fetchAll(PDO::FETCH_ASSOC);
    jout(['ok'=>true,'items'=>$rows]);
  }

  jout(['ok'=>false,'error'=>'Acción inválida']);
}

/* -------- HTML -------- */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Planes - GeologiHub</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>body{font-family:'Inter',sans-serif}</style>
</head>
<body class="bg-gray-100 flex min-h-screen">
  <?php include __DIR__ . '/../../asset/admin/sidebar.php'; ?>

  <main class="flex-1 flex flex-col">
    <header class="bg-white shadow p-4">
      <h1 class="text-2xl font-semibold text-gray-800">Planes</h1>
    </header>

    <div class="p-6 space-y-6">
      <!-- Crear plan -->
      <section class="bg-white rounded-xl shadow p-6">
        <h2 class="text-lg font-semibold mb-4">Crear plan</h2>
        <form id="planCreate" class="grid grid-cols-1 md:grid-cols-6 gap-3">
          <input name="code" placeholder="CODE" class="border rounded px-3 py-2 md:col-span-1" required>
          <input name="name" placeholder="Nombre" class="border rounded px-3 py-2 md:col-span-2" required>
          <input name="monthly_calls" type="number" min="1" placeholder="Mensuales" class="border rounded px-3 py-2" required>
          <input name="rpm_limit" type="number" min="1" placeholder="RPM" class="border rounded px-3 py-2" required>
          <input name="price_usd" type="number" step="0.01" min="0" placeholder="$/mes" class="border rounded px-3 py-2">
          <input name="overage_price_per_1k" type="number" step="0.01" min="0" placeholder="$ extra /1k" class="border rounded px-3 py-2">
          <textarea name="features" placeholder='{"support":"email"}' class="border rounded px-3 py-2 md:col-span-6"></textarea>
          <div class="md:col-span-6">
            <button class="bg-indigo-600 hover:bg-indigo-700 text-white rounded px-4 py-2">Crear</button>
            <span id="createMsg" class="text-sm ml-2"></span>
          </div>
        </form>
      </section>

      <!-- Listado y métricas -->
      <section class="bg-white rounded-xl shadow p-6">
        <h2 class="text-lg font-semibold mb-4">Listado de planes</h2>
        <div class="overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-gray-50 text-xs uppercase text-gray-700">
              <tr>
                <th class="px-2 py-2 text-left">Activo</th>
                <th class="px-2 py-2 text-left">Code</th>
                <th class="px-2 py-2 text-left">Nombre</th>
                <th class="px-2 py-2 text-left">Mensuales</th>
                <th class="px-2 py-2 text-left">RPM</th>
                <th class="px-2 py-2 text-left">$</th>
                <th class="px-2 py-2 text-left">$ /1k extra</th>
                <th class="px-2 py-2 text-left">Subs (act/tot)</th>
                <th class="px-2 py-2 text-left">Uso mes</th>
                <th class="px-2 py-2 text-left">Acciones</th>
              </tr>
            </thead>
            <tbody id="rows"></tbody>
          </table>
        </div>
      </section>

      <!-- Panel usuarios del plan -->
      <section id="panelUsers" class="bg-white rounded-xl shadow p-6 hidden">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-lg font-semibold">Usuarios del plan <span id="planTitle" class="text-indigo-700"></span></h2>
          <button id="closeUsers" class="border rounded px-3 py-1 text-sm">Cerrar</button>
        </div>
        <div class="overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-gray-50 text-xs uppercase text-gray-700">
              <tr>
                <th class="px-2 py-2 text-left">Usuario</th>
                <th class="px-2 py-2 text-left">Email</th>
                <th class="px-2 py-2 text-left">Estado</th>
                <th class="px-2 py-2 text-left">Vence</th>
                <th class="px-2 py-2 text-left">Mes (calls)</th>
                <th class="px-2 py-2 text-left">Últ. 60 min</th>
              </tr>
            </thead>
            <tbody id="userRows"></tbody>
          </table>
        </div>
      </section>
    </div>
  </main>

<script>
const rows = document.getElementById('rows');
const panelUsers = document.getElementById('panelUsers');
const userRows = document.getElementById('userRows');
const planTitle = document.getElementById('planTitle');

function escapeHtml(s){ return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[m])); }

function listPlans(){
  const fd=new FormData(); fd.append('action','plans.list');
  rows.innerHTML = `<tr><td colspan="10" class="px-3 py-4 text-center text-gray-500">Cargando...</td></tr>`;
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      const it=d.items||[];
      if(it.length===0){ rows.innerHTML = `<tr><td colspan="10" class="px-3 py-6 text-center text-gray-500">Sin planes</td></tr>`; return; }
      rows.innerHTML = it.map(p=>`
        <tr class="border-t" data-id="${p.id}" data-name="${escapeHtml(p.name)}">
          <td class="px-2 py-2">
            ${p.active ? '<span class="bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">Sí</span>'
                       : '<span class="bg-gray-200 text-gray-700 text-xs px-2 py-0.5 rounded-full">No</span>'}
          </td>
          <td class="px-2 py-2">${escapeHtml(p.code)}</td>
          <td class="px-2 py-2"><input class="inp w-48 border rounded px-2 py-1" data-k="name" value="${escapeHtml(p.name)}"></td>
          <td class="px-2 py-2"><input class="inp w-24 border rounded px-2 py-1" data-k="monthly_calls" type="number" value="${p.monthly_calls}"></td>
          <td class="px-2 py-2"><input class="inp w-24 border rounded px-2 py-1" data-k="rpm_limit" type="number" value="${p.rpm_limit}"></td>
          <td class="px-2 py-2"><input class="inp w-24 border rounded px-2 py-1" data-k="price_usd" type="number" step="0.01" value="${p.price_usd}"></td>
          <td class="px-2 py-2"><input class="inp w-28 border rounded px-2 py-1" data-k="overage_price_per_1k" type="number" step="0.01" value="${p.overage_price_per_1k??''}"></td>
          <td class="px-2 py-2">${p.subs_active}/${p.subs_total}</td>
          <td class="px-2 py-2">${Number(p.used_calls_month||0).toLocaleString()}</td>
          <td class="px-2 py-2 flex flex-wrap gap-2">
            <button class="px-2 py-1 border rounded text-xs btnUsers">Ver usuarios</button>
            <button class="px-2 py-1 border rounded text-xs btnSave">Guardar</button>
            ${p.active
              ? `<button class="px-2 py-1 border rounded text-xs btnToggle" data-active="0">Desactivar</button>`
              : `<button class="px-2 py-1 border rounded text-xs btnToggle" data-active="1">Activar</button>`
            }
            <button class="px-2 py-1 border rounded text-xs btnDel">Eliminar</button>
          </td>
        </tr>
      `).join('');
      bindRowEvents();
    });
}
function bindRowEvents(){
  document.querySelectorAll('.btnSave').forEach(b=>b.addEventListener('click', ()=>{
    const tr=b.closest('tr'); const id=tr.dataset.id;
    const data={id};
    tr.querySelectorAll('.inp').forEach(i=>{ data[i.dataset.k]=i.value; });
    const fd=new FormData(); fd.append('action','plans.update');
    Object.entries(data).forEach(([k,v])=>fd.append(k,v));
    fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
      .then(r=>r.json()).then(d=>{ if(!d.ok) alert(d.error||'Error'); else listPlans(); });
  }));
  document.querySelectorAll('.btnToggle').forEach(b=>b.addEventListener('click', ()=>{
    const tr=b.closest('tr'); const id=tr.dataset.id; const active=b.dataset.active;
    const fd=new FormData(); fd.append('action','plans.toggle'); fd.append('id',id); fd.append('active',active);
    fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
      .then(r=>r.json()).then(_=>listPlans());
  }));
  document.querySelectorAll('.btnDel').forEach(b=>b.addEventListener('click', ()=>{
    if(!confirm('Eliminar plan?')) return;
    const tr=b.closest('tr'); const id=tr.dataset.id;
    const fd=new FormData(); fd.append('action','plans.delete'); fd.append('id',id);
    fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
      .then(r=>r.json()).then(d=>{ if(!d.ok) alert(d.error||'Error'); else listPlans(); });
  }));
  document.querySelectorAll('.btnUsers').forEach(b=>b.addEventListener('click', ()=>{
    const tr=b.closest('tr'); const id=tr.dataset.id; const nm=tr.dataset.name;
    planTitle.textContent = nm + ' (ID '+id+')';
    userRows.innerHTML = `<tr><td colspan="6" class="px-3 py-4 text-center text-gray-500">Cargando...</td></tr>`;
    panelUsers.classList.remove('hidden');
    const fd=new FormData(); fd.append('action','plans.users'); fd.append('plan_id',id);
    fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
      .then(r=>r.json()).then(d=>{
        const it=d.items||[];
        if(it.length===0){ userRows.innerHTML = `<tr><td colspan="6" class="px-3 py-6 text-center text-gray-500">Sin usuarios</td></tr>`; return; }
        userRows.innerHTML = it.map(u=>`
          <tr class="border-t">
            <td class="px-2 py-2">${escapeHtml(u.name)}</td>
            <td class="px-2 py-2">${escapeHtml(u.email||'')}</td>
            <td class="px-2 py-2">${escapeHtml(u.status)}</td>
            <td class="px-2 py-2">${escapeHtml(u.current_period_end||'')}</td>
            <td class="px-2 py-2">${Number(u.calls_month||0).toLocaleString()}</td>
            <td class="px-2 py-2">${Number(u.calls_last_60_min||0).toLocaleString()}</td>
          </tr>
        `).join('');
      });
  }));
}
document.getElementById('closeUsers').addEventListener('click', ()=>panelUsers.classList.add('hidden'));

document.getElementById('planCreate').addEventListener('submit', e=>{
  e.preventDefault();
  const fd=new FormData(e.target); fd.append('action','plans.create');
  const msg=document.getElementById('createMsg'); msg.textContent='Creando...';
  fetch('index.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(d=>{
      msg.textContent = d.ok ? 'Creado' : (d.error||'Error');
      setTimeout(()=>msg.textContent='',2000);
      if(d.ok){ e.target.reset(); listPlans(); }
    });
});

/* init */
listPlans();
</script>
</body>
</html>
