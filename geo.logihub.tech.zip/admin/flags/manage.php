<?php
declare(strict_types=1);
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: /admin/auth/login/index.php'); exit; }
require_once __DIR__.'/../../config/db.php';

/* seguridad */
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');

/* helpers DB sin information_schema */
function tableExists(PDO $pdo, string $name): bool {
  try { $pdo->query("SELECT 1 FROM `{$name}` LIMIT 1"); return true; }
  catch(Throwable $e){ return false; }
}
function scalar(PDO $pdo, string $sql, array $p=[]): int {
  try { $st=$pdo->prepare($sql); $st->execute($p); $v=$st->fetchColumn(); return $v===false?0:(int)$v; }
  catch(Throwable $e){ return 0; }
}

/* rutas */
$flagsDir = realpath(__DIR__.'/../../asset')?:(__DIR__.'/../../asset');
$flagsDir = rtrim($flagsDir,'/').'/flags';

/* csrf */
if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];
function checkCsrf(): void {
  if (($_POST['csrf']??'')!==($_SESSION['csrf']??'')) { http_response_code(400); exit('CSRF'); }
}

/* acciones POST: update inline */
$flash=['ok'=>[], 'err'=>[]];
if (($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
  checkCsrf();
  if (!tableExists($pdo,'countries')) { $flash['err'][]='Tabla countries no existe.'; goto after_post; }

  $id   = (int)($_POST['id']??0);
  $name = trim($_POST['name']??'');
  $path = trim($_POST['flag_path']??'');
  if ($id<=0) { $flash['err'][]='ID inválido.'; goto after_post; }
  if ($name==='') $name=null;

  if ($path!=='') {
    if (!preg_match('#^/asset/flags/[A-Za-z0-9._-]+\.(png|svg|webp)$#',$path)) { $flash['err'][]='Ruta inválida.'; goto after_post; }
  } else { $path=null; }

  $st=$pdo->prepare("UPDATE countries SET name=?, flag_path=? WHERE id=?");
  $st->execute([$name, $path, $id]);
  $flash['ok'][]='Guardado.';

  after_post:
  $_SESSION['flash']=$flash;
  $_SESSION['csrf']=bin2hex(random_bytes(16));
  header('Location: '.$_SERVER['REQUEST_URI']); exit;
}

/* filtros GET */
$q        = trim($_GET['q']??'');
$hasFlag  = isset($_GET['has_flag']) ? (int)$_GET['has_flag'] : -1; // -1 todos, 1 con, 0 sin
$sort     = $_GET['sort'] ?? 'iso2'; // iso2|name
$dir      = strtolower($_GET['dir'] ?? 'asc'); // asc|desc
$page     = max(1, (int)($_GET['page']??1));
$perPage  = min(100, max(10, (int)($_GET['per_page']??25)));
$offset   = ($page-1)*$perPage;

$sortSql = ($sort==='name'?'name':'iso2').' '.($dir==='desc'?'DESC':'ASC');

$where=[]; $params=[];
if ($q!=='') {
  $where[]="(iso2 LIKE ? OR name LIKE ?)";
  $params[]="%$q%"; $params[]="%$q%";
}
if ($hasFlag===1) $where[]="flag_path IS NOT NULL";
if ($hasFlag===0) $where[]="flag_path IS NULL";
$whereSql = $where ? ('WHERE '.implode(' AND ',$where)) : '';

$total = tableExists($pdo,'countries') ? scalar($pdo,"SELECT COUNT(*) FROM countries $whereSql", $params) : 0;

$sql="SELECT id, iso2, COALESCE(name,'') AS name, flag_path FROM countries $whereSql ORDER BY $sortSql LIMIT $perPage OFFSET $offset";
$st=$pdo->prepare($sql); $st->execute($params);
$rows=$st->fetchAll(PDO::FETCH_ASSOC);

/* util UI */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES,'UTF-8'); }
$baseUrl = strtok($_SERVER['REQUEST_URI'],'?');
function qs(array $add=[]){ $q=$_GET; unset($q['page']); $q=array_merge($q,$add); return http_build_query($q); }
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Países · Edición uno por uno</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>body{font-family:'Inter',sans-serif}</style>
</head>
<body class="bg-gray-100">
<div class="flex min-h-screen">
  <?php include __DIR__.'/../../asset/admin/sidebar.php'; ?>
  <main class="flex-1 p-6 space-y-6">
    <header class="flex items-center justify-between">
      <h1 class="text-2xl font-semibold">Países · Lista completa</h1>
      <a href="/admin/flags/index.php" class="text-sm text-indigo-700 underline">Gestión de banderas</a>
    </header>

    <?php if (!empty($_SESSION['flash'])): $flash=$_SESSION['flash']; unset($_SESSION['flash']); endif; ?>
    <?php if (!empty($flash['ok'])||!empty($flash['err'])): ?>
      <div class="space-y-2">
        <?php foreach($flash['ok']??[] as $m): ?><div class="bg-green-50 text-green-800 px-4 py-2 rounded"><?=h($m)?></div><?php endforeach; ?>
        <?php foreach($flash['err']??[] as $m): ?><div class="bg-red-50 text-red-800 px-4 py-2 rounded"><?=h($m)?></div><?php endforeach; ?>
      </div>
    <?php endif; ?>

    <!-- filtros -->
    <form class="bg-white p-4 rounded-xl shadow flex flex-wrap gap-3 items-end">
      <div>
        <label class="text-xs text-gray-500">Buscar</label>
        <input type="text" name="q" value="<?=h($q)?>" placeholder="ISO2 o nombre" class="block border rounded px-3 py-2">
      </div>
      <div>
        <label class="text-xs text-gray-500">Con bandera</label>
        <select name="has_flag" class="block border rounded px-3 py-2">
          <option value="-1"<?= $hasFlag===-1?' selected':''; ?>>Todos</option>
          <option value="1" <?= $hasFlag===1?' selected':''; ?>>Sólo con</option>
          <option value="0" <?= $hasFlag===0?' selected':''; ?>>Sólo sin</option>
        </select>
      </div>
      <div>
        <label class="text-xs text-gray-500">Orden</label>
        <select name="sort" class="block border rounded px-3 py-2">
          <option value="iso2"<?= $sort==='iso2'?' selected':''; ?>>ISO2</option>
          <option value="name"<?= $sort==='name'?' selected':''; ?>>Nombre</option>
        </select>
      </div>
      <div>
        <label class="text-xs text-gray-500">Dirección</label>
        <select name="dir" class="block border rounded px-3 py-2">
          <option value="asc"<?= $dir==='asc'?' selected':''; ?>>Asc</option>
          <option value="desc"<?= $dir==='desc'?' selected':''; ?>>Desc</option>
        </select>
      </div>
      <div>
        <label class="text-xs text-gray-500">Por página</label>
        <input type="number" min="10" max="100" name="per_page" value="<?= (int)$perPage ?>" class="block border rounded px-3 py-2 w-24">
      </div>
      <button class="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Filtrar</button>
      <a class="px-4 py-2 bg-slate-600 text-white rounded hover:bg-slate-700" href="<?=$baseUrl?>">Limpiar</a>
      <div class="ml-auto text-sm text-gray-600">Total: <?=number_format($total)?></div>
    </form>

    <!-- tabla -->
    <div class="bg-white rounded-xl shadow overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-gray-50 text-gray-600">
          <tr>
            <th class="px-3 py-2 text-left">ID</th>
            <th class="px-3 py-2 text-left">
              <a href="<?=$baseUrl.'?'.qs(['sort'=>'iso2','dir'=>$sort==='iso2' && $dir==='asc'?'desc':'asc'])?>">ISO2</a>
            </th>
            <th class="px-3 py-2 text-left">
              <a href="<?=$baseUrl.'?'.qs(['sort'=>'name','dir'=>$sort==='name' && $dir==='asc'?'desc':'asc'])?>">Nombre</a>
            </th>
            <th class="px-3 py-2 text-left">Bandera</th>
            <th class="px-3 py-2 text-left">Ruta</th>
            <th class="px-3 py-2">Guardar</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($rows): foreach($rows as $r):
            $abs = $r['flag_path'] ? ($_SERVER['DOCUMENT_ROOT'].$r['flag_path']) : null;
            $exists = $abs ? file_exists($abs) : false;
          ?>
          <tr class="border-b last:border-0">
            <td class="px-3 py-2"><?= (int)$r['id'] ?></td>
            <td class="px-3 py-2 font-semibold"><?= h(strtoupper($r['iso2'])) ?></td>
            <td class="px-3 py-2">
              <form method="post" class="flex items-center gap-2">
                <input type="hidden" name="csrf" value="<?=$csrf?>">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <input type="text" name="name" value="<?= h($r['name']) ?>" placeholder="Nombre..." class="w-56 px-2 py-1 border rounded">
            </td>
            <td class="px-3 py-2">
              <?php if ($r['flag_path'] && $exists): ?>
                <img src="<?=h($r['flag_path'])?>" alt="" class="w-6 h-4 object-cover rounded border" loading="lazy">
              <?php elseif ($r['flag_path']): ?>
                <span class="text-xs text-red-600">No existe</span>
              <?php else: ?>
                <span class="text-xs text-gray-400">—</span>
              <?php endif; ?>
            </td>
            <td class="px-3 py-2">
                <input type="text" name="flag_path" value="<?= h($r['flag_path']??'') ?>" placeholder="/asset/flags/it.png" class="w-72 px-2 py-1 border rounded text-xs">
            </td>
            <td class="px-3 py-2">
                <button class="px-3 py-1 bg-emerald-600 text-white rounded text-xs hover:bg-emerald-700">Guardar</button>
              </form>
            </td>
          </tr>
          <?php endforeach; else: ?>
          <tr><td colspan="6" class="px-3 py-6 text-center text-gray-500">Sin datos</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- paginación -->
    <?php
      $pages = (int)ceil($total / $perPage);
      if ($pages<1) $pages=1;
      $window = 5; $start=max(1,$page-$window); $end=min($pages,$page+$window);
    ?>
    <nav class="flex flex-wrap gap-2 items-center">
      <?php if ($page>1): ?>
        <a class="px-3 py-1 border rounded" href="<?=$baseUrl.'?'.qs(['page'=>1])?>">« Primero</a>
        <a class="px-3 py-1 border rounded" href="<?=$baseUrl.'?'.qs(['page'=>$page-1])?>">‹ Anterior</a>
      <?php endif; ?>
      <?php for($p=$start;$p<=$end;$p++): ?>
        <a class="px-3 py-1 border rounded <?= $p===$page?'bg-indigo-600 text-white border-indigo-600':'' ?>" href="<?=$baseUrl.'?'.qs(['page'=>$p])?>"><?=$p?></a>
      <?php endfor; ?>
      <?php if ($page<$pages): ?>
        <a class="px-3 py-1 border rounded" href="<?=$baseUrl.'?'.qs(['page'=>$page+1])?>">Siguiente ›</a>
        <a class="px-3 py-1 border rounded" href="<?=$baseUrl.'?'.qs(['page'=>$pages])?>">Último »</a>
      <?php endif; ?>
      <span class="text-sm text-gray-500 ml-2">Página <?=$page?> de <?=$pages?></span>
    </nav>

    <p class="text-xs text-gray-500">Las filas se guardan individualmente. La carpeta de banderas es <code><?=$flagsDir?></code>.</p>
  </main>
</div>
</body>
</html>
