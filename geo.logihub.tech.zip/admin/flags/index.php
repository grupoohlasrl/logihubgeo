<?php
declare(strict_types=1);
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: /admin/auth/login/index.php'); exit; }
require_once __DIR__.'/../../config/db.php';

/* ---------- seguridad básica ---------- */
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');

/* ---------- helpers DB (sin information_schema) ---------- */
function tableExists(PDO $pdo, string $name): bool {
  try { $pdo->query("SELECT 1 FROM `{$name}` LIMIT 1"); return true; }
  catch(Throwable $e){ return false; }
}
function colExists(PDO $pdo, string $table, string $col): bool {
  try { $pdo->query("SELECT `{$col}` FROM `{$table}` LIMIT 0"); return true; }
  catch(Throwable $e){ return false; }
}
function execSilent(PDO $pdo, string $sql): void { try{$pdo->exec($sql);}catch(Throwable $e){} }
function scalar(PDO $pdo, string $sql, array $p=[]): int {
  try { $st=$pdo->prepare($sql); $st->execute($p); $v=$st->fetchColumn(); return $v===false?0:(int)$v; }
  catch(Throwable $e){ return 0; }
}

/* ---------- asegurar columna flag_path en countries ---------- */
if (tableExists($pdo,'countries') && !colExists($pdo,'countries','flag_path')) {
  execSilent($pdo,"ALTER TABLE countries ADD COLUMN flag_path VARCHAR(191) NULL AFTER name");
  execSilent($pdo,"CREATE INDEX idx_countries_flag ON countries(flag_path)");
}

/* ---------- rutas ---------- */
$flagsDir = realpath(__DIR__.'/../../asset')?:(__DIR__.'/../../asset');
$flagsDir = rtrim($flagsDir,'/').'/flags';
if (!is_dir($flagsDir)) { @mkdir($flagsDir,0775,true); }

/* ---------- csrf ---------- */
if (empty($_SESSION['csrf'])) { $_SESSION['csrf']=bin2hex(random_bytes(16)); }
$csrf = $_SESSION['csrf'];
function checkCsrf(): void {
  if (($_POST['csrf']??'')!==($_SESSION['csrf']??'')) { http_response_code(400); exit('CSRF'); }
}

/* ---------- normalizar nombre → iso2 ---------- */
function isoFromFilename(string $fn): ?string {
  $base=strtolower(pathinfo($fn,PATHINFO_FILENAME));
  $base=preg_replace('/[^a-z]/','',$base)??'';
  if (strlen($base)>=2) return substr($base,0,2);
  return null;
}

/* ---------- escribir archivo seguro ---------- */
function safeCopy(string $src, string $dstDir, string $dstName): bool {
  if (!is_dir($dstDir)) @mkdir($dstDir,0775,true);
  $dst=rtrim($dstDir,'/').'/'.$dstName;
  return @copy($src,$dst);
}

/* ---------- actualizar DB por iso2 ---------- */
function upsertFlag(PDO $pdo, string $iso2, string $relPath, bool $autoCreate=false): void {
  $iso2 = strtoupper($iso2);
  $st=$pdo->prepare("SELECT id FROM countries WHERE iso2=?");
  $st->execute([$iso2]); $id=$st->fetchColumn();
  if (!$id && $autoCreate) {
    $ins=$pdo->prepare("INSERT INTO countries(iso2,name) VALUES(?,NULL)");
    $ins->execute([$iso2]);
    $id=$pdo->lastInsertId();
  }
  if ($id) {
    $up=$pdo->prepare("UPDATE countries SET flag_path=? WHERE iso2=?");
    $up->execute([$relPath,$iso2]);
  }
}

/* ---------- acciones ---------- */
$flash = ['ok'=>[], 'err'=>[]];

if (($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
  checkCsrf();
  $action = $_POST['action'] ?? '';

  if ($action==='upload_zip') {
    $overwrite = isset($_POST['overwrite']);
    $autoCreate = isset($_POST['auto_create']);

    if (!isset($_FILES['flags_zip']) || ($_FILES['flags_zip']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) {
      $flash['err'][]='Archivo ZIP requerido.'; goto after_post;
    }
    $f=$_FILES['flags_zip'];
    $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
    if ($ext!=='zip') { $flash['err'][]='El archivo debe ser .zip'; goto after_post; }

    // MIME seguro con fallback
    $mime = '';
    if (function_exists('finfo_open')) {
      $fi=@finfo_open(FILEINFO_MIME_TYPE);
      if ($fi) { $mime=@finfo_file($fi,$f['tmp_name'])?:''; @finfo_close($fi); }
    }
    if ($mime==='') { $mime = @mime_content_type($f['tmp_name']) ?: ''; }
    if (strpos((string)$mime,'zip')===false && $mime!=='application/octet-stream') { $flash['err'][]='MIME inválido'; goto after_post; }

    // Copia del ZIP en la raíz
    $root = realpath(__DIR__ . '/../../') ?: dirname(__DIR__, 2);
    $backupDir = rtrim($root,'/').'/_flags_uploads';
    if (!is_dir($backupDir)) { @mkdir($backupDir, 0775, true); }
    $stamp = date('Ymd_His');
    @copy($f['tmp_name'], $backupDir.'/flags_'.$stamp.'.zip');

    // Extraer temporal
    $tmpBase=sys_get_temp_dir().'/flags_'.bin2hex(random_bytes(6));
    @mkdir($tmpBase,0775,true);

    $zip = new ZipArchive();
    if ($zip->open($f['tmp_name'])!==true) { $flash['err'][]='No se pudo abrir el ZIP'; goto after_post; }
    $zip->extractTo($tmpBase);
    $zip->close();

    $supported = ['png','svg','webp'];
    $found=0; $mapped=0; $created=0; $skipped=0; $copied=0;

    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmpBase, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $file) {
      if (!$file->isFile()) continue;
      $ext=strtolower(pathinfo((string)$file,PATHINFO_EXTENSION));
      if (!in_array($ext,$supported,true)) { $skipped++; continue; }
      $found++;
      $iso = isoFromFilename($file->getFilename());
      if (!$iso || strlen($iso)!==2) { $skipped++; continue; }

      $dstName = strtolower($iso).'.'.$ext;           // estandarizamos nombre
      $dstPath = rtrim($flagsDir,'/').'/'.$dstName;
      if (file_exists($dstPath) && !$overwrite) { $skipped++; continue; }

      if (safeCopy((string)$file, $flagsDir, $dstName)) {
        $copied++;
        $rel = '/asset/flags/'.$dstName;
        $before = scalar($pdo,"SELECT COUNT(*) FROM countries WHERE iso2=?", [strtoupper($iso)]);
        upsertFlag($pdo,$iso,$rel,$autoCreate);
        $after = scalar($pdo,"SELECT COUNT(*) FROM countries WHERE iso2=?", [strtoupper($iso)]);
        if ($after && !$before && $autoCreate) $created++;
        $mapped++;
      } else { $skipped++; }
    }
    // limpieza
    $itc = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmpBase, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach($itc as $fs){ $fs->isDir()?@rmdir($fs->getRealPath()):@unlink($fs->getRealPath()); }
    @rmdir($tmpBase);

    $flash['ok'][]="Procesado: archivos=$found, copiados=$copied, mapeados=$mapped, creados=$created, omitidos=$skipped.";

  } elseif ($action==='rescan_folder') {
    $overwrite = isset($_POST['overwrite']);
    $autoCreate = isset($_POST['auto_create']);

    if (!is_dir($flagsDir)) { $flash['err'][]='Carpeta /asset/flags/ no existe.'; goto after_post; }
    $files = glob($flagsDir.'/*.{png,svg,webp}', GLOB_BRACE);
    $mapped=0; $skipped=0; $created=0;
    foreach ($files as $fp) {
      $iso = isoFromFilename(basename($fp));
      if (!$iso) { $skipped++; continue; }
      $rel='/asset/flags/'.basename($fp);
      if (!$overwrite) {
        $has = scalar($pdo,"SELECT COUNT(*) FROM countries WHERE iso2=? AND flag_path IS NOT NULL", [strtoupper($iso)]);
        if ($has) { $skipped++; continue; }
      }
      $before = scalar($pdo,"SELECT COUNT(*) FROM countries WHERE iso2=?", [strtoupper($iso)]);
      upsertFlag($pdo,$iso,$rel,$autoCreate);
      $after = scalar($pdo,"SELECT COUNT(*) FROM countries WHERE iso2=?", [strtoupper($iso)]);
      if ($after && !$before && $autoCreate) $created++;
      $mapped++;
    }
    $flash['ok'][]="Re-escaneo: mapeados=$mapped, creados=$created, omitidos=$skipped.";

  } elseif ($action==='set_manual') {
    $iso2 = strtoupper(trim($_POST['iso2']??''));
    $path = trim($_POST['flag_path']??'');
    if (!preg_match('/^[A-Z]{2}$/',$iso2)) { $flash['err'][]='ISO2 inválido.'; goto after_post; }
    if ($path!=='' && !preg_match('#^/asset/flags/[A-Za-z0-9._-]+\.(png|svg|webp)$#',$path)) { $flash['err'][]='Ruta inválida.'; goto after_post; }
    $st=$pdo->prepare("UPDATE countries SET flag_path=? WHERE iso2=?");
    $st->execute([$path?:null,$iso2]);
    $flash['ok'][]='Actualizado.';
  }

  after_post:
  $_SESSION['flash']=$flash;                   // persistir mensajes
  $_SESSION['csrf']=bin2hex(random_bytes(16)); // renovar token
  header('Location: '.$_SERVER['REQUEST_URI']); exit;
}

/* ---------- datos para la vista ---------- */
$totalCountries = tableExists($pdo,'countries') ? scalar($pdo,"SELECT COUNT(*) FROM countries") : 0;
$withFlag = tableExists($pdo,'countries') ? scalar($pdo,"SELECT COUNT(*) FROM countries WHERE flag_path IS NOT NULL") : 0;
$perm = is_writable($flagsDir);
$flagsFiles = is_dir($flagsDir) ? glob($flagsDir.'/*.{png,svg,webp}', GLOB_BRACE) : [];
sort($flagsFiles, SORT_NATURAL);

$rows=[];
if (tableExists($pdo,'countries')) {
  $st=$pdo->query("SELECT iso2, COALESCE(name, '') AS name, flag_path FROM countries ORDER BY iso2 ASC");
  $rows=$st->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Banderas por País · Admin</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>body{font-family:'Inter',sans-serif}</style>
</head>
<body class="bg-gray-100">
<div class="flex min-h-screen">
  <?php include __DIR__.'/../../asset/admin/sidebar.php'; ?>

  <main class="flex-1 flex flex-col">
    <header class="bg-white shadow p-4">
      <h1 class="text-2xl font-semibold text-gray-800">Gestión de Banderas</h1>
      <p class="text-sm text-gray-500 mt-1">
        Directorio: <code>/asset/flags/</code>
        <?= $perm?'<span class="text-green-600">(escribible)</span>':'<span class="text-red-600">(sin permiso de escritura)</span>' ?>
      </p>
    </header>

    <section class="p-6 space-y-6">
      <!-- Flash -->
      <?php if (!empty($_SESSION['flash'])): $flash=$_SESSION['flash']; unset($_SESSION['flash']); endif; ?>
      <?php if (!empty($flash['ok'])||!empty($flash['err'])): ?>
        <div class="space-y-2">
          <?php foreach($flash['ok']??[] as $m): ?><div class="bg-green-50 text-green-800 px-4 py-2 rounded"><?=htmlspecialchars($m)?></div><?php endforeach; ?>
          <?php foreach($flash['err']??[] as $m): ?><div class="bg-red-50 text-red-800 px-4 py-2 rounded"><?=htmlspecialchars($m)?></div><?php endforeach; ?>
        </div>
      <?php endif; ?>

      <!-- KPIs -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white p-4 rounded-xl shadow">
          <div class="text-sm text-gray-500">Países</div>
          <div class="text-3xl font-bold"><?=number_format((int)$totalCountries)?></div>
        </div>
        <div class="bg-white p-4 rounded-xl shadow">
          <div class="text-sm text-gray-500">Con bandera</div>
          <div class="text-3xl font-bold"><?=number_format((int)$withFlag)?></div>
        </div>
        <div class="bg-white p-4 rounded-xl shadow">
          <div class="text-sm text-gray-500">Archivos en carpeta</div>
          <div class="text-3xl font-bold"><?=number_format(count($flagsFiles))?></div>
        </div>
        <div class="bg-white p-4 rounded-xl shadow">
          <div class="text-sm text-gray-500">Carpeta</div>
          <div class="text-xs break-all text-gray-700"><?=$flagsDir?></div>
        </div>
      </div>

      <!-- Subir ZIP -->
      <div class="bg-white p-6 rounded-xl shadow">
        <h2 class="text-lg font-semibold mb-3">Subir ZIP de banderas</h2>
        <form method="post" enctype="multipart/form-data" class="space-y-4">
          <input type="hidden" name="csrf" value="<?=$csrf?>">
          <input type="hidden" name="action" value="upload_zip">
          <div>
            <input type="file" name="flags_zip" accept=".zip" required
                   class="block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
            <p class="text-xs text-gray-500 mt-1">Nombres esperados: <code>us.png</code>, <code>it.svg</code>. Se mapean por ISO2.</p>
          </div>
          <div class="flex items-center gap-6">
            <label class="inline-flex items-center gap-2 text-sm"><input type="checkbox" name="overwrite" class="rounded"> Sobrescribir existentes</label>
            <label class="inline-flex items-center gap-2 text-sm"><input type="checkbox" name="auto_create" class="rounded"> Crear país si no existe</label>
          </div>
          <button class="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Procesar ZIP</button>
        </form>
      </div>

      <!-- Re-escanear carpeta -->
      <div class="bg-white p-6 rounded-xl shadow">
        <h2 class="text-lg font-semibold mb-3">Re-escaneo de /asset/flags/</h2>
        <form method="post" class="flex flex-wrap items-center gap-4">
          <input type="hidden" name="csrf" value="<?=$csrf?>">
          <input type="hidden" name="action" value="rescan_folder">
          <label class="inline-flex items-center gap-2 text-sm"><input type="checkbox" name="overwrite" class="rounded"> Sobrescribir existentes</label>
          <label class="inline-flex items-center gap-2 text-sm"><input type="checkbox" name="auto_create" class="rounded"> Crear país si no existe</label>
          <button class="px-4 py-2 bg-slate-700 text-white rounded hover:bg-slate-800">Re-escanear</button>
        </form>
      </div>

      <!-- Tabla -->
      <div class="bg-white rounded-xl shadow overflow-hidden">
        <div class="p-4 border-b"><h2 class="text-lg font-semibold">Listado por ISO2</h2></div>
        <div class="overflow-x-auto">
          <table class="w-full text-sm">
            <thead class="bg-gray-50 text-gray-600">
              <tr>
                <th class="px-4 py-2 text-left">ISO2</th>
                <th class="px-4 py-2 text-left">Nombre</th>
                <th class="px-4 py-2 text-left">Vista</th>
                <th class="px-4 py-2 text-left">Ruta</th>
                <th class="px-4 py-2">Acción</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($rows): foreach($rows as $r):
                $iso = strtoupper($r['iso2']);
                $name = $r['name'] ?: '';
                $path = $r['flag_path'] ?: '';
              ?>
              <tr class="border-b">
                <td class="px-4 py-2 font-semibold"><?=$iso?></td>
                <td class="px-4 py-2"><?=htmlspecialchars($name)?></td>
                <td class="px-4 py-2">
                  <?php if ($path && file_exists($_SERVER['DOCUMENT_ROOT'].$path)): ?>
                    <img src="<?=htmlspecialchars($path)?>" alt="<?=$iso?>" class="w-6 h-4 object-cover rounded border" loading="lazy">
                  <?php elseif ($path): ?>
                    <span class="text-red-600">No existe</span>
                  <?php else: ?>
                    <span class="text-gray-400">—</span>
                  <?php endif; ?>
                </td>
                <td class="px-4 py-2"><code class="text-xs"><?=htmlspecialchars($path?:'')?></code></td>
                <td class="px-4 py-2">
                  <form method="post" class="flex items-center gap-2">
                    <input type="hidden" name="csrf" value="<?=$csrf?>">
                    <input type="hidden" name="action" value="set_manual">
                    <input type="hidden" name="iso2" value="<?=$iso?>">
                    <input type="text" name="flag_path" value="<?=htmlspecialchars($path?:'')?>" placeholder="/asset/flags/it.png" class="w-64 px-2 py-1 border rounded text-xs">
                    <button class="px-3 py-1 bg-emerald-600 text-white rounded text-xs hover:bg-emerald-700">Guardar</button>
                  </form>
                </td>
              </tr>
              <?php endforeach; else: ?>
              <tr><td colspan="5" class="px-4 py-6 text-center text-gray-500">Sin datos</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="text-xs text-gray-500">
        La API podrá resolver por ISO2 usando <code>countries.iso2</code> y <code>countries.flag_path</code>. Ejemplo: <code>GET /api/country?iso2=IT</code>.
      </div>
    </section>
  </main>
</div>
</body>
</html>
