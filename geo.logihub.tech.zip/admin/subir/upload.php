<?php
/**
 * /admin/subir/upload.php
 * Requisitos:
 *  - Tabla Zonas_global(country_iso2,country_name,region_name,region_code,province_name,province_code,city,postal_code,lat,lng)
 *  - Tabla zones(zona_global_id FK a Zonas_global.id)
 *  - Proc opcional sp_rebuild_zones(); si no existe, se hace rebuild inline.
 */
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_rol'] !== 'admin') {
    http_response_code(401);
    echo json_encode(['ok'=>false,'error'=>'No autorizado']);
    exit;
}
require_once __DIR__ . '/../../config/db.php';

@set_time_limit(0);
@ini_set('memory_limit','1024M');

if (empty($_FILES['zipfile']['tmp_name']) || $_FILES['zipfile']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['ok'=>false,'error'=>'Archivo inválido']);
    exit;
}

/* Guardar y extraer ZIP */
$tmpZip = tempnam(sys_get_temp_dir(), 'zip_');
if (!move_uploaded_file($_FILES['zipfile']['tmp_name'], $tmpZip)) {
    echo json_encode(['ok'=>false,'error'=>'No se pudo mover el ZIP subido']);
    exit;
}
$zip = new ZipArchive();
if ($zip->open($tmpZip) !== TRUE) {
    @unlink($tmpZip);
    echo json_encode(['ok'=>false,'error'=>'No se pudo abrir el ZIP']);
    exit;
}
$extractPath = sys_get_temp_dir() . '/geo_' . uniqid();
mkdir($extractPath, 0777, true);
$zip->extractTo($extractPath);
$zip->close();
@unlink($tmpZip);

/* Utilidades */
function rr_files($dir) {
    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
    foreach ($rii as $file) if ($file->isFile()) yield $file->getPathname();
}
function cleanup_dir($dir) {
    $it = new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS);
    $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
    foreach($files as $file){
        $file->isDir() ? @rmdir($file->getRealPath()) : @unlink($file->getRealPath());
    }
    @rmdir($dir);
}

/* Mapa opcional iso2 -> country_name desde countries.csv si viene en el ZIP */
$countryNameMap = [];
foreach (rr_files($extractPath) as $path) {
    if (preg_match('/countries\.csv$/i', $path)) {
        if (($fh = fopen($path,'r')) !== false) {
            $header = fgetcsv($fh);
            if ($header) {
                $ix = array_change_key_case(array_flip($header), CASE_LOWER);
                while(($row = fgetcsv($fh)) !== false) {
                    $iso2 = isset($ix['iso2']) ? strtoupper(trim($row[$ix['iso2']])) : null;
                    $name = isset($ix['name']) ? trim($row[$ix['name']]) : null;
                    if ($iso2) $countryNameMap[$iso2] = $name ?: null;
                }
            }
            fclose($fh);
        }
    }
}

/* Inserción en Zonas_global */
$insert = $pdo->prepare("
  INSERT IGNORE INTO Zonas_global
  (country_iso2, country_name, region_name, region_code, province_name, province_code, city, postal_code, lat, lng)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

$totalInserted = 0;
$perFile = [];

try {
    foreach (rr_files($extractPath) as $file) {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

        // Saltar countries.csv en este pase (ya se usó para mapear nombres)
        if (preg_match('/countries\.csv$/i', $file)) continue;

        $sep = ($ext === 'csv') ? ',' : "\t"; // .txt => TAB (GeoNames)
        if (($fh = fopen($file,'r')) === false) continue;

        $inserted = 0;
        $pdo->beginTransaction();

        // Detectar si CSV trae cabecera con nombres de columnas tipo Zonas_global
        $header = null; $ix = [];
        if ($sep === ',') {
            $peek = fgetcsv($fh, 0, $sep);
            if ($peek) {
                $lower = array_map(function($v){ return strtolower(trim($v)); }, $peek);
                $known = ['country_iso2','country_name','region_name','region_code','province_name','province_code','city','postal_code','lat','lng'];
                $isHeader = count(array_intersect($lower, $known)) >= 3;
                if ($isHeader) {
                    $header = $lower;
                    $ix = array_flip($header);
                } else {
                    // No era cabecera, procesar esa primera fila como datos
                    $row = $peek;
                    // procesar como CSV universal sin cabecera
                    if (count($row) >= 8) {
                        // Formato universal: postal_code,city,province_code,province_name,region_name,country_iso2,lat,lng[,country_name]
                        $postal_code   = trim($row[0] ?? '');
                        $city          = trim($row[1] ?? '');
                        $province_code = trim($row[2] ?? '');
                        $province_name = trim($row[3] ?? '');
                        $region_name   = trim($row[4] ?? '');
                        $country_iso2  = strtoupper(trim($row[5] ?? ''));
                        $lat           = trim($row[6] ?? '') !== '' ? $row[6] : null;
                        $lng           = trim($row[7] ?? '') !== '' ? $row[7] : null;
                        $country_name  = isset($row[8]) && trim($row[8])!=='' ? trim($row[8]) : ($countryNameMap[$country_iso2] ?? null);
                        if ($country_iso2 && $postal_code && $city) {
                            $insert->execute([$country_iso2,$country_name,$region_name,null,$province_name,$province_code,$city,$postal_code,$lat,$lng]);
                            $inserted++;
                        }
                    }
                }
            }
        }

        // Recorrer archivo
        while(($row = fgetcsv($fh, 0, $sep)) !== false){
            if (!$row) continue;

            if ($sep === "\t") {
                // GeoNames TXT: 12 columnas
                if (count($row) < 12) continue;
                $country_iso2  = strtoupper(trim($row[0] ?? ''));
                $postal_code   = trim($row[1] ?? '');
                $city          = trim($row[2] ?? '');
                $region_name   = trim($row[3] ?? '');
                $region_code   = trim($row[4] ?? '') ?: null;
                $province_name = trim($row[5] ?? '');
                $province_code = trim($row[6] ?? '');
                $lat           = trim($row[9] ?? '') !== '' ? $row[9] : null;
                $lng           = trim($row[10]?? '') !== '' ? $row[10]: null;
                $country_name  = $countryNameMap[$country_iso2] ?? null;

                if ($country_iso2 && $postal_code && $city) {
                    $insert->execute([$country_iso2,$country_name,$region_name,$region_code,$province_name,$province_code,$city,$postal_code,$lat,$lng]);
                    $inserted++;
                }

            } else {
                // CSV
                if ($header) {
                    // Cabecera con nombres de Zonas_global
                    $get = function($k) use ($ix,$row){ return isset($ix[$k]) ? trim($row[$ix[$k]]) : ''; };
                    $country_iso2  = strtoupper($get('country_iso2'));
                    $country_name  = $get('country_name') ?: ($countryNameMap[$country_iso2] ?? null);
                    $region_name   = $get('region_name');
                    $region_code   = $get('region_code') ?: null;
                    $province_name = $get('province_name');
                    $province_code = $get('province_code');
                    $city          = $get('city');
                    $postal_code   = $get('postal_code');
                    $lat           = ($v=$get('lat'))!=='' ? $v : null;
                    $lng           = ($v=$get('lng'))!=='' ? $v : null;

                    if ($country_iso2 && $postal_code && $city) {
                        $insert->execute([$country_iso2,$country_name,$region_name,$region_code,$province_name,$province_code,$city,$postal_code,$lat,$lng]);
                        $inserted++;
                    }
                } else {
                    // CSV universal sin cabecera (ya procesamos la primera si era el caso)
                    if (count($row) < 8) continue;
                    $postal_code   = trim($row[0] ?? '');
                    $city          = trim($row[1] ?? '');
                    $province_code = trim($row[2] ?? '');
                    $province_name = trim($row[3] ?? '');
                    $region_name   = trim($row[4] ?? '');
                    $country_iso2  = strtoupper(trim($row[5] ?? ''));
                    $lat           = trim($row[6] ?? '') !== '' ? $row[6] : null;
                    $lng           = trim($row[7] ?? '') !== '' ? $row[7] : null;
                    $country_name  = isset($row[8]) && trim($row[8])!=='' ? trim($row[8]) : ($countryNameMap[$country_iso2] ?? null);

                    if ($country_iso2 && $postal_code && $city) {
                        $insert->execute([$country_iso2,$country_name,$region_name,null,$province_name,$province_code,$city,$postal_code,$lat,$lng]);
                        $inserted++;
                    }
                }
            }
        }

        $pdo->commit();
        fclose($fh);

        $perFile[] = basename($file).": $inserted filas";
        $totalInserted += $inserted;
    }

    // Reconstruir zones
    try {
        $pdo->exec("CALL sp_rebuild_zones()");
        $rebuildMsg = "zones reconstruido (CALL sp_rebuild_zones).";
    } catch (Throwable $e) {
        // Rebuild inline si no existe el SP
        $pdo->exec("CREATE TEMPORARY TABLE tmp_zones AS
            SELECT MIN(id) AS zona_global_id
            FROM Zonas_global
            GROUP BY country_iso2,
                     COALESCE(region_name,''),
                     COALESCE(province_name,''),
                     COALESCE(province_code,''),
                     COALESCE(city,''),
                     postal_code");
        $pdo->beginTransaction();
        $pdo->exec("DELETE FROM zones");
        $pdo->exec("INSERT INTO zones (zona_global_id) SELECT zona_global_id FROM tmp_zones");
        $pdo->commit();
        $pdo->exec("DROP TEMPORARY TABLE tmp_zones");
        $rebuildMsg = "zones reconstruido inline.";
    }

    cleanup_dir($extractPath);

    echo json_encode([
        'ok'=>true,
        'msg'=>implode('<br>',$perFile) . "<br>Total: $totalInserted filas<br>" . $rebuildMsg
    ]);

} catch (Throwable $ex) {
    cleanup_dir($extractPath);
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'Error al procesar: '.$ex->getMessage()]);
}

