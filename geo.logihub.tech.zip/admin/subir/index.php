<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_rol'] !== 'admin') {
    header('Location: /admin/auth/login/index.php'); exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Subir datos geográficos</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', sans-serif; }
  </style>
</head>
<body class="bg-gray-100 flex min-h-screen">
<?php include __DIR__.'/../../asset/admin/sidebar.php'; ?>
<main class="flex-1 flex flex-col">
  <header class="bg-white shadow p-4">
    <h1 class="text-2xl font-semibold text-gray-800">Subir ZIP de códigos postales (GeoNames TXT)</h1>
  </header>
  <div class="flex-1 overflow-y-auto p-8 bg-gray-50">
    <div class="max-w-lg mx-auto bg-white rounded-xl shadow p-8">
      <form id="uploadForm" enctype="multipart/form-data" class="space-y-6">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Archivo ZIP</label>
          <input type="file" name="zipfile" accept=".zip" required class="block w-full text-sm text-gray-900 border rounded-lg cursor-pointer">
        </div>
        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg px-6 py-3 font-medium w-full transition">Subir y procesar</button>
      </form>
      <div id="result" class="mt-8"></div>
    </div>
  </div>
</main>
<script>
document.getElementById('uploadForm').onsubmit = function(e){
    e.preventDefault();
    const form = e.target;
    const data = new FormData(form);
    document.getElementById('result').innerHTML = 'Procesando...';
    fetch('upload.php', {
        method: 'POST',
        body: data
    })
    .then(r => r.json())
    .then(json => {
        if (json.ok) {
            document.getElementById('result').innerHTML =
                `<div class="bg-green-100 text-green-800 px-4 py-2 rounded">¡Datos cargados correctamente!<br>${json.msg}</div>`;
        } else {
            document.getElementById('result').innerHTML =
                `<div class="bg-red-100 text-red-800 px-4 py-2 rounded">Error: ${json.error}</div>`;
        }
    })
    .catch(err => {
        document.getElementById('result').innerHTML =
            `<div class="bg-red-100 text-red-800 px-4 py-2 rounded">Error de red.</div>`;
    });
};
</script>
</body>
</html>
