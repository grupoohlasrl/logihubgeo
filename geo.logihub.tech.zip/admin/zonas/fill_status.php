<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
  if (!isset($_SESSION['user_id']) || ($_SESSION['user_rol'] ?? '') !== 'admin') {
    echo json_encode(['ok'=>false,'error'=>'No autorizado']); exit;
  }
  require_once __DIR__ . '/../../config/db.php';

  $db = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
  $st = $pdo->prepare("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_SCHEMA=? AND TABLE_NAME IN ('Zonas_global','zonas_global') LIMIT 1");
  $st->execute([$db]);
  $ZG = $st->fetchColumn() ?: 'Zonas_global';

  $country = strtoupper(trim($_GET['country'] ?? ''));
  if ($country==='' || strlen($country)!==2) { echo json_encode(['ok'=>false,'error'=>'country inválido']); exit; }

  $jobCounts = [];
  foreach (['pending','running','done','error','not_found'] as $s) {
    $q = $pdo->prepare("SELECT COUNT(*) FROM zipcode_jobs WHERE country_iso2=? AND status=?");
    $q->execute([$country,$s]); $jobCounts[$s]=(int)$q->fetchColumn();
  }

  $q1=$pdo->prepare("SELECT COUNT(*) FROM `$ZG` WHERE country_iso2=? AND (postal_code IS NULL OR postal_code='')");
  $q1->execute([$country]); $missing_zip=(int)$q1->fetchColumn();
  $q2=$pdo->prepare("SELECT COUNT(*) FROM `$ZG` WHERE country_iso2=? AND postal_code<>'' AND (lat IS NULL OR lng IS NULL)");
  $q2->execute([$country]); $missing_ll=(int)$q2->fetchColumn();

  $progress=null;
  if (class_exists('Redis')) {
    try {
      $r=new Redis();
      $host=getenv('REDIS_HOST')?:'127.0.0.1'; $port=(int)(getenv('REDIS_PORT')?:6379); $pass=getenv('REDIS_PASSWORD')?:null;
      $r->connect($host,$port,1.0); if($pass)$r->auth($pass); if($d=getenv('REDIS_DB'))$r->select((int)$d);
      $progress=$r->get('cron:zipcode:progress'); if($progress){ $progress=json_decode($progress,true); }
    } catch(Throwable $e){ $progress=null; }
  }

  echo json_encode(['ok'=>true,'country'=>$country,'counts'=>[
    'jobs'=>$jobCounts,'zg_missing_zip'=>$missing_zip,'zg_missing_latlng'=>$missing_ll
  ],'progress'=>$progress]);
} catch (Throwable $e) {
  echo json_encode(['ok'=>false,'error'=>'SERVER_ERROR','detail'=>substr($e->getMessage(),0,200)]);
}
