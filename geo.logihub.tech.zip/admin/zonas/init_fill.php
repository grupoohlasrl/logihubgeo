<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
  if (!isset($_SESSION['user_id']) || ($_SESSION['user_rol'] ?? '') !== 'admin') {
    echo json_encode(['ok'=>false,'error'=>'No autorizado']); exit;
  }
  require_once __DIR__ . '/../../config/db.php';

  $country = strtoupper(trim($_POST['country'] ?? ''));
  $mode    = strtolower(trim($_POST['mode'] ?? 'zip'));   // zip | latlng
  $force   = (int)($_POST['force'] ?? 0);                 // 0|1
  if ($country==='' || strlen($country)!==2) { echo json_encode(['ok'=>false,'error'=>'country inválido']); exit; }
  if (!in_array($mode,['zip','latlng'],true)) { echo json_encode(['ok'=>false,'error'=>'mode inválido']); exit; }

  $db = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
  $st = $pdo->prepare("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_SCHEMA=? AND TABLE_NAME IN ('Zonas_global','zonas_global') LIMIT 1");
  $st->execute([$db]);
  $ZG = $st->fetchColumn() ?: 'Zonas_global';

  if ($mode==='zip') {
    // force=1 ignora si ya hay postal_code
    $sql = "
      INSERT IGNORE INTO zipcode_jobs (country_iso2, city_name, job_type)
      SELECT ?, city, 'city_to_zip' FROM `$ZG`
      WHERE country_iso2=?
        AND city IS NOT NULL AND city<>'' ".
        ($force ? "" : "AND (postal_code IS NULL OR postal_code='')")."
      GROUP BY city
    ";
    $ins=$pdo->prepare($sql); $ins->execute([$country,$country]);
  } else {
    $sql = "
      INSERT IGNORE INTO zipcode_jobs (country_iso2, zip_code, job_type)
      SELECT ?, postal_code, 'code_to_location' FROM `$ZG`
      WHERE country_iso2=?
        AND postal_code<>'' ".
        ($force ? "" : "AND (lat IS NULL OR lng IS NULL)")."
      GROUP BY postal_code
    ";
    $ins=$pdo->prepare($sql); $ins->execute([$country,$country]);
  }

  echo json_encode(['ok'=>true,'enqueued'=>$ins->rowCount(),'country'=>$country,'mode'=>$mode,'force'=>$force]);
} catch (Throwable $e) {
  echo json_encode(['ok'=>false,'error'=>'SERVER_ERROR','detail'=>substr($e->getMessage(),0,200)]);
}
