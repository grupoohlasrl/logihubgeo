<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
ini_set('display_errors','0');
error_reporting(E_ALL);

try {
    if (!isset($_SESSION['user_id']) || ($_SESSION['user_rol'] ?? '') !== 'admin') {
        echo json_encode(['ok'=>false,'error'=>'No autorizado']); exit;
    }
    require_once __DIR__ . '/../../config/db.php';

    // Detecta nombre real de tabla (case-sensitive en Linux)
    $dbName = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
    $st = $pdo->prepare("
        SELECT TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME IN ('Zonas_global','zonas_global')
        LIMIT 1
    ");
    $st->execute([$dbName]);
    $ZG = $st->fetchColumn() ?: 'Zonas_global'; // fallback

    $country = strtoupper(trim($_GET['country'] ?? ''));
    $q       = trim($_GET['q'] ?? '');
    $sort    = trim($_GET['sort'] ?? 'city');
    $page    = max(1, (int)($_GET['page'] ?? 1));
    $per     = min(200, max(1, (int)($_GET['per_page'] ?? 50)));
    $off     = ($page-1)*$per;

    if ($country === '') {
        echo json_encode(['ok'=>true,'items'=>[],'total'=>0,'page'=>1,'pages'=>1]); exit;
    }

    // Map seguro para ORDER BY
    $sortMap = [
        'city'          => 'zg.city',
        'postal_code'   => 'zg.postal_code',
        'province_name' => 'zg.province_name',
        'region_name'   => 'zg.region_name',
    ];
    $orderBy = $sortMap[$sort] ?? 'zg.city';

    $where  = "WHERE zg.country_iso2 = :iso";
    $params = [':iso'=>$country];
    if ($q !== '') {
        $where .= " AND (zg.city LIKE :q OR zg.postal_code LIKE :q)";
        $params[':q'] = "%$q%";
    }

    // Total
    $sqlCount = "SELECT COUNT(*) FROM `$ZG` zg $where";
    $st = $pdo->prepare($sqlCount);
    foreach($params as $k=>$v) $st->bindValue($k, $v);
    $st->execute();
    $total = (int)$st->fetchColumn();

    // Paginado
    $sqlItems = "
      SELECT
        zg.country_iso2,
        COALESCE(NULLIF(zg.country_name,''), zg.country_iso2) AS country_name,
        zg.region_name,  zg.region_code,
        zg.province_name,zg.province_code,
        zg.city, zg.postal_code, zg.lat, zg.lng
      FROM `$ZG` zg
      $where
      ORDER BY $orderBy
      LIMIT :lim OFFSET :off
    ";
    $st = $pdo->prepare($sqlItems);
    foreach($params as $k=>$v) $st->bindValue($k, $v);
    $st->bindValue(':lim', (int)$per, PDO::PARAM_INT);
    $st->bindValue(':off', (int)$off, PDO::PARAM_INT);
    $st->execute();
    $items = $st->fetchAll(PDO::FETCH_ASSOC);

    $pages = max(1, (int)ceil($total / $per));
    echo json_encode(['ok'=>true,'items'=>$items,'total'=>$total,'page'=>$page,'pages'=>$pages]);

} catch (Throwable $e) {
    echo json_encode(['ok'=>false,'error'=>'SERVER_ERROR','detail'=>substr($e->getMessage(),0,300)]);
}
