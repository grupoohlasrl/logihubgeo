<?php
declare(strict_types=1);
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['user_rol'] ?? '') !== 'admin') {
    header('Location: /admin/auth/login/index.php'); exit;
}
require_once __DIR__ . '/../../config/db.php';

/* Detecta nombre real de la tabla plana */
$dbName = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
$st = $pdo->prepare("
  SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
  WHERE TABLE_SCHEMA = ? AND TABLE_NAME IN ('Zonas_global','zonas_global') LIMIT 1
");
$st->execute([$dbName]);
$ZG = $st->fetchColumn() ?: 'Zonas_global';

/* Países para el selector */
$stmt = $pdo->query("
  SELECT country_iso2, COALESCE(NULLIF(country_name,''), country_iso2) AS country_name
  FROM `$ZG`
  WHERE country_iso2 IS NOT NULL AND country_iso2 <> ''
  GROUP BY country_iso2, country_name
  ORDER BY country_name
");
$countries = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* Datos de cron */
$row = $pdo->query("SELECT cron_token FROM config_global WHERE provider='zipcodebase' AND active=1 LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: [];
$cronToken = (string)($row['cron_token'] ?? '');

/* Estado del cron: running por lock en Redis o fallback MySQL */
$cronRunning = null;
$cronLastTs  = null;
if (class_exists('Redis')) {
    try {
        $r = new Redis();
        if (getenv('REDIS_URL')) {
            $u = parse_url(getenv('REDIS_URL'));
            $host=$u['host']??'127.0.0.1'; $port=(int)($u['port']??6379); $pass=$u['pass']??null; $dbi=isset($u['path'])?(int)trim($u['path'],'/'):0;
            $r->connect($host,$port,1.0);
            if($pass) $r->auth($pass);
            if($dbi)  $r->select($dbi);
        } else {
            $host=getenv('REDIS_HOST')?:'127.0.0.1'; $port=(int)(getenv('REDIS_PORT')?:6379); $pass=getenv('REDIS_PASSWORD')?:null;
            $r->connect($host,$port,1.0);
            if($pass) $r->auth($pass);
            if($d=getenv('REDIS_DB')) $r->select((int)$d);
        }
        $cronRunning = (bool)$r->exists('cron:zipcode:lock');
        $prog = $r->get('cron:zipcode:progress');
        if ($prog) {
            $pj = json_decode($prog,true);
            $cronLastTs = is_array($pj) && !empty($pj['ts']) ? (string)$pj['ts'] : null;
        }
    } catch (Throwable $e) { $cronRunning = null; }
}
if ($cronRunning === null) {
    try {
        $isFree = $pdo->query("SELECT IS_FREE_LOCK('cron:zipcode:lock')")->fetchColumn();
        if ($isFree !== false) $cronRunning = ((int)$isFree === 0); // 0=usado -> running
    } catch (Throwable $e) { $cronRunning = false; }
}

/* URL base del cron (no se llama desde el cliente; solo referencia) */
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on') ? 'https' : 'http';
$origin = $scheme.'://'.$_SERVER['HTTP_HOST'];
$cronUrlTpl = $cronToken ? ($origin.'/cron/zipcode/?token='.rawurlencode($cronToken).'&country={ISO2}&batch=25&max_ms=25000&auto_enqueue=1') : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Zonas - GeologiHub</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>body{font-family:'Inter',sans-serif}</style>
</head>
<body class="bg-gray-100 flex min-h-screen">
  <?php include __DIR__ . '/../../asset/admin/sidebar.php'; ?>
  <main class="flex-1 flex flex-col">
    <header class="bg-white shadow p-4">
      <h1 class="text-2xl font-semibold text-gray-800">Zonas</h1>
    </header>

    <div class="p-6">
      <!-- Filtros -->
      <div class="bg-white rounded-xl shadow p-4 mb-6">
        <form id="filterForm" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div>
            <label class="block text-sm text-gray-700 mb-1">País (ISO2)</label>
            <select id="country" name="country" required class="w-full border rounded-lg px-3 py-2">
              <option value="">Selecciona país</option>
              <?php foreach ($countries as $c): ?>
                <option value="<?= htmlspecialchars($c['country_iso2']) ?>">
                  <?= htmlspecialchars($c['country_name']) ?> (<?= htmlspecialchars($c['country_iso2']) ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="block text-sm text-gray-700 mb-1">Buscar (Ciudad o ZIP)</label>
            <input id="q" name="q" type="text" placeholder="Roma o 00100" class="w-full border rounded-lg px-3 py-2">
          </div>
          <div>
            <label class="block text-sm text-gray-700 mb-1">Orden</label>
            <select id="sort" name="sort" class="w-full border rounded-lg px-3 py-2">
              <option value="city">Ciudad</option>
              <option value="postal_code">ZIP</option>
              <option value="province_name">Provincia</option>
              <option value="region_name">Región</option>
            </select>
          </div>
          <div class="flex gap-2">
            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg px-4 py-2">Buscar</button>
            <button type="button" id="resetBtn" class="border rounded-lg px-4 py-2">Reset</button>
          </div>
        </form>
      </div>

      <!-- Autocompletado ZIP -->
      <div class="bg-white rounded-xl shadow p-4 mb-6">
        <div class="flex flex-wrap items-center gap-3">
          <button id="startFill" class="border px-3 py-2 rounded">Iniciar autocompletado</button>
          <button id="runNow"   class="border px-3 py-2 rounded">Ejecutar un ciclo ahora</button>
          <button id="refreshSt" class="border px-3 py-2 rounded">Refrescar estado</button>
          <span id="statusMsg" class="text-sm text-gray-600"></span>
        </div>
        <div class="mt-3 text-xs text-gray-600">
          Cron: <b id="cronState"><?= $cronRunning ? 'ejecutándose' : 'inactivo' ?></b>
          · Último ciclo: <b id="cronLast"><?= $cronLastTs ? htmlspecialchars($cronLastTs) : '-' ?></b>
          · Frecuencia: <b id="cronFreq">5–15 min</b>
          <?php if ($cronUrlTpl): ?>
            <div class="mt-1">URL cron (plantilla): <code class="select-all"><?= htmlspecialchars(str_replace('{ISO2}','DO',$cronUrlTpl)) ?></code></div>
          <?php endif; ?>
        </div>
        <div id="statusBox" class="mt-3 grid grid-cols-2 md:grid-cols-6 gap-3 text-sm">
          <div class="p-2 bg-gray-50 rounded">pending: <b id="stPending">0</b></div>
          <div class="p-2 bg-gray-50 rounded">running: <b id="stRunning">0</b></div>
          <div class="p-2 bg-gray-50 rounded">done: <b id="stDone">0</b></div>
          <div class="p-2 bg-gray-50 rounded">error: <b id="stError">0</b></div>
          <div class="p-2 bg-gray-50 rounded">not_found: <b id="stNF">0</b></div>
          <div class="p-2 bg-gray-50 rounded">ZG sin ZIP: <b id="stMissZip">0</b></div>
          <div class="p-2 bg-gray-50 rounded">ZG sin LAT/LNG: <b id="stMissLL">0</b></div>
          <div class="p-2 bg-gray-50 rounded col-span-2 md:col-span-4">último: <span id="stProgress">-</span></div>
        </div>
      </div>

      <!-- Tabla -->
      <div class="bg-white rounded-xl shadow overflow-hidden">
        <div class="overflow-x-auto">
          <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-gray-50 text-xs uppercase">
              <tr>
                <th class="px-4 py-3 text-left">País</th>
                <th class="px-4 py-3 text-left">Región</th>
                <th class="px-4 py-3 text-left">Provincia</th>
                <th class="px-4 py-3 text-left">Ciudad</th>
                <th class="px-4 py-3 text-left">ZIP</th>
                <th class="px-4 py-3 text-left">Lat</th>
                <th class="px-4 py-3 text-left">Lng</th>
              </tr>
            </thead>
            <tbody id="rows"></tbody>
          </table>
        </div>
        <div class="p-4 flex items-center justify-between border-t">
          <div id="total" class="text-sm text-gray-600">0 resultados</div>
          <div class="flex items-center gap-2">
            <button id="prev" class="px-3 py-1 border rounded disabled:opacity-50" disabled>Anterior</button>
            <span id="pageInfo" class="text-sm"></span>
            <button id="next" class="px-3 py-1 border rounded disabled:opacity-50" disabled>Siguiente</button>
          </div>
        </div>
      </div>
    </div>
  </main>

<script>
const rows = document.getElementById('rows');
const total = document.getElementById('total');
const prev  = document.getElementById('prev');
const next  = document.getElementById('next');
const pageInfo = document.getElementById('pageInfo');
const form = document.getElementById('filterForm');
const resetBtn = document.getElementById('resetBtn');
const countrySel = document.getElementById('country');
const qInput = document.getElementById('q');

let page = 1;
const per_page = 50;
let debounceTimer = null;

/* ---- Panel de estado ---- */
const statusMsg = document.getElementById('statusMsg');
const stPending = document.getElementById('stPending');
const stRunning = document.getElementById('stRunning');
const stDone    = document.getElementById('stDone');
const stError   = document.getElementById('stError');
const stNF      = document.getElementById('stNF');
const stMissZip = document.getElementById('stMissZip');
const stMissLL  = document.getElementById('stMissLL');
const stProgress= document.getElementById('stProgress');
const cronLast  = document.getElementById('cronLast');

async function fetchStatus() {
  const country = countrySel.value;
  if(!country) return;
  const r = await fetch('fill_status.php?country='+encodeURIComponent(country), {credentials:'same-origin', cache:'no-store'});
  const j = await r.json();
  if(!j.ok){ statusMsg.textContent = j.error||'Error'; return; }
  stPending.textContent = j.counts.jobs.pending;
  stRunning.textContent = j.counts.jobs.running;
  stDone.textContent    = j.counts.jobs.done;
  stError.textContent   = j.counts.jobs.error;
  stNF.textContent      = j.counts.jobs.not_found;
  stMissZip.textContent = j.counts.zg_missing_zip;
  stMissLL.textContent  = j.counts.zg_missing_latlng;
  if (j.progress) {
    stProgress.textContent = `ts ${j.progress.ts} | processed=${j.progress.done} not_found=${j.progress.not_found} errors=${j.progress.errors}`;
    if (cronLast) cronLast.textContent = j.progress.ts;
  } else {
    stProgress.textContent = '-';
  }
}

/* ---- Tabla de zonas ---- */
function fetchData() {
  const params = new URLSearchParams(new FormData(form));
  params.set('page', page);
  params.set('per_page', per_page);

  if (!countrySel.value) {
    rows.innerHTML = `<tr><td colspan="7" class="px-4 py-6 text-center text-gray-500">Selecciona un país</td></tr>`;
    total.textContent = '0 resultados';
    prev.disabled = true; next.disabled = true; pageInfo.textContent = '';
    return;
  }

  rows.innerHTML = `<tr><td colspan="7" class="px-4 py-6 text-center text-gray-500">Cargando...</td></tr>`;

  fetch('search.php?' + params.toString(), {credentials: 'same-origin'})
    .then(r => r.text())
    .then(t => {
      let data;
      try { data = JSON.parse(t); }
      catch { throw new Error('Respuesta no válida'); }
      if (!data.ok) throw new Error(data.error || 'Error');
      render(data);
    })
    .catch(err => {
      rows.innerHTML = `<tr><td colspan="7" class="px-4 py-6 text-center text-red-600">${escapeHtml(err.message||'Error')}</td></tr>`;
      total.textContent = '0 resultados';
      prev.disabled = true; next.disabled = true; pageInfo.textContent = '';
      console.error('search.php response:', err);
    });
}

function render(data){
  const items = data.items || [];
  if (items.length === 0) {
    rows.innerHTML = `<tr><td colspan="7" class="px-4 py-6 text-center text-gray-500">Sin resultados</td></tr>`;
  } else {
    rows.innerHTML = items.map(x => `
      <tr class="border-t">
        <td class="px-4 py-2">${escapeHtml(x.country_name || x.country_iso2)} (${escapeHtml(x.country_iso2)})</td>
        <td class="px-4 py-2">${escapeHtml(x.region_name || '')}</td>
        <td class="px-4 py-2">${escapeHtml(x.province_name || '')} ${x.province_code ? '('+escapeHtml(x.province_code)+')' : ''}</td>
        <td class="px-4 py-2">${escapeHtml(x.city || '')}</td>
        <td class="px-4 py-2 font-medium">${escapeHtml(x.postal_code)}</td>
        <td class="px-4 py-2">${x.lat ?? ''}</td>
        <td class="px-4 py-2">${x.lng ?? ''}</td>
      </tr>
    `).join('');
  }
  total.textContent = `${data.total} resultados`;
  pageInfo.textContent = `Página ${data.page} de ${data.pages}`;
  prev.disabled = data.page <= 1;
  next.disabled = data.page >= data.pages;
}

function escapeHtml(s){
  return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

/* ---- Eventos ---- */
form.addEventListener('submit', e => { e.preventDefault(); page = 1; fetchData(); fetchStatus(); });
resetBtn.addEventListener('click', () => {
  form.reset(); page = 1; rows.innerHTML=''; total.textContent='0 resultados'; pageInfo.textContent=''; prev.disabled=true; next.disabled=true;
});
prev.addEventListener('click', () => { if (page>1){ page--; fetchData(); }});
next.addEventListener('click', () => { page++; fetchData(); });

countrySel.addEventListener('change', () => { page = 1; fetchData(); fetchStatus(); });
qInput.addEventListener('input', () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => { page = 1; fetchData(); }, 300);
});

/* ---- Botones autocompletado ---- */
document.getElementById('startFill').addEventListener('click', async () => {
  const country = countrySel.value;
  if(!country){ alert('Selecciona país'); return; }
  const fd = new FormData(); fd.append('country', country);
  const r = await fetch('init_fill.php', {method:'POST', body:fd, credentials:'same-origin'});
  const j = await r.json();
  if(!j.ok){ alert(j.error||'Error'); return; }
  statusMsg.textContent = `Encoladas ${j.enqueued} ciudades`;
  fetchStatus();
});

document.getElementById('runNow').addEventListener('click', async () => {
  const country = countrySel.value;
  if(!country){ alert('Selecciona país'); return; }
  const fd = new FormData();
  fd.append('country', country);
  fd.append('batch', '25');
  fd.append('max_ms', '25000');
  fd.append('auto_enqueue', '1');
  statusMsg.textContent = 'Ejecutando...';
  const r = await fetch('run_fill.php', {method:'POST', body:fd, credentials:'same-origin'});
  const j = await r.json();
  statusMsg.textContent = j.ok ? (j.stdout || 'OK') : (j.error||'Error');
  fetchStatus();
});

document.getElementById('refreshSt').addEventListener('click', () => { fetchStatus(); });

/* Cargas iniciales + refresco periódico */
setInterval(fetchStatus, 10000);
// if quieres, autoselecciona primer país al entrar:
// if (!countrySel.value && countrySel.options.length > 1) { countrySel.selectedIndex = 1; fetchData(); fetchStatus(); }
</script>
</body>
</html>
