<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
  if (!isset($_SESSION['user_id']) || ($_SESSION['user_rol'] ?? '') !== 'admin') {
    echo json_encode(['ok'=>false,'error'=>'No autorizado']); exit;
  }
  require_once __DIR__ . '/../../config/db.php';

  $country = strtoupper(trim($_POST['country'] ?? ''));
  $batch   = max(1, min(100, (int)($_POST['batch'] ?? 25)));
  $max_ms  = max(1000, min(55000, (int)($_POST['max_ms'] ?? 25000)));
  $auto    = (int)($_POST['auto_enqueue'] ?? 0);
  if ($country!=='' && strlen($country)!==2) { echo json_encode(['ok'=>false,'error'=>'country inválido']); exit; }

  $row=$pdo->query("SELECT cron_token FROM config_global WHERE provider='zipcodebase' AND active=1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
  if(!$row || empty($row['cron_token'])){ echo json_encode(['ok'=>false,'error'=>'cron_token no configurado']); exit; }
  $token=$row['cron_token'];

  $scheme=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on')?'https':'http';
  $origin=$scheme.'://'.$_SERVER['HTTP_HOST'];
  $qs=http_build_query(['token'=>$token,'country'=>$country?:null,'batch'=>$batch,'max_ms'=>$max_ms,'auto_enqueue'=>$auto],'','&',PHP_QUERY_RFC3986);
  $url=$origin.'/cron/zipcode/?'.$qs;

  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=ceil(($max_ms+3000)/1000),CURLOPT_FAILONERROR=>false,CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_SSL_VERIFYHOST=>false]);
  $out=curl_exec($ch); $err=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); curl_close($ch);

  if($out===false){ echo json_encode(['ok'=>false,'error'=>$err?:'curl']); exit; }
  if($code>=400){ echo json_encode(['ok'=>false,'error'=>"HTTP $code",'detail'=>$out]); exit; }

  preg_match_all('/(\w+)=(\d+)/',$out,$m);
  $metrics=[]; if($m && isset($m[1],$m[2])){ for($i=0;$i<count($m[1]);$i++) $metrics[$m[1][$i]]=(int)$m[2][$i]; }

  echo json_encode(['ok'=>true,'stdout'=>trim($out),'metrics'=>$metrics]);
} catch (Throwable $e) {
  echo json_encode(['ok'=>false,'error'=>'SERVER_ERROR','detail'=>substr($e->getMessage(),0,200)]);
}
