<?php
// /admin/api/index.php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_rol'] !== 'admin') {
  header('Location: /admin/auth/login/index.php'); exit;
}
require_once __DIR__ . '/../../config/db.php';

function json_out($arr) {
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($arr);
  exit;
}

// Helpers
function generate_plain_token(): string {
  // "LOGEO" + 12 dígitos
  $n = str_pad((string)random_int(0, 999999999999), 12, '0', STR_PAD_LEFT);
  return 'LOGEO' . $n;
}
function unique_token_pair(PDO $pdo): array {
  // Garante hash único en BD
  while (true) {
    $plain = generate_plain_token();
    $hash  = hash('sha256', $plain);
    $q = $pdo->prepare('SELECT 1 FROM api_tokens WHERE token_hash=? LIMIT 1');
    $q->execute([$hash]);
    if (!$q->fetch()) return [$plain, $hash];
  }
}

// AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
  $action = $_POST['action'];

  if ($action === 'list') {
    // Listado con paginación
    $page = max(1, (int)($_POST['page'] ?? 1));
    $per  = min(100, max(10, (int)($_POST['per_page'] ?? 25)));
    $off  = ($page - 1) * $per;

    // Filtros opcionales
    $uid = isset($_POST['usuario_id']) && $_POST['usuario_id'] !== '' ? (int)$_POST['usuario_id'] : null;
    $where = [];
    $args  = [];
    if ($uid) { $where[] = 't.usuario_id = ?'; $args[] = $uid; }
    $wsql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

    $stmt = $pdo->prepare("
      SELECT COUNT(*) FROM api_tokens t $wsql
    ");
    $stmt->execute($args);
    $total = (int)$stmt->fetchColumn();

    $stmt = $pdo->prepare("
      SELECT t.id, t.usuario_id, u.name, u.email, t.label, t.active, t.created_at
      FROM api_tokens t
      JOIN users u ON u.id = t.usuario_id
      $wsql
      ORDER BY t.created_at DESC
      LIMIT $per OFFSET $off
    ");
    $stmt->execute($args);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    json_out(['ok'=>true, 'items'=>$items, 'total'=>$total, 'page'=>$page, 'pages'=>max(1, (int)ceil($total/$per))]);
  }

  if ($action === 'create') {
    $usuario_id = (int)($_POST['usuario_id'] ?? 0);
    $label = trim((string)($_POST['label'] ?? ''));

    if (!$usuario_id) json_out(['ok'=>false,'error'=>'usuario_id requerido']);

    // Verifica usuario existe y activo
    $st = $pdo->prepare('SELECT id, status FROM users WHERE id=? LIMIT 1');
    $st->execute([$usuario_id]);
    $u = $st->fetch(PDO::FETCH_ASSOC);
    if (!$u) json_out(['ok'=>false,'error'=>'Usuario no existe']);
    if ($u['status'] !== 'active') json_out(['ok'=>false,'error'=>'Usuario no activo']);

    // Un token ACTIVO por usuario
    $st = $pdo->prepare('SELECT id FROM api_tokens WHERE usuario_id=? AND active=1 LIMIT 1');
    $st->execute([$usuario_id]);
    if ($st->fetch()) json_out(['ok'=>false,'error'=>'El usuario ya tiene un token activo']);

    // Genera par visible/hash único
    [$plain, $hash] = unique_token_pair($pdo);

    $st = $pdo->prepare('INSERT INTO api_tokens (usuario_id, token_hash, label, active) VALUES (?,?,?,1)');
    $st->execute([$usuario_id, $hash, $label ?: null]);

    json_out(['ok'=>true, 'token'=>$plain, 'token_note'=>'Guárdalo ahora. No se mostrará otra vez.']);
  }

  if ($action === 'toggle') {
    $id = (int)($_POST['id'] ?? 0);
    $active = (int)($_POST['active'] ?? 0);

    // Si se va a activar, aseguremos unicidad por usuario
    $st = $pdo->prepare('SELECT usuario_id FROM api_tokens WHERE id=?');
    $st->execute([$id]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) json_out(['ok'=>false,'error'=>'Token no encontrado']);

    if ($active) {
      $st = $pdo->prepare('SELECT id FROM api_tokens WHERE usuario_id=? AND active=1 AND id<>? LIMIT 1');
      $st->execute([$row['usuario_id'], $id]);
      if ($st->fetch()) json_out(['ok'=>false,'error'=>'Ese usuario ya tiene un token activo']);
    }

    $st = $pdo->prepare('UPDATE api_tokens SET active=? WHERE id=?');
    $st->execute([$active, $id]);
    json_out(['ok'=>true]);
  }

  if ($action === 'stats') {
    // Stats por usuario: plan + uso del mes
    $usuario_id = (int)($_POST['usuario_id'] ?? 0);
    if (!$usuario_id) json_out(['ok'=>false,'error'=>'usuario_id requerido']);

    // Plan activo
    $st = $pdo->prepare("
      SELECT p.code, p.name, p.monthly_calls, p.rpm_limit
      FROM subscriptions s
      JOIN plans p ON p.id = s.plan_id
      WHERE s.usuario_id=? AND s.status='active'
      ORDER BY s.id DESC LIMIT 1
    ");
    $st->execute([$usuario_id]);
    $plan = $st->fetch(PDO::FETCH_ASSOC) ?: null;

    // Uso mes actual
    $first = date('Y-m-01');
    $last  = date('Y-m-t');
    $st = $pdo->prepare('SELECT COALESCE(SUM(calls),0) FROM usage_daily WHERE usuario_id=? AND day BETWEEN ? AND ?');
    $st->execute([$usuario_id, $first, $last]);
    $month_calls = (int)$st->fetchColumn();

    json_out(['ok'=>true, 'plan'=>$plan, 'month_calls'=>$month_calls, 'period'=>[$first,$last]]);
  }

  json_out(['ok'=>false,'error'=>'Acción inválida']);
}

// Datos para HTML
$users = $pdo->query("SELECT id, name, email FROM users ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>API Tokens - GeologiHub</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>body{font-family:'Inter',sans-serif}</style>
</head>
<body class="bg-gray-100 flex min-h-screen">
  <?php include __DIR__ . '/../../asset/admin/sidebar.php'; ?>
  <main class="flex-1 flex flex-col">
    <header class="bg-white shadow p-4">
      <h1 class="text-2xl font-semibold text-gray-800">API Tokens</h1>
    </header>

    <div class="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Crear token -->
      <section class="bg-white rounded-xl shadow p-5">
        <h2 class="text-lg font-semibold mb-4">Crear token</h2>
        <form id="createForm" class="space-y-4">
          <div>
            <label class="block text-sm text-gray-700 mb-1">Usuario</label>
            <select name="usuario_id" id="usuario_id" required class="w-full border rounded-lg px-3 py-2">
              <option value="">Selecciona usuario</option>
              <?php foreach ($users as $u): ?>
                <option value="<?= (int)$u['id'] ?>"><?= htmlspecialchars($u['name']) ?> (<?= htmlspecialchars($u['email'] ?? '') ?>)</option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="block text-sm text-gray-700 mb-1">Etiqueta (opcional)</label>
            <input type="text" name="label" class="w-full border rounded-lg px-3 py-2" placeholder="Servidor prod, CI, etc.">
          </div>
          <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg px-4 py-2">Generar</button>
        </form>

        <div id="tokenBox" class="hidden mt-4 border rounded-lg p-3 bg-gray-50">
          <div class="text-sm text-gray-600 mb-1">Token generado (visible una sola vez):</div>
          <code id="plainToken" class="block text-lg font-mono"></code>
          <button id="copyBtn" class="mt-2 text-xs px-2 py-1 border rounded">Copiar</button>
        </div>

        <div class="mt-6">
          <h3 class="text-sm font-semibold text-gray-700 mb-2">Plan y uso del mes</h3>
          <div id="planBox" class="text-sm text-gray-700">Selecciona un usuario para ver límites.</div>
        </div>
      </section>

      <!-- Lista -->
      <section class="lg:col-span-2 bg-white rounded-xl shadow p-5">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-lg font-semibold">Tokens existentes</h2>
          <div>
            <label class="text-sm mr-2">Filtrar por usuario</label>
            <select id="filterUser" class="border rounded px-2 py-1">
              <option value="">Todos</option>
              <?php foreach ($users as $u): ?>
                <option value="<?= (int)$u['id'] ?>"><?= htmlspecialchars($u['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-gray-50 text-xs uppercase text-gray-700">
              <tr>
                <th class="px-3 py-2 text-left">Usuario</th>
                <th class="px-3 py-2 text-left">Etiqueta</th>
                <th class="px-3 py-2 text-left">Estado</th>
                <th class="px-3 py-2 text-left">Creado</th>
                <th class="px-3 py-2 text-left">Acciones</th>
              </tr>
            </thead>
            <tbody id="rows"></tbody>
          </table>
        </div>
        <div class="mt-3 flex items-center justify-between">
          <div id="total" class="text-sm text-gray-600">0 resultados</div>
          <div class="flex gap-2">
            <button id="prev" class="px-3 py-1 border rounded disabled:opacity-50" disabled>Anterior</button>
            <span id="pageInfo" class="text-sm"></span>
            <button id="next" class="px-3 py-1 border rounded disabled:opacity-50" disabled>Siguiente</button>
          </div>
        </div>
      </section>
    </div>
  </main>

<script>
const cf = document.getElementById('createForm');
const usuarioSel = document.getElementById('usuario_id');
const tokenBox = document.getElementById('tokenBox');
const plainToken = document.getElementById('plainToken');
const copyBtn = document.getElementById('copyBtn');

const rows = document.getElementById('rows');
const total = document.getElementById('total');
const prev  = document.getElementById('prev');
const next  = document.getElementById('next');
const pageInfo = document.getElementById('pageInfo');
const filterUser = document.getElementById('filterUser');
let page = 1, per_page = 25;

function escapeHtml(s){
  return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

function listTokens(){
  rows.innerHTML = `<tr><td colspan="5" class="px-3 py-4 text-center text-gray-500">Cargando...</td></tr>`;
  const fd = new FormData();
  fd.append('action','list');
  fd.append('page',page);
  fd.append('per_page',per_page);
  if (filterUser.value) fd.append('usuario_id', filterUser.value);

  fetch('index.php', {method:'POST', body:fd, credentials:'same-origin'})
    .then(r=>r.json())
    .then(data=>{
      if(!data.ok) throw new Error(data.error||'Error');
      renderList(data);
    })
    .catch(err=>{
      rows.innerHTML = `<tr><td colspan="5" class="px-3 py-4 text-center text-red-600">${escapeHtml(err.message)}</td></tr>`;
      total.textContent='0 resultados'; pageInfo.textContent=''; prev.disabled=true; next.disabled=true;
    });
}

function renderList(data){
  const items = data.items || [];
  if (items.length===0) {
    rows.innerHTML = `<tr><td colspan="5" class="px-3 py-4 text-center text-gray-500">Sin resultados</td></tr>`;
  } else {
    rows.innerHTML = items.map(x=>`
      <tr class="border-t">
        <td class="px-3 py-2">${escapeHtml(x.name)}<br><span class="text-xs text-gray-500">${escapeHtml(x.email||'')}</span></td>
        <td class="px-3 py-2">${escapeHtml(x.label||'')}</td>
        <td class="px-3 py-2">
          ${x.active ? '<span class="text-green-700 bg-green-100 text-xs px-2 py-0.5 rounded-full">Activo</span>'
                     : '<span class="text-gray-700 bg-gray-200 text-xs px-2 py-0.5 rounded-full">Inactivo</span>'}
        </td>
        <td class="px-3 py-2">${escapeHtml(x.created_at)}</td>
        <td class="px-3 py-2">
          ${x.active
            ? `<button class="text-xs px-2 py-1 border rounded toggleBtn" data-id="${x.id}" data-active="0">Desactivar</button>`
            : `<button class="text-xs px-2 py-1 border rounded toggleBtn" data-id="${x.id}" data-active="1">Activar</button>`
          }
        </td>
      </tr>
    `).join('');
  }
  total.textContent = `${data.total} resultados`;
  pageInfo.textContent = `Página ${data.page} de ${data.pages}`;
  prev.disabled = data.page<=1; next.disabled = data.page>=data.pages;

  document.querySelectorAll('.toggleBtn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const fd = new FormData();
      fd.append('action','toggle');
      fd.append('id', btn.dataset.id);
      fd.append('active', btn.dataset.active);
      fetch('index.php', {method:'POST', body:fd, credentials:'same-origin'})
        .then(r=>r.json())
        .then(d=>{ if(!d.ok) throw new Error(d.error||'Error'); listTokens(); })
        .catch(e=>alert(e.message||'Error'));
    });
  });
}

cf.addEventListener('submit', e=>{
  e.preventDefault();
  const fd = new FormData(cf);
  fd.append('action','create');
  fetch('index.php', {method:'POST', body:fd, credentials:'same-origin'})
    .then(r=>r.json())
    .then(data=>{
      if(!data.ok) throw new Error(data.error||'Error');
      plainToken.textContent = data.token;
      tokenBox.classList.remove('hidden');
      listTokens();
      // Stats
      loadStats(usuarioSel.value);
    })
    .catch(err=>{ alert(err.message||'Error'); });
});

copyBtn.addEventListener('click', ()=>{
  navigator.clipboard.writeText(plainToken.textContent||'');
});

filterUser.addEventListener('change', ()=>{ page=1; listTokens(); loadStats(filterUser.value); });

function loadStats(uid){
  const box = document.getElementById('planBox');
  if(!uid){ box.textContent='Selecciona un usuario para ver límites.'; return; }
  const fd = new FormData(); fd.append('action','stats'); fd.append('usuario_id', uid);
  fetch('index.php', {method:'POST', body:fd, credentials:'same-origin'})
    .then(r=>r.json())
    .then(d=>{
      if(!d.ok) throw new Error(d.error||'Error');
      const p = d.plan;
      if(!p){ box.textContent='Sin plan activo.'; return; }
      box.innerHTML = `
        <div><b>Plan:</b> ${escapeHtml(p.code)} - ${escapeHtml(p.name)}</div>
        <div><b>Límite mensual:</b> ${p.monthly_calls} llamadas</div>
        <div><b>Rate limit:</b> ${p.rpm_limit} rpm</div>
        <div><b>Uso (${escapeHtml(d.period[0])} a ${escapeHtml(d.period[1])}):</b> ${d.month_calls}</div>
      `;
    })
    .catch(_=>{ box.textContent='No disponible.'; });
}

// Init
listTokens();
</script>
</body>
</html>
