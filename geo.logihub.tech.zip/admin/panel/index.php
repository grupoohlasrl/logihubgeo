<?php
declare(strict_types=1);
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: /admin/auth/login/index.php'); exit; }
require_once __DIR__ . '/../../config/db.php';

/* helpers */
function tableExists(PDO $pdo, string $name): bool {
  $st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
  $st->execute([$name]);
  return (bool)$st->fetchColumn();
}
function scalar(PDO $pdo, string $sql, array $p=[]): int {
  try { $st=$pdo->prepare($sql); $st->execute($p); return (int)$st->fetchColumn(); }
  catch(Throwable $e){ return 0; }
}

/* stats base */
$stats = [
  'usuarios'=>0,'suscripciones'=>0,'ingresos'=>0,'api_calls'=>0,
  'paises'=>0,'ciudades'=>0,'postales'=>0,'zonas'=>0
];

/* usuarios */
if (tableExists($pdo,'users')) {
  $stats['usuarios'] = scalar($pdo,"SELECT COUNT(*) FROM users");
}

/* suscripciones */
if (tableExists($pdo,'subscriptions')) {
  $stats['suscripciones'] = scalar($pdo,"SELECT COUNT(*) FROM subscriptions WHERE status='active'");
}

/* ingresos del mes */
if (tableExists($pdo,'usage_billing')) {
  $stats['ingresos'] = scalar($pdo,"SELECT IFNULL(SUM(overage_amount_usd),0) FROM usage_billing WHERE period_start >= DATE_FORMAT(NOW(),'%Y-%m-01')");
}

/* llamadas de hoy */
if (tableExists($pdo,'usage_daily')) {
  $stats['api_calls'] = scalar($pdo,"SELECT IFNULL(SUM(calls),0) FROM usage_daily WHERE day=CURDATE()");
}

/* países, ciudades, postales, zonas */
$hasCountries = tableExists($pdo,'countries');
$hasCities    = tableExists($pdo,'cities');
$hasPostales  = tableExists($pdo,'postal_codes');
$hasZones     = tableExists($pdo,'zones');
$hasGlobal    = tableExists($pdo,'Zonas_global');

/* países */
if ($hasCountries) {
  $stats['paises'] = scalar($pdo,"SELECT COUNT(*) FROM countries");
} elseif ($hasGlobal) {
  $stats['paises'] = scalar($pdo,"SELECT COUNT(DISTINCT country_iso2) FROM Zonas_global WHERE country_iso2 IS NOT NULL AND country_iso2<>''");
}

/* ciudades */
if ($hasCities) {
  $stats['ciudades'] = scalar($pdo,"SELECT COUNT(*) FROM cities");
} elseif ($hasGlobal) {
  $stats['ciudades'] = scalar($pdo,"
    SELECT COUNT(*) FROM (
      SELECT 1 FROM Zonas_global
      WHERE city IS NOT NULL AND city<>''
      GROUP BY country_iso2, region_name, province_name, city
    ) t
  ");
}

/* postales */
if ($hasPostales) {
  $stats['postales'] = scalar($pdo,"SELECT COUNT(*) FROM postal_codes");
} elseif ($hasGlobal) {
  $stats['postales'] = scalar($pdo,"
    SELECT COUNT(*) FROM (
      SELECT 1 FROM Zonas_global
      WHERE postal_code IS NOT NULL AND postal_code<>''
      GROUP BY country_iso2, postal_code
    ) t
  ");
}

/* zonas */
if ($hasZones) {
  $stats['zonas'] = scalar($pdo,"SELECT COUNT(*) FROM zones");
} elseif ($hasGlobal) {
  $stats['zonas'] = scalar($pdo,"
    SELECT COUNT(*) FROM (
      SELECT 1 FROM Zonas_global
      GROUP BY country_iso2,
               COALESCE(region_code,region_name),
               COALESCE(province_code,province_name),
               COALESCE(city,''),
               COALESCE(postal_code,'')
    ) t
  ");
}

/* últimos usuarios */
$ultimos=[];
if (tableExists($pdo,'users')) {
  $st=$pdo->query("SELECT name, email, rol, status, DATE(created_at) AS fecha FROM users ORDER BY id DESC LIMIT 5");
  $ultimos=$st->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - GeologiHub</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body{font-family:'Inter',sans-serif}
    ::-webkit-scrollbar{width:8px}
    ::-webkit-scrollbar-track{background:#f1f5f9}
    ::-webkit-scrollbar-thumb{background:#94a3b8;border-radius:10px}
    ::-webkit-scrollbar-thumb:hover{background:#64748b}
  </style>
</head>
<body class="bg-gray-100">
<div class="flex h-screen">
  <?php include __DIR__.'/../../asset/admin/sidebar.php'; ?>

  <main class="flex-1 flex flex-col overflow-hidden">
    <header class="bg-white shadow p-4 z-10">
      <h1 class="text-2xl font-semibold text-gray-800">Dashboard</h1>
    </header>

    <div class="flex-1 overflow-y-auto p-6 bg-gray-100">
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="bg-white p-5 rounded-xl shadow flex justify-between items-center">
          <div>
            <h3 class="text-sm font-medium text-gray-500">Usuarios Totales</h3>
            <p class="text-3xl font-bold text-gray-900 mt-1"><?=number_format($stats['usuarios'])?></p>
          </div>
          <div class="bg-indigo-100 rounded-full p-3">
            <svg class="h-6 w-6 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.124-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.653.124-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
          </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow flex justify-between items-center">
          <div>
            <h3 class="text-sm font-medium text-gray-500">Suscripciones Activas</h3>
            <p class="text-3xl font-bold text-gray-900 mt-1"><?=number_format($stats['suscripciones'])?></p>
          </div>
          <div class="bg-green-100 rounded-full p-3">
            <svg class="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow flex justify-between items-center">
          <div>
            <h3 class="text-sm font-medium text-gray-500">Ingresos (Mes)</h3>
            <p class="text-3xl font-bold text-gray-900 mt-1">$<?=number_format($stats['ingresos'],2)?></p>
          </div>
          <div class="bg-yellow-100 rounded-full p-3">
            <svg class="h-6 w-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01"/></svg>
          </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow flex justify-between items-center">
          <div>
            <h3 class="text-sm font-medium text-gray-500">Llamadas API (Hoy)</h3>
            <p class="text-3xl font-bold text-gray-900 mt-1"><?=number_format($stats['api_calls'])?></p>
          </div>
          <div class="bg-blue-100 rounded-full p-3">
            <svg class="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
          </div>
        </div>

        <div class="bg-white p-5 rounded-xl shadow flex justify-between items-center">
          <div>
            <h3 class="text-sm font-medium text-gray-500">Países</h3>
            <p class="text-3xl font-bold text-gray-900 mt-1"><?=number_format($stats['paises'])?></p>
          </div>
          <div class="bg-red-100 rounded-full p-3">
            <svg class="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2h1a2 2 0 002-2v-1a2 2 0 012-2h1.945M7.885 21H16.115M12 21v-4.885M5.121 15.121A3 3 0 014.5 12.5V10a3 3 0 013-3h9a3 3 0 013 3v2.5a3 3 0 01-.621 1.621m-13.258 0A12.012 12.012 0 0012 18.5a12.012 12.012 0 006.879-3.379m-13.258 0L3 12m18 0l-2.121 3.121"/></svg>
          </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow flex justify-between items-center">
          <div>
            <h3 class="text-sm font-medium text-gray-500">Ciudades</h3>
            <p class="text-3xl font-bold text-gray-900 mt-1"><?=number_format($stats['ciudades'])?></p>
          </div>
          <div class="bg-purple-100 rounded-full p-3">
            <svg class="h-6 w-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
          </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow flex justify-between items-center">
          <div>
            <h3 class="text-sm font-medium text-gray-500">Cód. Postales</h3>
            <p class="text-3xl font-bold text-gray-900 mt-1"><?=number_format($stats['postales'])?></p>
          </div>
          <div class="bg-pink-100 rounded-full p-3">
            <svg class="h-6 w-6 text-pink-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
          </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow flex justify-between items-center">
          <div>
            <h3 class="text-sm font-medium text-gray-500">Zonas</h3>
            <p class="text-3xl font-bold text-gray-900 mt-1"><?=number_format($stats['zonas'])?></p>
          </div>
          <div class="bg-orange-100 rounded-full p-3">
            <svg class="h-6 w-6 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
          </div>
        </div>
      </div>

      <div class="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 bg-white p-6 rounded-xl shadow">
          <h2 class="text-xl font-semibold text-gray-800 mb-4">Visión General de Llamadas API (Últimos 7 días)</h2>
          <canvas id="apiCallsChart"></canvas>
        </div>
        <div class="bg-white p-6 rounded-xl shadow">
          <h2 class="text-xl font-semibold text-gray-800 mb-4">Distribución de Planes</h2>
          <canvas id="plansChart"></canvas>
        </div>
      </div>

      <div class="mt-8 bg-white rounded-xl shadow overflow-hidden">
        <div class="p-6"><h2 class="text-xl font-semibold text-gray-800">Usuarios Registrados Recientemente</h2></div>
        <div class="overflow-x-auto">
          <table class="w-full text-sm text-left text-gray-500">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
              <tr>
                <th class="px-6 py-3">Nombre</th>
                <th class="px-6 py-3">Email</th>
                <th class="px-6 py-3">Rol</th>
                <th class="px-6 py-3">Estado</th>
                <th class="px-6 py-3">Fecha de Registro</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($ultimos): foreach($ultimos as $u): ?>
              <tr class="bg-white border-b">
                <td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap"><?=htmlspecialchars($u['name'])?></td>
                <td class="px-6 py-4"><?=htmlspecialchars($u['email'])?></td>
                <td class="px-6 py-4"><?=ucfirst($u['rol'])?></td>
                <td class="px-6 py-4">
                  <?php if(($u['status']??'')==='active'): ?>
                    <span class="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Activo</span>
                  <?php else: ?>
                    <span class="bg-yellow-100 text-yellow-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Suspendido</span>
                  <?php endif; ?>
                </td>
                <td class="px-6 py-4"><?=htmlspecialchars($u['fecha']??'')?></td>
              </tr>
              <?php endforeach; else: ?>
              <tr class="bg-white border-b"><td colspan="5" class="px-6 py-6 text-center text-gray-500">Sin datos</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </main>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const ctxApi = document.getElementById('apiCallsChart').getContext('2d');
  new Chart(ctxApi, {
    type: 'line',
    data: {
      labels: ['Día 1','Día 2','Día 3','Día 4','Día 5','Día 6','Día 7'],
      datasets: [{
        label: 'Llamadas API',
        data: [120000,150000,110000,180000,160000,210000,190000],
        borderColor: 'rgb(79,70,229)',
        backgroundColor: 'rgba(79,70,229,0.1)',
        fill: true, tension: 0.4
      }]
    },
    options: { responsive:true, scales:{ y:{ beginAtZero:true } } }
  });

  const ctxPlans = document.getElementById('plansChart').getContext('2d');
  new Chart(ctxPlans, {
    type: 'doughnut',
    data: {
      labels: ['Free','Basic','Pro','Enterprise'],
      datasets: [{
        label: 'Distribución de Planes',
        data: [350,450,150,44],
        backgroundColor: ['rgb(165,180,252)','rgb(129,140,248)','rgb(99,102,241)','rgb(79,70,229)'],
        hoverOffset: 4
      }]
    },
    options: { responsive:true }
  });
});
</script>
</body>
</html>
