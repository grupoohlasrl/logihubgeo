<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../../_bootstrap.php';

if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'auth']); exit; }

function jout($d,$c=200){ if(ob_get_length())@ob_end_clean(); header('Content-Type: application/json',true,$c); echo json_encode($d,JSON_UNESCAPED_UNICODE); exit; }
function jread(){ $d=json_decode(file_get_contents('php://input')?:'',true); return is_array($d)?$d:[]; }

$db = pdo(); $uid=(int)$_SESSION['uid'];

$pp_mode = cfg('paypal_mode','sandbox');
$pp_id   = cfg('paypal_client_id','');
$pp_sec  = cfg('paypal_client_secret','');
$pp_cur  = cfg('paypal_currency','USD');
$base = $pp_mode==='live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';

$in = jread();
$invoice_id = (int)($in['invoice_id'] ?? 0);
if ($invoice_id<=0) jout(['ok'=>false,'error'=>'bad_request','detail'=>'invoice_id requerido'],400);

/* factura */
try{
  $st=$db->prepare('SELECT id,user_id,amount_usd,currency,status,description FROM invoices WHERE id=? AND user_id=? LIMIT 1');
  $st->execute([$invoice_id,$uid]); $inv=$st->fetch();
  if(!$inv) jout(['ok'=>false,'error'=>'not_found'],404);
  if($inv['status']!=='due') jout(['ok'=>false,'error'=>'invalid_state','detail'=>'Factura no pendiente'],409);
}catch(\Throwable $e){ jout(['ok'=>false,'error'=>'server','detail'=>$e->getMessage()],500); }

/* token */
$ch=curl_init("$base/v1/oauth2/token");
curl_setopt_array($ch,[
  CURLOPT_RETURNTRANSFER=>true,
  CURLOPT_USERPWD=>"$pp_id:$pp_sec",
  CURLOPT_POST=>true,
  CURLOPT_POSTFIELDS=>'grant_type=client_credentials'
]);
$tok=json_decode(curl_exec($ch),true); curl_close($ch);
if(empty($tok['access_token'])) jout(['ok'=>false,'error'=>'pp_auth'],502);
$AT=$tok['access_token'];

/* crear orden */
$body=[
  'intent'=>'CAPTURE',
  'purchase_units'=>[[
    'amount'=>[
      'currency_code'=>$pp_cur,
      'value'=>number_format((float)$inv['amount_usd'],2,'.','')
    ],
    'description'=>$inv['description'] ?: ('Invoice #'.$inv['id'])
  ]],
  'application_context'=>[
    'shipping_preference'=>'NO_SHIPPING',
    'user_action'=>'PAY_NOW',
    'return_url'=>'https://'.$_SERVER['HTTP_HOST'].'/users/facturas/',
    'cancel_url'=>'https://'.$_SERVER['HTTP_HOST'].'/users/facturas/'
  ]
];
$ch=curl_init("$base/v2/checkout/orders");
curl_setopt_array($ch,[
  CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$AT,'Content-Type: application/json'],
  CURLOPT_POST=>true,
  CURLOPT_RETURNTRANSFER=>true,
  CURLOPT_POSTFIELDS=>json_encode($body)
]);
$res=json_decode(curl_exec($ch),true); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
if($code>=300 || empty($res['id'])) jout(['ok'=>false,'error'=>'pp_create','detail'=>json_encode($res)],502);

/* guardar external_id */
try{
  $u=$db->prepare('UPDATE invoices SET external_id=? WHERE id=? AND user_id=?');
  $u->execute([$res['id'],$invoice_id,$uid]);
}catch(\Throwable $e){ /* no detiene pago */ }

jout(['ok'=>true,'id'=>$res['id']]);
