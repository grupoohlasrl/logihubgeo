<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../../_bootstrap.php';

if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'auth']); exit; }

function jout($d,$c=200){ if(ob_get_length())@ob_end_clean(); header('Content-Type: application/json',true,$c); echo json_encode($d,JSON_UNESCAPED_UNICODE); exit; }
function jread(){ $d=json_decode(file_get_contents('php://input')?:'',true); return is_array($d)?$d:[]; }

$db = pdo(); $uid=(int)$_SESSION['uid'];

$pp_mode = cfg('paypal_mode','sandbox');
$pp_id   = cfg('paypal_client_id','');
$pp_sec  = cfg('paypal_client_secret','');
$base = $pp_mode==='live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';

$in = jread();
$order_id = trim((string)($in['order_id'] ?? ''));
if($order_id==='') jout(['ok'=>false,'error'=>'bad_request'],400);

/* buscar factura por external_id */
try{
  $st=$db->prepare('SELECT id,user_id,status FROM invoices WHERE external_id=? AND user_id=? LIMIT 1');
  $st->execute([$order_id,$uid]); $inv=$st->fetch();
  if(!$inv) jout(['ok'=>false,'error'=>'not_found'],404);
  if($inv['status']!=='due') jout(['ok'=>false,'error'=>'invalid_state'],409);
}catch(\Throwable $e){ jout(['ok'=>false,'error'=>'server','detail'=>$e->getMessage()],500); }

/* token */
$ch=curl_init("$base/v1/oauth2/token");
curl_setopt_array($ch,[
  CURLOPT_RETURNTRANSFER=>true,
  CURLOPT_USERPWD=>"$pp_id:$pp_sec",
  CURLOPT_POST=>true,
  CURLOPT_POSTFIELDS=>'grant_type=client_credentials'
]);
$tok=json_decode(curl_exec($ch),true); curl_close($ch);
if(empty($tok['access_token'])) jout(['ok'=>false,'error'=>'pp_auth'],502);
$AT=$tok['access_token'];

/* capturar */
$ch=curl_init("$base/v2/checkout/orders/$order_id/capture");
curl_setopt_array($ch,[
  CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$AT,'Content-Type: application/json'],
  CURLOPT_POST=>true,
  CURLOPT_RETURNTRANSFER=>true
]);
$res=json_decode(curl_exec($ch),true); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
if($code>=300) jout(['ok'=>false,'error'=>'pp_capture','detail'=>json_encode($res)],502);

/* marcar pagado */
try{
  $db->beginTransaction();
  $db->prepare('UPDATE invoices SET status="paid", paid_at=NOW() WHERE id=? AND user_id=?')->execute([$inv['id'],$uid]);
  // opcional: registrar payment
  $db->prepare('CREATE TABLE IF NOT EXISTS payments (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id BIGINT UNSIGNED NOT NULL,
      invoice_id BIGINT UNSIGNED NOT NULL,
      provider VARCHAR(20) NOT NULL,
      provider_id VARCHAR(64) NOT NULL,
      amount_usd DECIMAL(10,2) NOT NULL,
      created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
      KEY idx_pay_user (user_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4')->execute();
  $amount = 0.00;
  if (!empty($res['purchase_units'][0]['payments']['captures'][0]['amount']['value'])) {
    $amount = (float)$res['purchase_units'][0]['payments']['captures'][0]['amount']['value'];
  }
  $db->prepare('INSERT INTO payments (user_id,invoice_id,provider,provider_id,amount_usd) VALUES (?,?,?,?,?)')
     ->execute([$uid,$inv['id'],'paypal',$order_id,$amount]);
  $db->commit();
}catch(\Throwable $e){ $db->rollBack(); /* no romper respuesta al cliente */ }

jout(['ok'=>true]);
