<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../config/db.php';
if (empty($_SESSION['uid'])) { header('Location: /users/auth/login/'); exit; }

/* helpers y cfg iguales al ejemplo */
function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]); return $db;
}
function cfg(string $k,$d=null){ static $m=null; if($m===null){ $m=[];
  try{$r=pdo()->query('SELECT k,v FROM app_settings')->fetchAll(); foreach($r as $x){$m[$x['k']]=$x['v'];}}catch(Throwable $e){}
} return $m[$k]??$d; }
$brand=['name'=>cfg('site_name','Geo Logihub'),'logo'=>cfg('site_logo_url','/asset/logo.png'),'primary'=>cfg('brand_primary','#2563eb')];
function esc($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}

/* datos plan + facturas seguros */
$db=pdo();
$planName='Free'; $planPrice=0.00; $planStatus='active'; $renewal=null;
try{
  $q=$db->prepare('SELECT s.status, s.next_renewal_at, p.name plan_name, p.price_usd
                   FROM subscriptions s JOIN plans p ON p.id=s.plan_id
                   WHERE s.usuario_id=? ORDER BY s.id DESC LIMIT 1');
  $q->execute([(int)$_SESSION['uid']]); $row=$q->fetch();
  if($row){ $planName=$row['plan_name']??'Free'; $planPrice=(float)($row['price_usd']??0); $planStatus=$row['status']??'active'; $renewal=$row['next_renewal_at']??null; }
}catch(Throwable $e){}

$invoices=[];
try{
  $q=$db->prepare('SELECT id, created_at, description, amount_usd, status, pdf_url FROM invoices WHERE user_id=? ORDER BY id DESC');
  $q->execute([(int)$_SESSION['uid']]); $invoices=$q->fetchAll();
}catch(Throwable $e){}

$pp_mode = cfg('paypal_mode','sandbox');       // sandbox|live
$pp_mail = cfg('paypal_payer_email','');       // opcional para mostrar
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Facturación</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
:root{--brand: <?=esc($brand['primary'])?>}
aside,main{transition:.3s all}
.sidebar-scroll::-webkit-scrollbar{display:none}
.sidebar-scroll{-ms-overflow-style:none;scrollbar-width:none}
.card{box-shadow:0 10px 30px rgba(0,0,0,.06)}
.badge{padding:.25rem .5rem;border-radius:9999px;font-size:.75rem;font-weight:600}
</style>
</head>
<body class="bg-gray-100 font-sans">
<div class="relative min-h-screen md:flex">
  <?php include __DIR__.'/../../asset/users/sidebar.php'; ?>

  <!-- SIN md:ml-64 (pegado al sidebar como el ejemplo) -->
  <main id="main-content" class="flex-1 p-6 md:p-10">
    <!-- Header -->
    <div class="flex items-start justify-between mb-8">
      <div>
        <h1 class="text-3xl font-extrabold text-gray-800 tracking-tight">Facturación</h1>
        <p class="text-gray-500 mt-1">Gestiona tu plan y revisa tu historial de pagos.</p>
      </div>
      <a href="/users/planes/index.php" class="hidden md:inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg">
        Cambiar plan
        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m9 18 6-6-6-6"/></svg>
      </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Columna izquierda -->
      <div class="lg:col-span-1 space-y-6">
        <!-- Plan actual -->
        <div class="bg-white rounded-2xl card p-6">
          <h3 class="text-lg font-semibold text-gray-800 mb-4">Plan actual</h3>
          <div class="flex items-center justify-between">
            <div>
              <div class="text-blue-600 font-extrabold text-xl"><?=esc($planName)?></div>
              <div class="text-xs text-gray-500 mt-1">Estado: <span class="font-medium"><?=esc($planStatus)?></span></div>
              <div class="text-xs text-gray-500">Próxima renovación: <?= $renewal?esc($renewal):'—' ?></div>
            </div>
            <div class="text-2xl font-extrabold text-gray-900">
              $<?=number_format($planPrice,2)?><span class="text-sm text-gray-500">/mes</span>
            </div>
          </div>
          <a href="/users/planes/index.php" class="mt-4 inline-flex w-full justify-center bg-blue-100 text-blue-700 hover:bg-blue-200 font-semibold py-2 px-4 rounded-lg">
            Mejorar / cambiar plan
          </a>
        </div>

        <!-- Método de pago -->
        <div class="bg-white rounded-2xl card p-6">
          <h3 class="text-lg font-semibold text-gray-800 mb-4">Método de pago</h3>
          <div class="flex items-center p-4 border rounded-lg">
            <svg class="w-8 h-8" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M3.523 2.051c.224-.03.45.02.62.15l5.053 3.82c.26.19.42.49.42.81v.01c0 .03 0 .06-.01.09l-1.55 9.32c-.07.4-.38.71-.78.78l-5.02 1.05c-.17.03-.34 0-.5-.09-.16-.09-.28-.23-.33-.4l-1.12-3.8c-.03-.09-.03-.18 0-.27l2.2-7.55c.06-.21.18-.39.34-.52l.01-.01c.16-.13.36-.2.56-.2Z" fill="#253B80"/>
              <path fill-rule="evenodd" clip-rule="evenodd" d="M12.443 3.511c.238-.03.473.029.645.16l4.983 3.76c.26.2.42.5.42.82v.01c0 .03 0 .06-.01.09l-1.55 9.32c-.07.4-.38.71-.78.78l-5.02 1.05c-.17.03-.34 0-.5-.09-.16-.09-.28-.23-.33-.4l-1.12-3.8c-.03-.09-.03-.18 0-.27L11.4 7.42c.06-.21.18-.39.34-.52l.01-.01c.16-.13.36-.2.56-.2h.133Z" fill="#009cde"/>
            </svg>
            <div class="ml-3">
              <div class="font-semibold text-gray-700">PayPal <span class="text-xs text-gray-500">(<?=esc($pp_mode)?>)</span></div>
              <div class="text-sm text-gray-500"><?= $pp_mail?esc($pp_mail):'Sin configurar' ?></div>
            </div>
          </div>
          <a href="/users/planes/index.php" class="mt-4 inline-flex w-full justify-center bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded-lg">
            Actualizar método
          </a>
        </div>
      </div>

      <!-- Columna derecha -->
      <div class="lg:col-span-2">
        <div class="bg-white rounded-2xl card">
          <div class="p-6 border-b">
            <h3 class="text-lg font-semibold text-gray-800">Historial de facturación</h3>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-600">
              <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                <tr>
                  <th class="px-6 py-3">Fecha</th>
                  <th class="px-6 py-3">Descripción</th>
                  <th class="px-6 py-3">Monto</th>
                  <th class="px-6 py-3">Estado</th>
                  <th class="px-6 py-3 text-right">Factura</th>
                </tr>
              </thead>
              <tbody>
                <?php if(!$invoices): ?>
                  <tr><td colspan="5" class="px-6 py-6 text-center text-gray-500">No hay facturas.</td></tr>
                <?php else: foreach($invoices as $i): 
                  $st=strtolower((string)$i['status']);
                  $cls=$st==='paid'?'bg-green-100 text-green-800':($st==='pending'?'bg-yellow-100 text-yellow-800':'bg-gray-200 text-gray-800'); ?>
                  <tr class="bg-white border-b hover:bg-gray-50">
                    <td class="px-6 py-4 font-medium text-gray-900"><?=esc($i['created_at'])?></td>
                    <td class="px-6 py-4"><?=esc($i['description'])?></td>
                    <td class="px-6 py-4">$<?=number_format((float)$i['amount_usd'],2)?></td>
                    <td class="px-6 py-4"><span class="badge <?=$cls?>"><?=esc($i['status'])?></span></td>
                    <td class="px-6 py-4 text-right">
                      <?php if(!empty($i['pdf_url'])): ?>
                        <a class="font-medium text-blue-600 hover:underline" target="_blank" href="<?=esc($i['pdf_url'])?>">Descargar</a>
                      <?php else: ?><span class="text-gray-400">—</span><?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>

<script>
// abrir/cerrar sidebar móvil (igual al ejemplo)
document.addEventListener('DOMContentLoaded',()=>{
  const sidebar=document.getElementById('sidebar');
  const openBtn=document.getElementById('open-sidebar-mobile');
  const closeBtn=document.getElementById('close-sidebar-mobile');
  const adjust=()=>{ if(innerWidth<768) sidebar.classList.add('-translate-x-full'); else sidebar.classList.remove('-translate-x-full'); };
  if(openBtn) openBtn.addEventListener('click',()=>sidebar.classList.remove('-translate-x-full'));
  if(closeBtn) closeBtn.addEventListener('click',()=>sidebar.classList.add('-translate-x-full'));
  adjust(); addEventListener('resize',adjust);
});
</script>
</body>
</html>
