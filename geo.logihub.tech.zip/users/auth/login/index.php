<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../../config/db.php';

function pdo(): PDO {
  global $pdo; if ($pdo instanceof PDO) return $pdo;
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  return new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]);
}
function csrf_token($k='csrf_login'){ if(empty($_SESSION[$k])) $_SESSION[$k]=bin2hex(random_bytes(16)); return $_SESSION[$k]; }
function csrf_check($t,$k='csrf_login'){ if(empty($_SESSION[$k])||!hash_equals($_SESSION[$k],$t)){ http_response_code(400); exit('CSRF'); } }
function brand(): array {
  static $b; if($b) return $b;
  $db=pdo();
  $q=$db->prepare('SELECT `key`,`value` FROM config_global WHERE `key` IN ("brand_name","brand_logo_url","brand_primary")');
  try{$q->execute();$m=$q->fetchAll();$map=[];foreach($m as $r){$map[$r['key']]=$r['value'];}}catch(\Throwable $e){$map=[];}
  return $b=['name'=>$map['brand_name']??'Geo Logihub','logo'=>$map['brand_logo_url']??'/asset/logo.png','primary'=>$map['brand_primary']??'#0d6efd'];
}
function esc($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function throttle($k,$max,$win){$now=time(); if(!isset($_SESSION[$k]))$_SESSION[$k]=[]; $_SESSION[$k]=array_filter($_SESSION[$k],fn($t)=>($now-$t)<$win); if(count($_SESSION[$k])>=$max)return false; $_SESSION[$k][]=$now; return true;}

$brand=brand(); $err=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check($_POST['csrf']??'');
  if(!throttle('thr_login_'.($_SERVER['REMOTE_ADDR']??'ip'),20,300)){ http_response_code(429); exit('rate'); }
  $email=strtolower(trim((string)($_POST['email']??'')));
  $pass=(string)($_POST['password']??'');
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)||$pass===''){ $err='Credenciales inválidas'; }
  else{
    $db=pdo();
    $st=$db->prepare('SELECT id,password_hash,status FROM users WHERE email=? LIMIT 1'); $st->execute([$email]); $u=$st->fetch();
    if(!$u || !password_verify($pass,$u['password_hash'])) $err='Credenciales inválidas';
    else{
      if($u['status']==='pending'){
        $_SESSION['pending_user_id']=$u['id'];
        header('Location: /users/auth/register/'); exit;
      }
      $_SESSION['uid']=(int)$u['id'];
      header('Location: /users/panel/index.php'); exit;
    }
  }
}
?>
<!doctype html><html lang="es"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>:root{--brand:<?=esc($brand['primary'])?>}body{background:#0f172a}.card{border:0;border-radius:1rem;box-shadow:0 10px 30px rgba(0,0,0,.25)}.btn-brand{background:var(--brand);border-color:var(--brand)}</style>
</head><body class="text-light">
<div class="container py-5"><div class="row justify-content-center"><div class="col-lg-5">
<div class="card p-4 bg-dark text-light">
  <div class="d-flex align-items-center mb-3">
    <img src="<?=esc($brand['logo'])?>" style="height:36px" class="me-2" alt="logo"><strong><?=esc($brand['name'])?></strong>
  </div>
  <?php if($err):?><div class="alert alert-danger"><?=esc($err)?></div><?php endif;?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?=esc(csrf_token())?>">
    <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required></div>
    <div class="mb-3"><label class="form-label">Contraseña</label><input type="password" name="password" class="form-control" required></div>
    <div class="d-grid"><button class="btn btn-brand btn-lg">Entrar</button></div>
    <div class="text-center mt-3"><a href="/users/auth/register/">Crear cuenta</a></div>
  </form>
</div></div></div></div>
</body></html>
