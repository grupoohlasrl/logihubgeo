<?php
declare(strict_types=1);
session_start();

require_once __DIR__ . '/../../../config/db.php';

/* ===== DB helper ===== */
function pdo(): PDO {
  global $pdo;
  if ($pdo instanceof PDO) return $pdo;
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $pdo = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
  return $pdo;
}

/* ===== Config dinámica de marca ===== */
function cfg_get(string $key, ?string $default=null): ?string {
  static $cache = [];
  if (array_key_exists($key,$cache)) return $cache[$key];
  try {
    $db = pdo();
    $stmt = $db->prepare('SELECT `value` FROM config_global WHERE `key`=? LIMIT 1');
    $stmt->execute([$key]);
    $val = $stmt->fetchColumn();
    if ($val === false) $val = $default;
  } catch (\Throwable $e) { $val = $default; }
  $cache[$key] = $val;
  return $val;
}
function brand(): array {
  return [
    'name' => cfg_get('brand_name','Geo Logihub'),
    'logo' => cfg_get('brand_logo_url','/asset/logo.png'),
    'primary' => cfg_get('brand_primary','#0d6efd'),
  ];
}

/* ===== Utilidades ===== */
function csrf_token(string $key='csrf_reg'): string {
  if (empty($_SESSION[$key])) $_SESSION[$key] = bin2hex(random_bytes(16));
  return $_SESSION[$key];
}
function csrf_check(string $token, string $key='csrf_reg'): void {
  if (empty($_SESSION[$key]) || !hash_equals($_SESSION[$key], $token)) {
    http_response_code(400); exit('CSRF inválido');
  }
}
function valid_domain(string $d): bool {
  return (bool)preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/i', $d);
}
function throttle_key(string $suffix): string {
  $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
  return 'thr_'.$suffix.'_'.$ip;
}
function throttle(string $key, int $max, int $winSec): bool {
  $now = time();
  if (!isset($_SESSION[$key])) $_SESSION[$key] = [];
  $_SESSION[$key] = array_filter($_SESSION[$key], fn($t)=>($now-$t) < $winSec);
  if (count($_SESSION[$key]) >= $max) return false;
  $_SESSION[$key][] = $now;
  return true;
}
function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function rand_token(int $len=12): string {
  $alpha = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  $out=''; for($i=0;$i<$len;$i++){ $out.=$alpha[random_int(0,strlen($alpha)-1)]; }
  return $out;
}

/* ===== Flujo ===== */
$brand = brand();
$step  = !empty($_SESSION['pending_user_id']) ? 'verify' : 'form';
$errors = [];
$flash  = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'register') {
    csrf_check($_POST['csrf'] ?? '');
    if (!throttle(throttle_key('register'), 10, 300)) { http_response_code(429); exit('Demasiados intentos'); }
    if (!empty($_POST['website'])) { http_response_code(400); exit('Bot'); }

    $name = trim((string)($_POST['name'] ?? ''));
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    $domain = strtolower(trim((string)($_POST['domain'] ?? '')));
    $terms  = isset($_POST['terms']);

    if ($name === '' || mb_strlen($name) < 2) $errors[] = 'Nombre inválido';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email inválido';
    if (mb_strlen($password) < 8) $errors[] = 'Contraseña mínima 8 caracteres';
    if (!valid_domain($domain)) $errors[] = 'Dominio inválido. Ej: sub.miempresa.com';
    if (!$terms) $errors[] = 'Debes aceptar Términos y Política';

    if (!$errors) {
      try {
        $db = pdo();
        $s = $db->prepare('SELECT id FROM users WHERE email=? LIMIT 1');
        $s->execute([$email]);
        if ($s->fetch()) $errors[] = 'Email ya registrado';
      } catch (\Throwable $e) { $errors[] = 'Error de base de datos'; }
    }

    if (!$errors) {
      $db = pdo();
      try {
        $db->beginTransaction();

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $token = rand_token(12); // requerido por schema
        // Nota: status enum es active|suspended. Insertamos active.
        $db->prepare('INSERT INTO users (name,email,password_hash,rol,token,status) VALUES (?,?,?,?,?, "active")')
           ->execute([$name,$email,$hash,'cliente',$token]); // sin phone, sin pending
        $uid = (int)$db->lastInsertId();

        $db->prepare('INSERT INTO user_domains (user_id,domain,verified) VALUES (?,?,0)')
           ->execute([$uid,$domain]);

        $code = str_pad((string)random_int(0,999999), 6, '0', STR_PAD_LEFT);
        $exp  = (new DateTime('+10 minutes'))->format('Y-m-d H:i:s');
        $db->prepare('INSERT INTO user_otp (user_id,code,purpose,expires_at) VALUES (?,?, "signup", ?)')
           ->execute([$uid,$code,$exp]);

        $db->commit();

        $_SESSION['pending_user_id'] = $uid;
        $_SESSION['pending_email']   = $email;
        $_SESSION['pending_otp']     = $code;
        $_SESSION['shown_otp_once']  = false;

        $step = 'verify';
      } catch (\Throwable $e) {
        $db->rollBack();
        $errors[] = 'No se pudo registrar';
      }
    }
  }

  if ($action === 'verify') {
    csrf_check($_POST['csrf'] ?? '', 'csrf_ver');
    if (!throttle(throttle_key('verify'), 20, 300)) { http_response_code(429); exit('Demasiados intentos'); }
    if (empty($_SESSION['pending_user_id'])) { header('Location: /users/auth/register/'); exit; }

    $code = trim((string)($_POST['code'] ?? ''));
    if (!preg_match('/^\d{6}$/', $code)) {
      $errors[] = 'Código inválido'; $step = 'verify';
    } else {
      $db = pdo();
      $uid = (int)$_SESSION['pending_user_id'];
      $row = $db->prepare('SELECT id,code,expires_at,consumed FROM user_otp WHERE user_id=? AND purpose="signup" ORDER BY id DESC LIMIT 1');
      $row->execute([$uid]);
      $otp = $row->fetch();

      if (!$otp) { $errors[] = 'No hay OTP activo'; }
      elseif ((int)$otp['consumed'] === 1) { $errors[] = 'OTP ya usado'; }
      elseif (new DateTime() > new DateTime($otp['expires_at'])) { $errors[] = 'OTP expirado'; }
      elseif (!hash_equals($otp['code'], $code)) { $errors[] = 'Código incorrecto'; }
      else {
        try {
          $db->beginTransaction();
          $db->prepare('UPDATE user_otp SET consumed=1 WHERE id=?')->execute([$otp['id']]);
          $db->commit();

          // login y redirección a planes
          unset($_SESSION['pending_user_id'], $_SESSION['pending_email'], $_SESSION['pending_otp'], $_SESSION['csrf_ver']);
          $_SESSION['uid'] = $uid;
          header('Location: /users/planes/index.php'); exit;
        } catch (\Throwable $e) {
          $db->rollBack(); $errors[] = 'Error al verificar';
        }
      }
      $step = 'verify';
    }
  }

  if ($action === 'resend') {
    csrf_check($_POST['csrf'] ?? '', 'csrf_ver');
    if (!throttle(throttle_key('resend'), 5, 300)) { http_response_code(429); exit('Demasiados reintentos'); }
    if (empty($_SESSION['pending_user_id'])) { header('Location: /users/auth/register/'); exit; }
    $db = pdo(); $uid = (int)$_SESSION['pending_user_id'];
    try {
      $db->beginTransaction();
      $db->prepare('UPDATE user_otp SET consumed=1 WHERE user_id=? AND purpose="signup" AND consumed=0')->execute([$uid]);
      $code = str_pad((string)random_int(0,999999), 6, '0', STR_PAD_LEFT);
      $exp  = (new DateTime('+10 minutes'))->format('Y-m-d H:i:s');
      $db->prepare('INSERT INTO user_otp (user_id,code,purpose,expires_at) VALUES (?,?, "signup", ?)')->execute([$uid,$code,$exp]);
      $db->commit();
      $_SESSION['pending_otp'] = $code;
      $_SESSION['shown_otp_once'] = false;
      $flash = 'Se generó un nuevo código.';
      $step = 'verify';
    } catch (\Throwable $e) { $db->rollBack(); $errors[] = 'No se pudo regenerar el código'; }
  }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Registro</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root{ --brand: <?=esc($brand['primary'])?>; }
    body{background:#0f172a;}
    .card{border:0;border-radius:1rem;box-shadow:0 10px 30px rgba(0,0,0,.25);}
    .brand{font-weight:700;letter-spacing:.5px}
    .otp-box{font:700 28px/1.2 ui-monospace, SFMono-Regular, Menlo, monospace; letter-spacing:.2em}
    .pin input{width:48px;height:56px;text-align:center;font:600 24px/1 ui-monospace;border-radius:.75rem}
    .btn-brand{background:var(--brand);border-color:var(--brand)}
    .btn-brand:hover{opacity:.9}
  </style>
</head>
<body class="text-light">
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-6">
      <div class="card p-4 bg-dark text-light">
        <div class="d-flex align-items-center mb-3">
          <img src="<?=esc($brand['logo'])?>" alt="Logo" style="height:36px" class="me-2">
          <div class="brand"><?=esc($brand['name'])?></div>
        </div>

        <?php if ($errors): ?>
          <div class="alert alert-danger"><?php foreach ($errors as $e) echo '<div>'.esc($e).'</div>'; ?></div>
        <?php endif; ?>
        <?php if ($flash): ?>
          <div class="alert alert-info"><?=esc($flash)?></div>
        <?php endif; ?>

        <?php if ($step === 'form'): ?>
          <h4 class="mb-3">Crear cuenta</h4>
          <form method="post" action="">
            <input type="hidden" name="csrf" value="<?=esc(csrf_token())?>">
            <input type="hidden" name="action" value="register">
            <input type="text" name="website" value="" style="display:none">

            <div class="mb-3">
              <label class="form-label">Nombre</label>
              <input name="name" class="form-control" required minlength="2" value="<?=isset($_POST['name'])?esc($_POST['name']):''?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" required value="<?=isset($_POST['email'])?esc($_POST['email']):''?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Contraseña</label>
              <input type="password" name="password" class="form-control" required minlength="8" autocomplete="new-password">
            </div>
            <div class="mb-3">
              <label class="form-label">Dominio a usar</label>
              <input name="domain" class="form-control" placeholder="sub.miempresa.com" required value="<?=isset($_POST['domain'])?esc($_POST['domain']):''?>">
            </div>
            <div class="form-check mb-3">
              <input class="form-check-input" type="checkbox" name="terms" id="t1" <?=isset($_POST['terms'])?'checked':''?>>
              <label for="t1" class="form-check-label">Acepto Términos y Política</label>
            </div>

            <div class="d-grid">
              <button class="btn btn-brand btn-lg">Registrarme</button>
            </div>
            <div class="text-center mt-3">
              <a href="/users/auth/login/">¿Ya tienes cuenta? Inicia sesión</a>
            </div>
          </form>

        <?php else: ?>
          <h4 class="mb-1">Verificación</h4>
          <div class="text-secondary mb-3">Ingresa el código de 6 dígitos para activar tu cuenta.</div>

          <?php
          $visibleOtp = '';
          if (!empty($_SESSION['pending_otp'])) {
            if (empty($_SESSION['shown_otp_once'])) {
              $visibleOtp = $_SESSION['pending_otp'];
              $_SESSION['shown_otp_once'] = true;
            } else {
              $code = $_SESSION['pending_otp'];
              $visibleOtp = substr($code,0,2) . '••' . substr($code,-2);
            }
          }
          if ($visibleOtp !== ''):
          ?>
            <div class="alert alert-warning">
              Código generado para esta sesión:
              <div class="d-flex align-items-center gap-2">
                <div class="otp-box mt-1" id="otpText"><?=esc($visibleOtp)?></div>
                <?php if (!empty($_SESSION['pending_otp'])): ?>
                  <button type="button" class="btn btn-sm btn-outline-dark ms-auto" id="copyBtn">Copiar</button>
                <?php endif; ?>
              </div>
              <small class="text-muted">Caduca en 10 minutos.</small>
            </div>
          <?php endif; ?>

          <form method="post" action="" id="verifyForm">
            <input type="hidden" name="csrf" value="<?=esc(csrf_token('csrf_ver'))?>">
            <input type="hidden" name="action" value="verify">
            <input type="hidden" name="code" id="codeHidden">

            <div class="pin d-flex gap-2 justify-content-between mb-3">
              <?php for($i=0;$i<6;$i++): ?>
                <input class="form-control form-control-lg text-dark" inputmode="numeric" maxlength="1" pattern="\d" autocomplete="one-time-code" data-idx="<?=$i?>">
              <?php endfor; ?>
            </div>

            <div class="d-grid gap-2">
              <button class="btn btn-success btn-lg" type="submit">Confirmar</button>
            </div>
          </form>

          <form method="post" action="" class="mt-3">
            <input type="hidden" name="csrf" value="<?=esc(csrf_token('csrf_ver'))?>">
            <input type="hidden" name="action" value="resend">
            <button class="btn btn-outline-light w-100" type="submit">Generar nuevo código</button>
          </form>

          <div class="text-center mt-3">
            <a href="/users/auth/register/">Volver al registro</a>
          </div>
        <?php endif; ?>

      </div>
    </div>
  </div>
</div>

<script>
(function(){
  const brand = getComputedStyle(document.documentElement).getPropertyValue('--brand');
  document.querySelectorAll('.btn-brand').forEach(b=>b.style.background=brand);

  // OTP inputs
  const inputs = Array.from(document.querySelectorAll('.pin input[data-idx]'));
  const hidden = document.getElementById('codeHidden');
  function rebuild(){
    const v = inputs.map(i=>i.value.replace(/\D/g,'')).join('');
    hidden.value = v;
  }
  inputs.forEach((inp,idx)=>{
    inp.addEventListener('input', e=>{
      e.target.value = e.target.value.replace(/\D/g,'').slice(0,1);
      rebuild();
      if (e.target.value && idx < inputs.length-1) inputs[idx+1].focus();
    });
    inp.addEventListener('keydown', e=>{
      if (e.key === 'Backspace' && !inp.value && idx>0){ inputs[idx-1].focus(); }
      if (e.key === 'ArrowLeft' && idx>0){ inputs[idx-1].focus(); }
      if (e.key === 'ArrowRight' && idx<inputs.length-1){ inputs[idx+1].focus(); }
    });
    inp.addEventListener('paste', e=>{
      const text = (e.clipboardData || window.clipboardData).getData('text') || '';
      const digits = text.replace(/\D/g,'').slice(0,6).split('');
      if (digits.length){
        e.preventDefault();
        inputs.forEach((el,i)=>{ el.value = digits[i] || ''; });
        rebuild();
        const next = digits.length>=6 ? inputs[5] : inputs[digits.length] || inputs[0];
        next.focus();
      }
    });
  });

  // Copy OTP
  const copyBtn = document.getElementById('copyBtn');
  const otpText = document.getElementById('otpText');
  if (copyBtn && otpText){
    copyBtn.addEventListener('click', async ()=>{
      const raw = "<?= isset($_SESSION['pending_otp']) ? esc($_SESSION['pending_otp']) : '' ?>";
      try { await navigator.clipboard.writeText(raw); copyBtn.textContent='Copiado'; }
      catch(e){ copyBtn.textContent='Listo'; }
      setTimeout(()=>copyBtn.textContent='Copiar', 2000);
    });
  }
})();
</script>
</body>
</html>
