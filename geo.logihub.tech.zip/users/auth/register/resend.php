<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../../../config/db.php';

$mail_cfg = [
  'host' => 'SMTP_HOST',
  'port' => 587,
  'user' => 'SMTP_USER',
  'pass' => 'SMTP_PASS',
  'from' => 'no-reply@tu-dominio.com',
  'from_name' => 'Geo Logihub'
];

function pdo(): PDO {
  global $pdo;
  if ($pdo instanceof PDO) return $pdo;
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $pdo = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
  return $pdo;
}
function send_otp_email(array $cfg, string $to, string $name, string $code): bool {
  if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
    $m = new PHPMailer\PHPMailer\PHPMailer(true);
    try {
      $m->isSMTP();
      $m->Host = $cfg['host'];
      $m->SMTPAuth = true;
      $m->Username = $cfg['user'];
      $m->Password = $cfg['pass'];
      $m->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
      $m->Port = $cfg['port'];
      $m->setFrom($cfg['from'], $cfg['from_name']);
      $m->addAddress($to, $name);
      $m->Subject = 'Código de verificación';
      $m->Body = "Tu nuevo código es: $code\nCaduca en 10 minutos.\n";
      return $m->send();
    } catch (\Throwable $e) { return false; }
  }
  $h = "From: {$cfg['from']}\r\nContent-Type: text/plain; charset=utf-8";
  return @mail($to, 'Código de verificación', "Nuevo código: $code\nCaduca en 10 minutos.", $h);
}

if (empty($_SESSION['pending_user_id'])) { header('Location: /users/auth/register/'); exit; }
$uid = (int)$_SESSION['pending_user_id'];

$db = pdo();
$u = $db->prepare('SELECT name,email FROM users WHERE id=? LIMIT 1');
$u->execute([$uid]);
$user = $u->fetch();
if (!$user) { header('Location: /users/auth/register/'); exit; }

$db->beginTransaction();
try {
  $db->prepare('UPDATE user_otp SET consumed=1 WHERE user_id=? AND purpose="signup" AND consumed=0')->execute([$uid]);
  $code = str_pad((string)random_int(0,999999), 6, '0', STR_PAD_LEFT);
  $exp = (new DateTime('+10 minutes'))->format('Y-m-d H:i:s');
  $db->prepare('INSERT INTO user_otp (user_id,code,purpose,expires_at) VALUES (?,?, "signup", ?)')->execute([$uid,$code,$exp]);
  $db->commit();
  send_otp_email($mail_cfg, $user['email'], $user['name'], $code);
} catch (\Throwable $e) {
  $db->rollBack();
}
header('Location: /users/auth/register/verify.php');
exit;
