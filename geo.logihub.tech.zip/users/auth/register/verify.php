<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../../../config/db.php';

function pdo(): PDO {
  global $pdo;
  if ($pdo instanceof PDO) return $pdo;
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $pdo = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
  return $pdo;
}
function csrf_token(): string {
  if (empty($_SESSION['csrf_v'])) $_SESSION['csrf_v'] = bin2hex(random_bytes(16));
  return $_SESSION['csrf_v'];
}
function csrf_check(string $t): void {
  if (empty($_SESSION['csrf_v']) || !hash_equals($_SESSION['csrf_v'], $t)) {
    http_response_code(400); exit('CSRF inválido');
  }
}

if (empty($_SESSION['pending_user_id'])) {
  header('Location: /users/auth/register/'); exit;
}

$errors = [];
$info = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check($_POST['csrf'] ?? '');
  $code = trim((string)($_POST['code'] ?? ''));
  if (!preg_match('/^\d{6}$/', $code)) {
    $errors[] = 'Código inválido';
  } else {
    $db = pdo();
    $uid = (int)$_SESSION['pending_user_id'];
    $row = $db->prepare('SELECT id,code,expires_at,consumed FROM user_otp WHERE user_id=? AND purpose="signup" ORDER BY id DESC LIMIT 1');
    $row->execute([$uid]);
    $otp = $row->fetch();

    if (!$otp) {
      $errors[] = 'No hay OTP activo';
    } elseif ((int)$otp['consumed'] === 1) {
      $errors[] = 'OTP ya usado';
    } elseif (new DateTime() > new DateTime($otp['expires_at'])) {
      $errors[] = 'OTP expirado';
    } elseif (!hash_equals($otp['code'], $code)) {
      $errors[] = 'Código incorrecto';
    } else {
      $db->beginTransaction();
      try {
        $db->prepare('UPDATE user_otp SET consumed=1 WHERE id=?')->execute([$otp['id']]);
        $db->prepare('UPDATE users SET status="active", verified_at=NOW() WHERE id=?')->execute([$uid]);
        $db->commit();
        unset($_SESSION['pending_user_id'], $_SESSION['pending_email'], $_SESSION['csrf_v']);
        $_SESSION['uid'] = $uid; // login
        header('Location: /users/planes/index.php');
        exit;
      } catch (\Throwable $e) {
        $db->rollBack();
        $errors[] = 'Error al verificar';
      }
    }
  }
}

if (isset($_SESSION['pending_email'])) $info = 'Se envió un código a '.$_SESSION['pending_email'];
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Verificar código</title>
</head>
<body>
<h1>Verificación</h1>
<?php if ($info): ?><div><?=$info?></div><?php endif; ?>
<?php if ($errors): ?><div style="color:#b00"><?php foreach ($errors as $e) echo '<div>'.htmlspecialchars($e).'</div>'; ?></div><?php endif; ?>
<form method="post" action="">
  <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
  <label>Código de 6 dígitos<br><input name="code" pattern="\d{6}" required></label><br><br>
  <button type="submit">Confirmar</button>
</form>
<form method="post" action="resend.php" style="margin-top:10px">
  <button type="submit">Reenviar código</button>
</form>
</body>
</html>
