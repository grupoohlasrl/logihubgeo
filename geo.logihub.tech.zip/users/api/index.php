<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../config/db.php';
if (empty($_SESSION['uid'])) { header('Location: /users/auth/login/'); exit; }

/* helpers */
function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]); return $db;
}
function cfg(string $k,$d=null){ static $m=null; if($m===null){ $m=[];
  try{$r=pdo()->query('SELECT k,v FROM app_settings')->fetchAll(); foreach($r as $x){$m[$x['k']]=$x['v'];}}catch(Throwable $e){}
} return $m[$k]??$d; }
function esc($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}

if(empty($_SESSION['csrf_api'])) $_SESSION['csrf_api']=bin2hex(random_bytes(16));
$CSRF = $_SESSION['csrf_api'];

$brand=['name'=>cfg('site_name','Geo Logihub'),'logo'=>cfg('site_logo_url','/asset/logo.png'),'primary'=>cfg('brand_primary','#2563eb')];
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https' : 'http';
$baseUrl = $scheme.'://'.($_SERVER['HTTP_HOST'] ?? 'localhost');
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>API Keys</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
:root{--brand: <?=esc($brand['primary'])?>}
aside,main{transition:.3s all}
.sidebar-scroll::-webkit-scrollbar{display:none}
.sidebar-scroll{-ms-overflow-style:none;scrollbar-width:none}
.card{box-shadow:0 10px 30px rgba(0,0,0,.06)}
.badge{padding:.25rem .5rem;border-radius:9999px;font-size:.75rem;font-weight:600}
.modal-backdrop{transition:opacity .3s}
.modal-content{transition:transform .3s,opacity .3s}
.skel{background:linear-gradient(90deg,#ececec 25%,#f5f5f5 37%,#ececec 63%);background-size:400% 100%;animation:sh 1.2s ease infinite}
@keyframes sh{0%{background-position:100% 50%}100%{background-position:0 50%}}
pre{position:relative} pre button.copy{position:absolute;top:.5rem;right:.5rem}
code{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace}
</style>
</head>
<body class="bg-gray-100 font-sans">
<div class="relative min-h-screen md:flex">
  <?php include __DIR__.'/../../asset/users/sidebar.php'; ?>

  <main id="main-content" class="flex-1 p-6 md:p-10">
    <div class="flex flex-col lg:flex-row gap-6">
      <!-- Listado -->
      <section class="flex-1">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
          <div>
            <h1 class="text-3xl font-extrabold text-gray-800 tracking-tight">API Keys</h1>
            <p class="text-gray-500 mt-1">Gestiona tus tokens. Se copian al crearlos o al “ver token” (rotación).</p>
          </div>
          <div class="flex items-center mt-4 sm:mt-0 gap-2">
            <div class="relative">
              <input id="q" class="w-56 sm:w-72 rounded-lg border px-3 py-2 pr-9" placeholder="Buscar por etiqueta/proyecto…">
              <svg class="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
            </div>
            <button id="create-key-btn" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg inline-flex items-center gap-2">
              <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
              Nueva key
            </button>
          </div>
        </div>

        <div id="planNotice" class="hidden bg-amber-50 text-amber-800 border border-amber-200 rounded-xl p-4 mb-6">
          Requiere un plan activo. <a href="/users/planes/index.php" class="underline font-medium">Activar plan</a>.
        </div>

        <div class="bg-white rounded-2xl card">
          <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-600">
              <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                <tr>
                  <th class="px-6 py-3">Etiqueta</th>
                  <th class="px-6 py-3">Proyecto</th>
                  <th class="px-6 py-3">Token</th>
                  <th class="px-6 py-3">Plan</th>
                  <th class="px-6 py-3">Pago</th>
                  <th class="px-6 py-3">Estado</th>
                  <th class="px-6 py-3">Creado</th>
                  <th class="px-6 py-3">Último uso</th>
                  <th class="px-6 py-3 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody id="tbody">
                <?php for($i=0;$i<4;$i++): ?>
                <tr class="border-b">
                  <td class="px-6 py-4"><div class="w-36 h-4 rounded skel"></div></td>
                  <td class="px-6 py-4"><div class="w-32 h-4 rounded skel"></div></td>
                  <td class="px-6 py-4"><div class="w-40 h-4 rounded skel"></div></td>
                  <td class="px-6 py-4"><div class="w-20 h-4 rounded skel"></div></td>
                  <td class="px-6 py-4"><div class="w-16 h-4 rounded skel"></div></td>
                  <td class="px-6 py-4"><div class="w-16 h-4 rounded skel"></div></td>
                  <td class="px-6 py-4"><div class="w-20 h-4 rounded skel"></div></td>
                  <td class="px-6 py-4"><div class="w-16 h-4 rounded skel"></div></td>
                  <td class="px-6 py-4 text-right"><div class="w-28 h-8 rounded skel inline-block"></div></td>
                </tr>
                <?php endfor; ?>
              </tbody>
            </table>
          </div>
        </div>

        <div id="pager" class="hidden mt-6 flex items-center justify-center gap-2">
          <button id="prev" class="px-3 py-1.5 rounded border text-sm">Anterior</button>
          <div id="pageInfo" class="text-sm text-gray-500"></div>
          <button id="next" class="px-3 py-1.5 rounded border text-sm">Siguiente</button>
        </div>
      </section>

      <!-- Guía rápida -->
      <aside class="w-full lg:w-96 shrink-0">
        <div class="bg-white rounded-2xl card p-5">
          <h2 class="text-lg font-semibold text-gray-800">Guía rápida</h2>
          <p class="text-gray-500 text-sm mt-1">Header <span class="font-mono">X-API-Key</span>.</p>

          <div class="mt-3">
            <label class="block text-sm text-gray-600 mb-1">Base URL</label>
            <div class="flex items-center gap-2">
              <input id="base" class="w-full border rounded-lg px-3 py-2" value="<?=esc($baseUrl)?>/api" readonly>
              <button class="px-3 py-2 border rounded-lg text-sm" data-copy="#base">Copiar</button>
            </div>
          </div>

          <div class="mt-4">
            <label class="block text-sm text-gray-600 mb-1">Header</label>
            <div class="flex items-center gap-2">
              <input id="hdr" class="w-full border rounded-lg px-3 py-2 font-mono text-xs" value="X-API-Key: &lt;TU_TOKEN&gt;" readonly>
              <button class="px-3 py-2 border rounded-lg text-sm" data-copy="#hdr">Copiar</button>
            </div>
          </div>

          <div class="mt-4">
            <div class="text-xs text-gray-500 mb-1">Ejemplo cURL</div>
            <pre class="bg-gray-900 text-gray-100 rounded-lg p-3 overflow-auto text-xs">
<button class="copy px-2 py-1 bg-white/10 rounded text-white text-[11px]" data-copy="#curl">Copiar</button>
<code id="curl">curl -s \
  -H "X-API-Key: &lt;TU_TOKEN&gt;" \
  "<?=esc($baseUrl)?>/api/tu-endpoint"</code></pre>
          </div>

          <div class="mt-4">
            <div class="text-xs text-gray-500 mb-1">Ejemplo PHP</div>
            <pre class="bg-gray-900 text-gray-100 rounded-lg p-3 overflow-auto text-xs">
<button class="copy px-2 py-1 bg-white/10 rounded text-white text-[11px]" data-copy="#php">Copiar</button>
<code id="php">&lt;?php
$ch = curl_init('<?=esc($baseUrl)?>/api/tu-endpoint');
curl_setopt_array($ch, [
  CURLOPT_HTTPHEADER => ['X-API-Key: &lt;TU_TOKEN&gt;'],
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_TIMEOUT => 10
]);
$resp = curl_exec($ch);
if($resp===false){ throw new Exception(curl_error($ch)); }
echo $resp;
?&gt;</code></pre>
          </div>

          <div class="mt-4">
            <div class="text-xs text-gray-500 mb-1">Ejemplo JS</div>
            <pre class="bg-gray-900 text-gray-100 rounded-lg p-3 overflow-auto text-xs">
<button class="copy px-2 py-1 bg-white/10 rounded text-white text-[11px]" data-copy="#js">Copiar</button>
<code id="js">fetch('<?=esc($baseUrl)?>/api/tu-endpoint', {
  headers: { 'X-API-Key': '&lt;TU_TOKEN&gt;' }
}).then(r => r.json()).then(console.log)</code></pre>
          </div>

          <div class="mt-4 text-xs text-gray-500">
            El token se muestra al crear o al “Ver token” (rota la key).
          </div>
        </div>
      </aside>
    </div>
  </main>
</div>

<!-- Modal crear -->
<div id="create-key-modal" class="fixed inset-0 bg-black/40 hidden items-center justify-center p-4 modal-backdrop opacity-0 z-40">
  <div class="bg-white rounded-2xl w-full max-w-md modal-content transform scale-95 opacity-0">
    <div class="p-6">
      <h3 class="text-lg font-semibold text-gray-800">Crear Nueva API Key</h3>
      <div class="mt-4">
        <label class="block text-sm text-gray-600 mb-1">Etiqueta</label>
        <input id="m_label" class="w-full border rounded-lg px-3 py-2" placeholder="Ej: Backend producción">
      </div>
      <div class="mt-3">
        <label class="block text-sm text-gray-600 mb-1">Proyecto</label>
        <select id="m_project" class="w-full border rounded-lg px-3 py-2"></select>
      </div>
    </div>
    <div class="bg-gray-50 px-6 py-4 rounded-b-2xl flex justify-end gap-2">
      <button id="m_cancel" class="px-4 py-2 rounded-lg border">Cancelar</button>
      <button id="m_create" class="px-4 py-2 rounded-lg bg-blue-600 text-white">Crear</button>
    </div>
  </div>
</div>

<!-- Modal token -->
<div id="token-modal" class="fixed inset-0 bg-black/40 hidden items-center justify-center p-4 modal-backdrop opacity-0 z-40">
  <div class="bg-white rounded-2xl w-full max-w-lg modal-content transform scale-95 opacity-0">
    <div class="p-6">
      <h3 class="text-lg font-semibold text-gray-800">API key</h3>
      <div class="mt-3 p-3 rounded-lg border border-yellow-200 bg-yellow-50 text-yellow-900 text-sm">
        Copia tu API key ahora. Por seguridad no se mostrará nuevamente.
      </div>
      <div class="mt-4 flex items-center gap-2 bg-gray-100 border rounded-lg p-2">
        <span id="tokenText" class="font-mono text-sm text-gray-800 flex-1"></span>
        <button id="copyToken" class="p-2 rounded hover:bg-gray-200" title="Copiar">
          <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
        </button>
      </div>
    </div>
    <div class="bg-gray-50 px-6 py-4 rounded-b-2xl flex justify-end">
      <button id="tokenDone" class="px-4 py-2 rounded-lg bg-blue-600 text-white">Listo</button>
    </div>
  </div>
</div>

<!-- Modal revocar -->
<div id="revoke-key-modal" class="fixed inset-0 bg-black/40 hidden items-center justify-center p-4 modal-backdrop opacity-0 z-40">
  <div class="bg-white rounded-2xl w-full max-w-md modal-content transform scale-95 opacity-0">
    <div class="p-6">
      <h3 class="text-lg font-semibold text-gray-800">Revocar API key</h3>
      <p class="text-gray-600 mt-2">¿Seguro? No se puede deshacer.</p>
    </div>
    <div class="bg-gray-50 px-6 py-4 rounded-b-2xl flex justify-end gap-2">
      <button id="rv_cancel" class="px-4 py-2 rounded-lg border">Cancelar</button>
      <button id="rv_confirm" class="px-4 py-2 rounded-lg bg-rose-600 text-white">Revocar</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div id="toast" class="fixed bottom-5 right-5 hidden px-4 py-3 rounded-lg text-white bg-gray-900/90 z-50"></div>

<script>
/* sidebar móvil */
document.addEventListener('DOMContentLoaded',()=>{
  const sidebar=document.getElementById('sidebar');
  const openBtn=document.getElementById('open-sidebar-mobile');
  const closeBtn=document.getElementById('close-sidebar-mobile');
  const adjust=()=>{ if(innerWidth<768) sidebar?.classList.add('-translate-x-full'); else sidebar?.classList.remove('-translate-x-full'); };
  openBtn?.addEventListener('click',()=>sidebar?.classList.remove('-translate-x-full'));
  closeBtn?.addEventListener('click',()=>sidebar?.classList.add('-translate-x-full'));
  adjust(); addEventListener('resize',adjust);
});

/* helpers */
const CSRF = <?= json_encode($CSRF) ?>;
const toast = (m,ok=true)=>{const t=document.getElementById('toast');t.textContent=m;t.className='fixed bottom-5 right-5 px-4 py-3 rounded-lg text-white z-50 '+(ok?'bg-emerald-600':'bg-rose-600');t.classList.remove('hidden');setTimeout(()=>t.classList.add('hidden'),1800);};
async function api(url,data=null){
  const opt=data?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...data,csrf:CSRF})}:{method:'GET'};
  const r=await fetch(url,opt); let j; try{ j=await r.json(); }catch(e){ alert('Respuesta no válida'); throw e; }
  if(!r.ok||!j.ok){ alert(j?.error||('HTTP '+r.status)); throw new Error(j?.error||('HTTP '+r.status)); }
  return j;
}
function badge(status){
  status=(status||'').toLowerCase();
  if(status.includes('paus')) return '<span class="bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-1 rounded-full">Pausado</span>';
  if(status.includes('rev')) return '<span class="bg-gray-200 text-gray-800 text-xs font-medium px-2.5 py-1 rounded-full">Revocado</span>';
  return '<span class="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-1 rounded-full">Activo</span>';
}

/* copiar */
document.addEventListener('click',e=>{
  const trg=e.target.closest('[data-copy]'); if(trg){ const sel=trg.getAttribute('data-copy'); const el=document.querySelector(sel); if(el){ navigator.clipboard.writeText(el.value || el.textContent).then(()=>toast('Copiado')); } }
  const cp=e.target.closest('.copy'); if(cp){ const sel=cp.getAttribute('data-copy'); const el=document.querySelector(sel); if(el){ navigator.clipboard.writeText(el.textContent).then(()=>toast('Copiado')); } }
});

/* state */
let ITEMS=[], PAGE=1, PER=10, Q='';
let revokeId=null;

/* refs */
const tbody=document.getElementById('tbody');
const pager=document.getElementById('pager'); const prev=document.getElementById('prev'); const next=document.getElementById('next'); const pageInfo=document.getElementById('pageInfo');

/* load list */
async function loadList(){
  const res = await api('/users/api/api/list.php'); // {ok, items:[...]}
  ITEMS = res.items||[];
  render();
}

/* render */
function render(){
  const rows = ITEMS.filter(x=>{
    if(!Q) return true;
    const q=Q.toLowerCase();
    return (x.label||'').toLowerCase().includes(q) || (x.project_name||'').toLowerCase().includes(q);
  });
  const total=rows.length, pages=Math.max(1,Math.ceil(total/PER));
  PAGE=Math.min(PAGE,pages);
  const view=rows.slice((PAGE-1)*PER,(PAGE-1)*PER+PER);

  if(!total){
    tbody.innerHTML = `<tr><td colspan="9" class="px-6 py-10 text-center text-gray-500">No hay API keys.</td></tr>`;
    pager.classList.add('hidden');
    return;
  }
  pager.classList.toggle('hidden', pages<=1);
  pageInfo.textContent=`Página ${PAGE} de ${pages}`;
  prev.disabled=PAGE===1; next.disabled=PAGE===pages;

  tbody.innerHTML = view.map(it=>`
    <tr class="border-b hover:bg-gray-50">
      <td class="px-6 py-4 font-medium text-gray-900">${it.label||'—'}</td>
      <td class="px-6 py-4">${it.project_name||'—'}</td>
      <td class="px-6 py-4 font-mono text-xs">${it.masked || (it.last4 ? '••••••••••'+it.last4 : '—')}</td>
      <td class="px-6 py-4">${it.plan || '—'}</td>
      <td class="px-6 py-4">${it.pago || '—'}</td>
      <td class="px-6 py-4">${badge(it.status||'active')}</td>
      <td class="px-6 py-4">${it.created_at? new Date(it.created_at).toLocaleDateString():'—'}</td>
      <td class="px-6 py-4">${it.last_used? new Date(it.last_used).toLocaleDateString():'—'}</td>
      <td class="px-6 py-4 text-right">
        <button class="text-blue-600 hover:underline rotate" data-id="${it.id}">Ver token</button>
        <span class="mx-2 text-gray-300">|</span>
        <button class="text-red-600 hover:underline revoke" data-id="${it.id}">Revocar</button>
      </td>
    </tr>
  `).join('');
}

/* buscar */
let dq=null; document.getElementById('q').addEventListener('input',e=>{
  clearTimeout(dq); dq=setTimeout(()=>{ Q=e.target.value.trim(); PAGE=1; render(); },250);
});

/* pager */
prev?.addEventListener('click',()=>{ if(PAGE>1){ PAGE--; render(); }});
next?.addEventListener('click',()=>{ PAGE++; render(); });

/* modales */
function showModal(mod,show){
  const backdrop=mod, content=mod.querySelector('.modal-content');
  if(show){ mod.classList.remove('hidden'); mod.classList.add('flex'); setTimeout(()=>{ backdrop.classList.remove('opacity-0'); content.classList.remove('opacity-0','scale-95'); },10); }
  else { backdrop.classList.add('opacity-0'); content.classList.add('opacity-0','scale-95'); setTimeout(()=>{ mod.classList.add('hidden'); mod.classList.remove('flex'); },300); }
}

/* crear */
const mCreate=document.getElementById('create-key-modal');
document.getElementById('create-key-btn').addEventListener('click',async ()=>{
  try{
    const pj = await api('/users/proyectos/api/list.php');
    const sel=document.getElementById('m_project');
    const items=(pj.items||[]).filter(x=>x.id&&x.name);
    sel.innerHTML = items.length ? items.map(x=>`<option value="${x.id}">${x.name}</option>`).join('') : `<option value="0">Sin proyectos</option>`;
  }catch(e){ document.getElementById('m_project').innerHTML='<option value="0">Sin proyectos</option>'; }
  showModal(mCreate,true);
});
document.getElementById('m_cancel').addEventListener('click',()=>showModal(mCreate,false));
document.getElementById('m_create').addEventListener('click',async ()=>{
  const label=document.getElementById('m_label').value.trim()||'Sin etiqueta';
  const project_id=+document.getElementById('m_project').value||0;
  const res=await api('/users/api/api/create.php',{label,project_id});
  showModal(mCreate,false);
  document.getElementById('tokenText').textContent=res.token_plain||'';
  showModal(document.getElementById('token-modal'),true);
  await loadList();
});
document.getElementById('copyToken').addEventListener('click',()=>{
  const t=document.getElementById('tokenText').textContent;
  if(t){ navigator.clipboard.writeText(t).then(()=>toast('Copiado')); }
});
document.getElementById('tokenDone').addEventListener('click',()=>showModal(document.getElementById('token-modal'),false));

/* rotar / revocar */
const mRevoke=document.getElementById('revoke-key-modal');
document.addEventListener('click',async e=>{
  const rot=e.target.closest('.rotate');
  if(rot){
    const id=+rot.dataset.id||0; if(!id) return;
    if(!confirm('Se rotará la key y se mostrará un nuevo token. El anterior dejará de funcionar. ¿Continuar?')) return;
    try{
      const res=await api('/users/api/api/rotate.php',{id});
      document.getElementById('tokenText').textContent=res.token_plain||'';
      showModal(document.getElementById('token-modal'),true);
      await loadList();
    }catch(_){ /* handled in api() */ }
    return;
  }
  const rv=e.target.closest('.revoke');
  if(rv){ revokeId=+rv.dataset.id||0; showModal(mRevoke,true); }
});
document.getElementById('rv_cancel').addEventListener('click',()=>{ revokeId=null; showModal(mRevoke,false); });
document.getElementById('rv_confirm').addEventListener('click',async ()=>{
  if(revokeId){ await api('/users/api/api/revoke.php',{id:revokeId}); toast('Key revocada'); }
  revokeId=null; showModal(mRevoke,false); loadList();
});

/* init */
loadList().catch(()=>{ document.getElementById('tbody').innerHTML=`<tr><td colspan="9" class="px-6 py-10 text-center text-gray-500">No se pudo cargar.</td></tr>`; });
</script>
</body>
</html>
