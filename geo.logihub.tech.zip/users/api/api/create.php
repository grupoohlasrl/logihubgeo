<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../../../config/db.php';
if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'UNAUTHORIZED']); exit; }

function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]); return $db;
}
function b64url(string $b): string { return rtrim(strtr(base64_encode($b), '+/','-_'),'='); }

$uid=(int)$_SESSION['uid'];
$in=json_decode(file_get_contents('php://input'), true) ?: [];
if (empty($in['csrf']) || $in['csrf'] !== ($_SESSION['csrf_api']??'')) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'CSRF']); exit; }

$label=trim((string)($in['label']??'Sin etiqueta'));
$project_id = (int)($in['project_id']??0);

try{
  if ($project_id>0){
    $st=pdo()->prepare("SELECT 1 FROM projects WHERE id=? AND usuario_id=?");
    $st->execute([$project_id,$uid]);
    if(!$st->fetchColumn()){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'PROJECT_NOT_FOUND']); exit; }
  } else { $project_id = null; }

  $token_plain = b64url(random_bytes(24)); /* ~32 chars */
  $token_hash  = hash('sha256',$token_plain);
  $last4 = substr($token_plain,-4);

  $st=pdo()->prepare("INSERT INTO api_keys (usuario_id, project_id, label, token_hash, last4, status, created_at) VALUES (?,?,?,?,?,'active',NOW())");
  $st->execute([$uid,$project_id,$label,$token_hash,$last4]);
  $id = (int)pdo()->lastInsertId();

  echo json_encode([
    'ok'=>true,
    'item'=>[
      'id'=>$id,'label'=>$label,'project_id'=>$project_id,'last4'=>$last4,'status'=>'active'
    ],
    'token_plain'=>$token_plain
  ], JSON_UNESCAPED_UNICODE);
}catch(Throwable $e){
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'SERVER_ERROR','detail'=>$e->getMessage()]);
}
