<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../../../config/db.php';
if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'UNAUTHORIZED']); exit; }

function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]); return $db;
}

$uid=(int)$_SESSION['uid'];
$in=json_decode(file_get_contents('php://input'), true) ?: [];
if (empty($in['csrf']) || $in['csrf'] !== ($_SESSION['csrf_api']??'')) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'CSRF']); exit; }
$id=(int)($in['id']??0);
if($id<=0){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'BAD_ID']); exit; }

try{
  $st=pdo()->prepare("UPDATE api_keys SET status='revoked' WHERE id=? AND usuario_id=?");
  $st->execute([$id,$uid]);
  if(!$st->rowCount()){ http_response_code(404); echo json_encode(['ok'=>false,'error'=>'NOT_FOUND']); exit; }
  echo json_encode(['ok'=>true]);
}catch(Throwable $e){
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'SERVER_ERROR','detail'=>$e->getMessage()]);
}
