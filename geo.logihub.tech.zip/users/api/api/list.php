<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../../config/db.php';
if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'auth']); exit; }

/* DB */
function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]);
  return $db;
}
function has_table(string $t): bool {
  $q = 'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?';
  $st = pdo()->prepare($q); $st->execute([$t]); return (bool)$st->fetchColumn();
}

/* Base: keys + proyecto */
$sql = 'SELECT k.id, k.label, k.status, k.created_at, k.last_used_at AS last_used, k.last4,
               p.name AS project_name
        FROM api_keys k
        LEFT JOIN projects p ON p.id = k.project_id
        WHERE k.usuario_id = :uid
        ORDER BY k.id DESC';
$st = pdo()->prepare($sql);
$st->execute([':uid'=>$_SESSION['uid']]);
$items = $st->fetchAll();

/* Enriquecer con plan y último pago si existen tablas */
$haveSubs = has_table('subscriptions');
$havePlans = has_table('plans');
$havePays = has_table('payments');

if ($haveSubs && $havePlans) {
  $planSt = pdo()->prepare('
    SELECT pl.name
    FROM subscriptions s
    JOIN plans pl ON pl.id = s.plan_id
    WHERE s.usuario_id = ?
    ORDER BY s.created_at DESC
    LIMIT 1
  ');
}
if ($havePays) {
  $paySt = pdo()->prepare('
    SELECT status
    FROM payments
    WHERE usuario_id = ?
    ORDER BY created_at DESC
    LIMIT 1
  ');
}

foreach ($items as &$it) {
  $it['masked'] = $it['last4'] ? ('••••••••••'.$it['last4']) : null;

  $it['plan'] = null;
  if (isset($planSt)) {
    $planSt->execute([$_SESSION['uid']]);
    $row = $planSt->fetch();
    if ($row && isset($row['name'])) $it['plan'] = $row['name'];
  }

  $it['pago'] = null;
  if (isset($paySt)) {
    $paySt->execute([$_SESSION['uid']]);
    $row = $paySt->fetch();
    if ($row && isset($row['status'])) $it['pago'] = $row['status'];
  }
}

echo json_encode(['ok'=>true,'items'=>$items], JSON_UNESCAPED_UNICODE);
