<?php
require __DIR__.'/_bootstrap.php';

try {
  $data = jread();
  $name = trim((string)($data['name'] ?? ''));
  $desc = trim((string)($data['description'] ?? ''));
  if (mb_strlen($name) < 2) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Nombre inválido']); exit; }

  ensure_projects();
  $db  = pdo(); $uid = (int)$_SESSION['uid'];
  $stm = $db->prepare('INSERT INTO projects (usuario_id,name,description,status) VALUES (?,?,?, "Activo")');
  $stm->execute([$uid, $name, $desc ?: null]);
  echo json_encode(['ok'=>true, 'id'=>(int)$db->lastInsertId()]);
} catch (\Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false, 'error'=>'db', 'detail'=>$e->getMessage()]);
}
