<?php
require __DIR__.'/_bootstrap.php';
try{
  $data = jread();
  $id   = (int)($data['id'] ?? 0);
  $act  = (string)($data['status'] ?? '');
  if ($id<=0) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id']); exit; }

  ensure_projects();
  $map = ['activar'=>'Activo','pausar'=>'Pausado','archivar'=>'Archivado'];
  if (!isset($map[$act])) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'status']); exit; }

  $db=pdo(); $uid=(int)$_SESSION['uid'];
  $db->prepare('UPDATE projects SET status=? WHERE id=? AND usuario_id=?')->execute([$map[$act], $id, $uid]);
  echo json_encode(['ok'=>true]);
}catch(\Throwable $e){ http_response_code(500); echo json_encode(['ok'=>false,'error'=>'db','detail'=>$e->getMessage()]); }
