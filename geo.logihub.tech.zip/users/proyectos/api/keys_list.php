<?php
declare(strict_types=1);
require __DIR__.'/_bootstrap.php';
ensure_projects(); ensure_api_keys();

$uid = (int)$_SESSION['uid'];
if (!has_active_plan($uid)) {
  http_response_code(402);
  echo json_encode(['ok'=>false,'error'=>'no_plan','detail'=>'Plan requerido']); exit;
}

$pid = (int)($_GET['project_id'] ?? 0);
if ($pid<=0 || !owns_project($pid,$uid)) {
  http_response_code(404);
  echo json_encode(['ok'=>false,'error'=>'not_found']); exit;
}

$db = pdo();
$s = $db->prepare('SELECT id,label,last4,status,created_at,last_used_at
                   FROM api_keys WHERE usuario_id=? AND project_id=?
                   ORDER BY id DESC');
$s->execute([$uid,$pid]);
$items = $s->fetchAll() ?: [];

echo json_encode(['ok'=>true,'items'=>$items], JSON_UNESCAPED_UNICODE);
