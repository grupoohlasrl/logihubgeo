<?php
declare(strict_types=1);
require __DIR__.'/_bootstrap.php';
ensure_projects(); ensure_api_keys();

$uid = (int)$_SESSION['uid'];
if (!has_active_plan($uid)) {
  http_response_code(402);
  echo json_encode(['ok'=>false,'error'=>'no_plan','detail'=>'Plan requerido']); exit;
}

$in = jread();
$pid   = (int)($in['project_id'] ?? 0);
$label = trim((string)($in['label'] ?? ''));
if ($pid<=0 || mb_strlen($label)<2) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error']=='bad_request'?['ok'=>false]:['ok'=>false]); exit; // hard minimal
}
if (!owns_project($pid,$uid)) {
  http_response_code(404);
  echo json_encode(['ok'=>false,'error'=>'not_found']); exit;
}

$db = pdo();
/* límite simple: 5 activas por proyecto */
$c = $db->prepare('SELECT COUNT(*) FROM api_keys WHERE usuario_id=? AND project_id=? AND status="active"');
$c->execute([$uid,$pid]);
if ((int)$c->fetchColumn() >= 5) {
  http_response_code(409);
  echo json_encode(['ok'=>false,'error'=>'limit','detail'=>'Máximo 5 keys activas por proyecto']); exit;
}

/* generar token y guardar hash */
$token  = 'tok_'.bin2hex(random_bytes(20)); // visible una sola vez
$last4  = substr($token, -4);
$hash   = hash('sha256', $token);

$ins = $db->prepare('INSERT INTO api_keys (usuario_id,project_id,label,token_hash,last4,status) VALUES (?,?,?,?,?,"active")');
$ins->execute([$uid,$pid,$label,$hash,$last4]);

echo json_encode(['ok'=>true,'id'=>(int)$db->lastInsertId(),'token'=>$token,'last4'=>$last4], JSON_UNESCAPED_UNICODE);
