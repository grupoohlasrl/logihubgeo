<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../../../config/db.php';
if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'UNAUTHORIZED']); exit; }

function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]); return $db;
}
$uid=(int)$_SESSION['uid'];

$st=pdo()->prepare("SELECT id,name FROM projects WHERE usuario_id=? ORDER BY name");
$st->execute([$uid]);
$items=$st->fetchAll();

echo json_encode(['ok'=>true,'items'=>$items], JSON_UNESCAPED_UNICODE);
