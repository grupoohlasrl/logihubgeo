<?php
declare(strict_types=1);
require __DIR__.'/_bootstrap.php';
ensure_projects(); ensure_api_keys();

$uid = (int)$_SESSION['uid'];
$in = jread();
$id = (int)($in['id'] ?? 0);
if ($id<=0) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'bad_request']); exit; }

/* validar propiedad */
$db = pdo();
$own = $db->prepare('SELECT project_id FROM api_keys WHERE id=? AND usuario_id=?');
$own->execute([$id,$uid]);
$row = $own->fetch();
if (!$row) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'not_found']); exit; }

$db->prepare('UPDATE api_keys SET status="revoked" WHERE id=? AND usuario_id=?')->execute([$id,$uid]);
echo json_encode(['ok'=>true]);
