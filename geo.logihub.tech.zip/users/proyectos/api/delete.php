<?php
require __DIR__.'/_bootstrap.php';
$data=jread();
$id=(int)($data['id']??0);
if($id<=0){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'id']); exit; }
ensure_projects();
$db=pdo(); $uid=(int)$_SESSION['uid'];
$stmt=$db->prepare('DELETE FROM projects WHERE id=? AND usuario_id=?');
$stmt->execute([$id,$uid]);
echo json_encode(['ok'=>true]);
