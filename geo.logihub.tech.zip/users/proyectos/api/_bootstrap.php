<?php
declare(strict_types=1);
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../../config/db.php';

ini_set('display_errors', '0');

function pdo(): PDO {
  static $db=null; if ($db instanceof PDO) return $db;
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]);
  return $db;
}

/* ---------- JSON helpers ---------- */
function jread(): array {
  $raw = file_get_contents('php://input') ?: '';
  $d = json_decode($raw, true);
  return is_array($d) ? $d : [];
}
function jout(array $data, int $code=200): void {
  if (ob_get_length()) @ob_end_clean();
  if (!headers_sent()) header('Content-Type: application/json; charset=utf-8', true, $code);
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
  exit;
}
function jerr(string $code, string $msg='', int $http=400): void {
  jout(['ok'=>false, 'error'=>$code, 'detail'=>$msg], $http);
}

/* ---------- Auth guards ---------- */
function require_login(): void {
  if (empty($_SESSION['uid'])) jerr('auth','not_logged',401);
}
function owns_project(int $pid, int $uid): bool {
  $s = pdo()->prepare('SELECT 1 FROM projects WHERE id=? AND usuario_id=?');
  $s->execute([$pid,$uid]);
  return (bool)$s->fetchColumn();
}
function has_active_plan(int $uid): bool {
  $s = pdo()->prepare('SELECT 1
    FROM subscriptions s
    JOIN plans p ON p.id=s.plan_id
    WHERE s.usuario_id=? AND s.status="active"
      AND (s.current_period_end IS NULL OR s.current_period_end > NOW())
    ORDER BY s.id DESC LIMIT 1');
  $s->execute([$uid]);
  return (bool)$s->fetchColumn();
}

/* ---------- Ensure tables (MySQL 5.7) ---------- */
function ensure_projects(): void {
  $sql = "
  CREATE TABLE IF NOT EXISTS projects (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(120) NOT NULL,
    description TEXT NULL,
    status ENUM('active','paused','archived') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_proj_user (usuario_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
  pdo()->exec($sql);
}
function ensure_api_keys(): void {
  $sql = "
  CREATE TABLE IF NOT EXISTS api_keys (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NOT NULL,
    project_id BIGINT UNSIGNED NOT NULL,
    label VARCHAR(80) NOT NULL,
    token_hash CHAR(64) NOT NULL,
    last4 CHAR(4) NOT NULL,
    status ENUM('active','revoked') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    last_used_at DATETIME NULL,
    KEY idx_ak_user (usuario_id),
    KEY idx_ak_project (project_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
  pdo()->exec($sql);
}
