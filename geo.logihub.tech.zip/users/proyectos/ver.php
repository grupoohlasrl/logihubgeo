<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../../config/db.php';
if (empty($_SESSION['uid'])) { header('Location: /users/auth/login/'); exit; }

/* ===== DB ===== */
function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]);
  return $db;
}
function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$uid = (int)$_SESSION['uid'];
$db  = pdo();

/* Requiere plan activo */
$sub = $db->prepare('SELECT s.id, s.status, p.name plan_name
                     FROM subscriptions s JOIN plans p ON p.id=s.plan_id
                     WHERE s.usuario_id=? AND s.status="active"
                     ORDER BY s.id DESC LIMIT 1');
$sub->execute([$uid]); $activeSub = $sub->fetch();
if (!$activeSub) { $_SESSION['flash_err']='Necesitas un plan activo.'; header('Location: /users/planes/index.php'); exit; }

/* Proyecto */
$pid = (int)($_GET['id'] ?? 0);
$pr  = $db->prepare('SELECT id,name,description,status,created_at FROM projects WHERE id=? AND usuario_id=? LIMIT 1');
$pr->execute([$pid, $uid]); $project = $pr->fetch();
if (!$project) { http_response_code(404); exit('Proyecto no encontrado'); }

$active='projects';
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Proyecto: <?=esc($project['name'])?></title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
  aside, main { transition: all .3s ease-in-out; }
  .card{ box-shadow:0 10px 30px rgba(0,0,0,.06) }
</style>
</head>
<body class="bg-gray-100">
<div class="relative min-h-screen md:flex">
  <?php include __DIR__ . '/../../asset/users/sidebar.php'; ?>

  <!-- Pegado al sidebar: usamos md:ml-64 y SIN contenedores centrados -->
  <main id="main-content" class="flex-1 p-4 md:p-6 md:ml-64">
    <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-6">
      <div>
        <h1 class="text-2xl sm:text-3xl font-bold text-gray-800">Proyecto: <?=esc($project['name'])?></h1>
        <p class="text-sm text-gray-500">Estado: <span class="font-medium"><?=esc($project['status'])?></span> · Creado: <?=esc($project['created_at'])?></p>
      </div>
      <a href="/users/proyectos/" class="text-blue-600 hover:text-blue-700 text-sm">Volver</a>
    </div>

    <div class="mb-6 p-4 rounded-xl bg-blue-50 text-blue-800 border border-blue-200">
      Plan activo: <span class="font-semibold"><?=esc($activeSub['plan_name'])?></span>. Puedes crear y usar API keys en este proyecto.
    </div>

    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
      <h2 class="text-xl font-semibold text-gray-800">API Keys</h2>
      <button id="btnNew" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
        Nueva key
      </button>
    </div>

    <div class="bg-white rounded-xl card p-4 overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="text-gray-600 bg-gray-50">
          <tr>
            <th class="text-left px-3 py-2">Etiqueta</th>
            <th class="text-left px-3 py-2">Últimos 4</th>
            <th class="text-left px-3 py-2">Estado</th>
            <th class="text-left px-3 py-2">Creado</th>
            <th class="text-left px-3 py-2">Último uso</th>
            <th class="text-right px-3 py-2">Acciones</th>
          </tr>
        </thead>
        <tbody id="tbodyKeys" class="divide-y"></tbody>
      </table>
      <div id="emptyRow" class="hidden text-center text-gray-500 py-8">Sin keys todavía.</div>
    </div>

    <!-- Modal crear -->
    <div id="modal" class="hidden fixed inset-0 z-40 grid place-items-center bg-black/40 p-4">
      <div class="bg-white w-full max-w-md rounded-2xl p-5 shadow-lg">
        <h3 class="text-lg font-semibold mb-3">Nueva API Key</h3>
        <label class="block text-sm mb-1">Etiqueta</label>
        <input id="mLabel" class="w-full border rounded-lg px-3 py-2 mb-4" placeholder="Ej: Producción">
        <div class="flex justify-end gap-2">
          <button id="mCancel" class="px-3 py-2 rounded-lg border">Cancelar</button>
          <button id="mCreate" class="px-3 py-2 rounded-lg bg-blue-600 text-white">Crear</button>
        </div>
      </div>
    </div>

    <!-- Modal token una sola vez -->
    <div id="tokenModal" class="hidden fixed inset-0 z-50 grid place-items-center bg-black/50 p-4">
      <div class="bg-white w-full max-w-lg rounded-2xl p-6 shadow-xl">
        <h3 class="text-lg font-semibold mb-2">Copia tu token ahora</h3>
        <p class="text-sm text-gray-600 mb-3">Se mostrará una sola vez. Guárdalo en un lugar seguro.</p>
        <pre id="tokenValue" class="bg-gray-100 p-3 rounded-lg text-xs overflow-auto"></pre>
        <div class="flex justify-end mt-4">
          <button id="tokenOk" class="px-4 py-2 rounded-lg bg-blue-600 text-white">Entendido</button>
        </div>
      </div>
    </div>

  </main>
</div>

<script>
const pid = <?= (int)$project['id'] ?>;

async function api(url, data=null){
  const opt = data ? {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)} : {};
  const res = await fetch(url, opt);
  const txt = await res.text();
  let j; try{ j=JSON.parse(txt) } catch(e){ throw new Error('Respuesta no válida del servidor'); }
  if(!res.ok || !j.ok){ throw new Error(j.detail || j.error || 'Error'); }
  return j;
}

async function loadKeys(){
  try{
    const j = await api(`/users/proyectos/api/keys_list.php?project_id=${pid}`);
    const tb = document.getElementById('tbodyKeys');
    tb.innerHTML = '';
    if(!j.items.length){ document.getElementById('emptyRow').classList.remove('hidden'); return; }
    document.getElementById('emptyRow').classList.add('hidden');
    j.items.forEach(k=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="px-3 py-2">${k.label}</td>
        <td class="px-3 py-2 font-mono">${k.last4}</td>
        <td class="px-3 py-2">${k.status}</td>
        <td class="px-3 py-2">${k.created_at||''}</td>
        <td class="px-3 py-2">${k.last_used_at||'—'}</td>
        <td class="px-3 py-2 text-right">
          <button data-id="${k.id}" class="revoke text-red-600 hover:underline ${k.status==='revoked'?'opacity-40 pointer-events-none':''}">Revocar</button>
        </td>`;
      tb.appendChild(tr);
    });
  }catch(e){ alert(e.message); }
}

const modal = document.getElementById('modal');
document.getElementById('btnNew').onclick = ()=>{ modal.classList.remove('hidden'); };
document.getElementById('mCancel').onclick = ()=>{ modal.classList.add('hidden'); };
document.getElementById('mCreate').onclick = async ()=>{
  const label = (document.getElementById('mLabel').value||'').trim();
  if(label.length<2){ alert('Etiqueta inválida'); return; }
  try{
    const j = await api('/users/proyectos/api/key_create.php', {project_id: pid, label});
    modal.classList.add('hidden');
    document.getElementById('tokenValue').textContent = j.token;
    document.getElementById('tokenModal').classList.remove('hidden');
    document.getElementById('mLabel').value = '';
    await loadKeys();
  }catch(e){ alert(e.message); }
};
document.getElementById('tokenOk').onclick = ()=>{ document.getElementById('tokenModal').classList.add('hidden'); };

document.getElementById('tbodyKeys').addEventListener('click', async (e)=>{
  const btn = e.target.closest('.revoke'); if(!btn) return;
  if(!confirm('¿Revocar esta key?')) return;
  try{ await api('/users/proyectos/api/key_revoke.php', {id: parseInt(btn.dataset.id,10)||0}); await loadKeys(); }
  catch(err){ alert(err.message); }
});

loadKeys();
</script>
</body>
</html>
