<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../config/db.php';
if (empty($_SESSION['uid'])) { header('Location: /users/auth/login/'); exit; }

/* helpers */
function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]); return $db;
}
function cfg(string $k,$d=null){ static $m=null; if($m===null){ $m=[];
  try{$r=pdo()->query('SELECT k,v FROM app_settings')->fetchAll(); foreach($r as $x){$m[$x['k']]=$x['v'];}}catch(Throwable $e){}
} return $m[$k]??$d; }
$brand=['name'=>cfg('site_name','Geo Logihub'),'logo'=>cfg('site_logo_url','/asset/logo.png'),'primary'=>cfg('brand_primary','#2563eb')];
function esc($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}

/* CSRF para endpoints ajax */
if(empty($_SESSION['csrf_api'])) $_SESSION['csrf_api']=bin2hex(random_bytes(16));
$CSRF = $_SESSION['csrf_api'];
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mis Proyectos</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
:root{--brand: <?=esc($brand['primary'])?>}
aside,main{transition:.3s all}
.sidebar-scroll::-webkit-scrollbar{display:none}
.sidebar-scroll{-ms-overflow-style:none;scrollbar-width:none}
.card{box-shadow:0 10px 30px rgba(0,0,0,.06)}
.badge{padding:.25rem .5rem;border-radius:9999px;font-size:.75rem;font-weight:600}
.skel{background:linear-gradient(90deg,#ececec 25%,#f5f5f5 37%,#ececec 63%);background-size:400% 100%;animation:sh 1.2s ease infinite}
@keyframes sh{0%{background-position:100% 50%}100%{background-position:0 50%}}
</style>
</head>
<body class="bg-gray-100 font-sans">
<div class="relative min-h-screen md:flex">
  <?php include __DIR__.'/../../asset/users/sidebar.php'; ?>

  <!-- pegado al sidebar (sin md:ml-64) -->
  <main id="main-content" class="flex-1 p-6 md:p-10">
    <!-- Header -->
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-6">
      <div>
        <h1 class="text-3xl font-extrabold text-gray-800 tracking-tight">Mis Proyectos</h1>
        <p class="text-gray-500" id="modeHelp">Cargando…</p>
      </div>
      <div class="flex gap-2">
        <div class="relative">
          <input id="q" class="w-56 sm:w-72 rounded-lg border px-3 py-2 pr-9" placeholder="Buscar proyectos…">
          <svg class="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
        </div>
        <button id="btnNew" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg">
          <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
          Nuevo
        </button>
      </div>
    </div>

    <!-- Stats -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <div class="bg-white rounded-2xl card p-5">
        <div class="text-sm text-gray-500">Proyectos</div>
        <div class="text-2xl font-extrabold text-gray-900"><span data-count="0" id="statProjects">0</span></div>
      </div>
      <div class="bg-white rounded-2xl card p-5">
        <div class="text-sm text-gray-500">Tokens activos</div>
        <div class="text-2xl font-extrabold text-gray-900"><span data-count="0" id="statTokens">0</span></div>
      </div>
      <div class="bg-white rounded-2xl card p-5">
        <div class="text-sm text-gray-500">Requests (30 días)</div>
        <div class="text-2xl font-extrabold text-gray-900"><span data-count="0" id="statReq">0</span></div>
      </div>
      <div class="bg-white rounded-2xl card p-5">
        <div class="text-sm text-gray-500">Costo estimado</div>
        <div class="text-2xl font-extrabold text-gray-900">$<span data-count-decimal="0.00" id="statCost">0.00</span></div>
      </div>
    </div>

    <!-- Filtros -->
    <div class="flex items-center gap-2 mb-4">
      <button class="tab px-3 py-1.5 rounded-lg bg-blue-100 text-blue-700" data-status="all">Todos</button>
      <button class="tab px-3 py-1.5 rounded-lg hover:bg-gray-200" data-status="active">Activos</button>
      <button class="tab px-3 py-1.5 rounded-lg hover:bg-gray-200" data-status="paused">Pausados</button>
      <button class="tab px-3 py-1.5 rounded-lg hover:bg-gray-200" data-status="archived">Archivados</button>
    </div>

    <!-- Empty -->
    <div id="empty" class="hidden bg-white rounded-2xl card p-10 text-center mb-6">
      <div class="mx-auto w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mb-4">
        <svg class="w-6 h-6 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/>
          <rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>
        </svg>
      </div>
      <h3 class="text-lg font-semibold text-gray-800">Aún no tienes proyectos</h3>
      <p class="text-gray-500 mt-1">Crea tu primer proyecto para organizar tus integraciones y tokens.</p>
      <button id="btnNew2" class="inline-flex mt-6 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">Crear proyecto</button>
    </div>

    <!-- Grid -->
    <div id="grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"></div>

    <!-- Paginación (client-side simple) -->
    <div id="pager" class="hidden mt-6 flex items-center justify-center gap-2">
      <button id="prev" class="px-3 py-1.5 rounded border text-sm">Anterior</button>
      <div id="pageInfo" class="text-sm text-gray-500"></div>
      <button id="next" class="px-3 py-1.5 rounded border text-sm">Siguiente</button>
    </div>
  </main>
</div>

<!-- Modal crear/editar -->
<div id="modal" class="fixed inset-0 bg-black/40 hidden items-center justify-center p-4 z-40">
  <div class="bg-white rounded-2xl w-full max-w-md p-6">
    <h3 id="m_title" class="text-lg font-semibold mb-4">Nuevo proyecto</h3>
    <div class="mb-3">
      <label class="block text-sm text-gray-600 mb-1">Nombre</label>
      <input id="m_name" class="w-full border rounded-lg px-3 py-2" maxlength="120" required>
    </div>
    <div class="mb-4">
      <label class="block text-sm text-gray-600 mb-1">Descripción</label>
      <textarea id="m_desc" class="w-full border rounded-lg px-3 py-2" rows="3"></textarea>
    </div>
    <input type="hidden" id="m_id" value="0">
    <div class="flex justify-end gap-2">
      <button id="m_cancel" class="px-4 py-2 rounded-lg border">Cancelar</button>
      <button id="m_save" class="px-4 py-2 rounded-lg bg-blue-600 text-white">Guardar</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div id="toast" class="fixed bottom-5 right-5 hidden px-4 py-3 rounded-lg text-white bg-gray-900/90 z-50"></div>

<script>
// sidebar móvil
document.addEventListener('DOMContentLoaded',()=>{
  const sidebar=document.getElementById('sidebar');
  const openBtn=document.getElementById('open-sidebar-mobile');
  const closeBtn=document.getElementById('close-sidebar-mobile');
  const adjust=()=>{ if(innerWidth<768) sidebar.classList.add('-translate-x-full'); else sidebar.classList.remove('-translate-x-full'); };
  if(openBtn) openBtn.addEventListener('click',()=>sidebar.classList.remove('-translate-x-full'));
  if(closeBtn) closeBtn.addEventListener('click',()=>sidebar.classList.add('-translate-x-full'));
  adjust(); addEventListener('resize',adjust);
});

// helpers
const CSRF = <?= json_encode($CSRF) ?>;
function toast(msg, ok=true){
  const t=document.getElementById('toast');
  t.textContent=msg; t.className='fixed bottom-5 right-5 px-4 py-3 rounded-lg text-white z-50 ' + (ok?'bg-emerald-600':'bg-rose-600');
  t.classList.remove('hidden'); setTimeout(()=>t.classList.add('hidden'),2200);
}
async function api(url, data=null){
  const opt = data ? {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...data,csrf:CSRF})} : {method:'GET'};
  const r = await fetch(url, opt);
  let j;
  try{ j=await r.json(); }catch(e){ alert('Respuesta no válida del servidor'); throw e; }
  if(!r.ok || !j.ok){ alert(j?.error||('HTTP '+r.status)); throw new Error(j?.error||('HTTP '+r.status)); }
  return j;
}
function badgeClass(status){
  status=(status||'').toString().toLowerCase();
  if(status.startsWith('paus')||status==='paused') return 'bg-yellow-100 text-yellow-800';
  if(status.startsWith('arch')||status==='archived') return 'bg-gray-200 text-gray-800';
  return 'bg-green-100 text-green-800';
}
function skelCard(){
  return `<div class="bg-white rounded-2xl card p-6">
    <div class="flex justify-between"><div class="w-40 h-6 rounded skel"></div><div class="w-16 h-6 rounded skel"></div></div>
    <div class="mt-3 w-full h-10 rounded skel"></div>
    <div class="mt-4 border-t pt-4 flex gap-2"><div class="w-28 h-9 rounded skel"></div><div class="w-10 h-9 rounded skel"></div></div>
  </div>`;
}
function cardHTML(it){
  const id=it.id||0, name=it.name||'Proyecto', desc=it.description||'—';
  const status=it.status||'Activo';
  const created=it.created_at? new Date(it.created_at).toLocaleDateString(): '—';
  return `
  <div class="bg-white rounded-2xl card p-6 flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
    <div>
      <div class="flex justify-between items-start">
        <h3 class="text-xl font-bold text-gray-800">${name}</h3>
        <span class="badge ${badgeClass(status)}">${status}</span>
      </div>
      <p class="text-gray-500 mt-2">${desc}</p>
    </div>
    <div class="mt-6">
      <div class="flex items-center justify-between text-sm text-gray-500">
        <span>Creado: ${created}</span><span>ID: ${id}</span>
      </div>
      <div class="mt-4 border-t pt-4 flex gap-2 items-center">
        <a href="/users/proyectos/ver.php?id=${id}" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition">Gestionar</a>
        <div class="relative">
          <button class="p-2 bg-gray-200 hover:bg-gray-300 rounded-lg transition action-btn" data-id="${id}">⋮</button>
          <div class="hidden absolute right-0 mt-2 w-40 bg-white rounded-lg shadow p-1 text-sm action-menu" data-id="${id}">
            <button class="w-full text-left px-3 py-2 hover:bg-gray-100 act" data-act="rename" data-id="${id}" data-name="${name}" data-desc="${desc}">Renombrar</button>
            <button class="w-full text-left px-3 py-2 hover:bg-gray-100 act" data-act="activar" data-id="${id}">Activar</button>
            <button class="w-full text-left px-3 py-2 hover:bg-gray-100 act" data-act="pausar" data-id="${id}">Pausar</button>
            <button class="w-full text-left px-3 py-2 hover:bg-gray-100 act" data-act="archivar" data-id="${id}">Archivar</button>
            <button class="w-full text-left px-3 py-2 hover:bg-rose-50 text-rose-600 act" data-act="eliminar" data-id="${id}">Eliminar</button>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

// state
let STATUS='all', Q='', PAGE=1, PER=9, CACHE=[];

// load stats
async function loadStats(){
  try{
    const s=await api('/users/proyectos/api/stats.php');
    animateInt(document.getElementById('statProjects'), s.projects||0);
    animateInt(document.getElementById('statTokens'), s.active_tokens||0);
    animateInt(document.getElementById('statReq'), s.requests_30d||0);
    animateDec(document.getElementById('statCost'), s.cost_usd||0);
  }catch(e){
    // silencioso
  }
}
function animateInt(el, target){
  const dur=600, start=performance.now();
  function tick(t){ const p=Math.min(1,(t-start)/dur); el.textContent=Math.round(target*p).toLocaleString(); if(p<1) requestAnimationFrame(tick); }
  requestAnimationFrame(tick);
}
function animateDec(el, target){
  const dur=600, start=performance.now();
  function tick(t){ const p=Math.min(1,(t-start)/dur); el.textContent=(target*p).toFixed(2); if(p<1) requestAnimationFrame(tick); }
  requestAnimationFrame(tick);
}

// list
const grid=document.getElementById('grid');
const empty=document.getElementById('empty');
const pager=document.getElementById('pager');
const pageInfo=document.getElementById('pageInfo');
const prev=document.getElementById('prev');
const next=document.getElementById('next');
const modeHelp=document.getElementById('modeHelp');

async function loadList(){
  grid.innerHTML = Array.from({length:6}).map(skelCard).join('');
  try{
    const res = await api('/users/proyectos/api/list.php', {status:STATUS, q:Q});
    modeHelp.textContent = res.mode==='projects'
      ? 'Gestiona tus proyectos y sus llaves API.'
      : 'No hay tabla de proyectos. Se muestran grupos por etiqueta de tokens.';
    CACHE = res.items||[];
    renderPage();
  }catch(e){
    grid.innerHTML=''; empty.classList.remove('hidden');
  }
}
function renderPage(){
  const items = CACHE.filter(it=>{
    if(STATUS==='all') return true;
    const s=(it.status||'').toString().toLowerCase();
    if(STATUS==='active') return s.includes('act');
    if(STATUS==='paused') return s.includes('paus');
    if(STATUS==='archived') return s.includes('arch');
    return true;
  }).filter(it=>{
    if(!Q) return true;
    const q=Q.toLowerCase();
    return (it.name||'').toLowerCase().includes(q) || (it.description||'').toLowerCase().includes(q);
  });

  const total = items.length;
  const pages = Math.max(1, Math.ceil(total/PER));
  PAGE = Math.min(PAGE, pages);
  const start=(PAGE-1)*PER, end=start+PER;
  const view = items.slice(start,end);

  if(!total){ empty.classList.remove('hidden'); grid.innerHTML=''; pager.classList.add('hidden'); }
  else{
    empty.classList.add('hidden');
    grid.innerHTML = view.map(cardHTML).join('');
    bindActions();
    if(pages>1){
      pager.classList.remove('hidden'); pageInfo.textContent=`Página ${PAGE} de ${pages}`;
      prev.disabled = PAGE===1; next.disabled = PAGE===pages;
    }else pager.classList.add('hidden');
  }
}

// actions menu
function bindActions(){
  document.querySelectorAll('.action-btn').forEach(b=>{
    b.addEventListener('click', e=>{
      const id=b.dataset.id;
      const menu=document.querySelector(`.action-menu[data-id="${id}"]`);
      document.querySelectorAll('.action-menu').forEach(m=>{ if(m!==menu) m.classList.add('hidden'); });
      menu.classList.toggle('hidden'); e.stopPropagation();
    });
  });
  addEventListener('click', ()=>document.querySelectorAll('.action-menu').forEach(m=>m.classList.add('hidden')));

  document.querySelectorAll('.act').forEach(a=>{
    a.addEventListener('click', async ()=>{
      const id=+a.dataset.id, act=a.dataset.act;
      if(act==='rename'){
        openModal('Editar proyecto', id, a.dataset.name||'', a.dataset.desc||'');
        return;
      }
      if(act==='eliminar'){
        if(!confirm('¿Eliminar proyecto?')) return;
        await api('/users/proyectos/api/delete.php',{id});
        toast('Proyecto eliminado');
      }else{
        await api('/users/proyectos/api/update_status.php',{id, status: act});
        toast('Estado actualizado');
      }
      loadList();
    });
  });
}

// tabs
document.querySelectorAll('.tab').forEach(t=>{
  t.addEventListener('click',()=>{
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('bg-blue-100','text-blue-700'));
    t.classList.add('bg-blue-100','text-blue-700');
    STATUS=t.dataset.status||'all'; PAGE=1; loadList();
  });
});

// search (debounce)
let dq=null; document.getElementById('q').addEventListener('input', e=>{
  clearTimeout(dq); dq=setTimeout(()=>{ Q=e.target.value.trim(); PAGE=1; loadList(); }, 250);
});

// pager
prev.addEventListener('click',()=>{ if(PAGE>1){ PAGE--; renderPage(); }});
next.addEventListener('click',()=>{ PAGE++; renderPage(); });

// modal
const modal=document.getElementById('modal');
const btnNew=document.getElementById('btnNew');
const btnNew2=document.getElementById('btnNew2');
const m_cancel=document.getElementById('m_cancel');
const m_save=document.getElementById('m_save');
function openModal(title='Nuevo proyecto', id=0, name='', desc=''){
  document.getElementById('m_title').textContent=title;
  document.getElementById('m_id').value=id;
  document.getElementById('m_name').value=name;
  document.getElementById('m_desc').value=desc;
  modal.classList.remove('hidden'); modal.classList.add('flex');
}
function closeModal(){ modal.classList.add('hidden'); modal.classList.remove('flex'); }
if(btnNew) btnNew.addEventListener('click', ()=>openModal());
if(btnNew2) btnNew2.addEventListener('click', ()=>openModal());
m_cancel.addEventListener('click', closeModal);
m_save.addEventListener('click', async ()=>{
  const id=+document.getElementById('m_id').value||0;
  const name=document.getElementById('m_name').value.trim();
  const description=document.getElementById('m_desc').value.trim();
  if(name.length<2){ alert('Nombre mínimo 2 caracteres'); return; }
  if(id>0){
    await api('/users/proyectos/api/update.php',{id,name,description});
    toast('Proyecto actualizado');
  }else{
    await api('/users/proyectos/api/create.php',{name,description});
    toast('Proyecto creado');
  }
  closeModal(); loadList();
});

// init
loadStats();
loadList();
</script>
</body>
</html>
