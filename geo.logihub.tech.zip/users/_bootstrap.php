<?php
declare(strict_types=1);

/* === DB === */
$cfgDb = __DIR__ . '/../config/db.php';  // /config/db.php relativo a /users/
if (!file_exists($cfgDb)) {
  http_response_code(500); exit('Config DB no encontrado: '.$cfgDb);
}
require_once $cfgDb; // Debe definir DB_HOST, DB_NAME, DB_USER, DB_PASS (o $pdo)

function pdo(): PDO {
  static $db=null;
  if ($db instanceof PDO) return $db;
  if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) { $db = $GLOBALS['pdo']; return $db; }
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
  return $db;
}

/* === Utils === */
function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/* === Config dinámica ===
   Lee primero app_settings(k,v). Si no existe, intenta config_global(key,value).
*/
function cfg(string $key, $default=null){
  static $cache=null;
  if ($cache===null){
    $cache=[];
    try{
      $rows = pdo()->query('SELECT k as k, v as v FROM app_settings')->fetchAll();
      foreach($rows as $r){ $cache[$r['k']] = $r['v']; }
    } catch(Throwable $e){
      try{
        $rows = pdo()->query('SELECT `key` as k, `value` as v FROM config_global')->fetchAll();
        foreach($rows as $r){ $cache[$r['k']] = $r['v']; }
      } catch(Throwable $e2){ /* sin tabla, cache vacío */ }
    }
  }
  return $cache[$key] ?? $default;
}

/* === Marca === */
function brand(): array {
  return [
    'name'    => cfg('site_name','Geo Logihub'),
    'logo'    => cfg('site_logo_url','/asset/logo.png'),
    'primary' => cfg('brand_primary','#2563eb'),
  ];
}

/* === CSRF / Flash opcional === */
function csrf_token(string $k='csrf'): string { if(empty($_SESSION[$k])) $_SESSION[$k]=bin2hex(random_bytes(16)); return $_SESSION[$k]; }
function csrf_check(string $t,string $k='csrf'): void { if(empty($_SESSION[$k])||!hash_equals($_SESSION[$k],$t)){ http_response_code(400); exit('CSRF'); } }
function flash_set(string $k,string $v): void { $_SESSION[$k]=$v; }
function flash_take(string $k): ?string { if(empty($_SESSION[$k])) return null; $v=$_SESSION[$k]; unset($_SESSION[$k]); return $v; }
