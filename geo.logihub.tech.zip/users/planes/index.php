<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../config/db.php';
if (empty($_SESSION['uid'])) { header('Location: /users/auth/login/'); exit; }

/* helpers */
function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]);
  return $db;
}
function cfg(string $k,$d=null){ static $m=null; if($m===null){ $m=[];
  try{$r=pdo()->query('SELECT k,v FROM app_settings')->fetchAll(); foreach($r as $x){$m[$x['k']]=$x['v'];}}catch(Throwable $e){}
} return $m[$k]??$d; }
function esc($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}

$brand=['name'=>cfg('site_name','Geo Logihub'),'logo'=>cfg('site_logo_url','/asset/logo.png'),'primary'=>cfg('brand_primary','#2563eb')];
if(empty($_SESSION['csrf_api'])) $_SESSION['csrf_api']=bin2hex(random_bytes(16));
$CSRF = $_SESSION['csrf_api'];
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mi Plan</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
:root{--brand: <?=esc($brand['primary'])?>}
aside,main{transition:.3s all}
.sidebar-scroll::-webkit-scrollbar{display:none}
.sidebar-scroll{-ms-overflow-style:none;scrollbar-width:none}
.card{box-shadow:0 10px 30px rgba(0,0,0,.06)}
</style>
</head>
<body class="bg-gray-100 font-sans">
<div class="relative min-h-screen md:flex">
  <?php include __DIR__.'/../../asset/users/sidebar.php'; ?>

  <main id="main-content" class="flex-1 p-6 md:p-10">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
      <div>
        <h1 class="text-3xl font-extrabold text-gray-800 tracking-tight">Mi Plan</h1>
        <p class="text-gray-500 mt-1">Gestiona tu suscripción y límites de uso.</p>
      </div>
      <div class="flex items-center gap-3">
        <span class="text-sm text-gray-600">Mensual</span>
        <label class="relative inline-flex items-center cursor-pointer select-none">
          <input id="billing-toggle" type="checkbox" class="sr-only peer">
          <div class="w-11 h-6 bg-gray-200 rounded-full peer-checked:bg-blue-600 transition-colors"></div>
          <div class="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-5"></div>
        </label>
        <span class="text-sm text-gray-600">Anual</span>
        <span class="bg-green-100 text-green-800 text-xs font-semibold px-2.5 py-1 rounded-full">Ahorra 15%</span>
      </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
      <!-- Plan actual -->
      <aside class="lg:col-span-1">
        <div class="bg-white rounded-2xl card p-6 sticky top-10">
          <h3 class="text-lg font-semibold text-gray-800 mb-1">Tu Plan Actual</h3>
          <p id="cur-name" class="text-gray-500 mb-4 text-sm">—</p>
          <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p class="text-3xl font-bold text-blue-600">
              <span id="cur-price">$0</span><span id="cur-period" class="text-base font-normal text-gray-500">/mes</span>
            </p>
            <p id="cur-renew" class="text-sm text-gray-500 mt-1">—</p>
          </div>
          <ul id="cur-feats" class="mt-4 space-y-2 text-sm text-gray-600"></ul>
          <button id="btn-cancel" class="w-full mt-6 text-sm text-red-600 hover:bg-red-50 font-semibold py-2 px-4 rounded-lg transition">Cancelar suscripción</button>
        </div>
      </aside>

      <!-- Planes -->
      <section class="lg:col-span-3">
        <div id="plans" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6"></div>
      </section>
    </div>
  </main>
</div>

<!-- Toast -->
<div id="toast" class="fixed bottom-5 right-5 hidden px-4 py-3 rounded-lg text-white bg-gray-900/90 z-50"></div>

<script>
const CSRF = <?= json_encode($CSRF) ?>;
const toast = (m,ok=true)=>{const t=document.getElementById('toast');t.textContent=m;t.classList.remove('hidden');t.className='fixed bottom-5 right-5 px-4 py-3 rounded-lg text-white z-50 '+(ok?'bg-emerald-600':'bg-rose-600');setTimeout(()=>t.classList.add('hidden'),1800);};

// API con errores explícitos
async function api(url,data=null){
  const opt = data
    ? { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...data, csrf:CSRF}) }
    : { method:'GET' };
  const r = await fetch(url,opt);
  let j = { ok:false };
  try { j = await r.json(); } catch(_) {}
  if(!r.ok || !j.ok){
    alert(j.error || ('HTTP '+r.status)); // verás: PAYPAL_OFF, MISSING_CREDENTIALS, MAP_MISSING, PP_CREATE, etc.
    console.error('API error', url, j);
    throw new Error(j.error || ('HTTP '+r.status));
  }
  return j;
}

const fmtUSD = n=>'$'+(Number(n).toFixed(2).replace(/\.00$/,''));
const annualPrice = p => Math.round((+p*12)*0.85*100)/100;

let ANNUAL=false, PLANS=[], SUB=null;

function planCard(p){
  const price = ANNUAL? annualPrice(p.price_usd): p.price_usd;
  const period = ANNUAL? '/año':'/mes';
  const isCur = SUB && +SUB.plan_id===+p.id && SUB.status!=='canceled';
  const btnTxt = isCur? 'Tu plan actual' : 'Suscribirme con PayPal';
  const btnCls = isCur? 'w-full mt-auto bg-gray-200 text-gray-500 font-semibold py-2 px-4 rounded-lg cursor-not-allowed'
                      : 'w-full mt-auto bg-blue-600 text-white hover:bg-blue-700 font-semibold py-2 px-4 rounded-lg transition';
  const feats = [
    `${p.monthly_calls.toLocaleString()} peticiones/mes`,
    `${p.rpm_limit} req/min`,
    p.overage_price_per_1k?`$${p.overage_price_per_1k}/1k extra`:''
  ].filter(Boolean).map(x=>`<li class="flex items-start"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-blue-500 mr-2 mt-1 shrink-0"><path d="M20 6 9 17l-5-5"/></svg><span>${x}</span></li>`).join('');
  return `
  <div class="relative border ${isCur?'border-2 border-blue-500 shadow-lg':'shadow-sm'} rounded-xl p-6 flex flex-col h-full bg-white">
    ${isCur?'<span class="absolute -mt-3 right-4 bg-blue-500 text-white text-xs font-bold px-3 py-1 rounded-full">Plan actual</span>':''}
    <h3 class="text-xl font-bold text-gray-800">${p.name}</h3>
    <p class="text-gray-500 mt-1 mb-4 text-sm flex-grow">${p.features||''}</p>
    <div class="mb-6"><span class="text-4xl font-bold">${fmtUSD(price)}</span> <span class="text-gray-500">${period}</span></div>
    <ul class="space-y-3 text-gray-600 text-sm mb-6">${feats}</ul>
    <button class="${btnCls}" ${isCur?'disabled':''} data-plan="${p.id}">${btnTxt}</button>
  </div>`;
}

function render(){
  document.getElementById('cur-name').textContent = SUB? (SUB.plan_name||'—') : '—';
  const base = SUB? +SUB.price_usd : 0;
  const price = ANNUAL? annualPrice(base): base;
  document.getElementById('cur-price').textContent = fmtUSD(price);
  document.getElementById('cur-period').textContent = ANNUAL? '/año' : '/mes';
  document.getElementById('cur-renew').textContent = SUB && SUB.current_period_end ? ('Se renueva el '+ new Date(SUB.current_period_end.replace(' ','T')).toLocaleDateString()) : '—';
  const feats = SUB? [
    `${(+SUB.monthly_calls||0).toLocaleString()} peticiones/mes`,
    `${(+SUB.rpm_limit||0)} req/min`,
    SUB.overage_price_per_1k?`$${SUB.overage_price_per_1k}/1k extra`:''
  ].filter(Boolean) : [];
  document.getElementById('cur-feats').innerHTML = feats.map(x=>`<li class="flex items-center"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-blue-500 mr-2"><path d="M20 6 9 17l-5-5"/></svg>${x}</li>`).join('');

  document.getElementById('plans').innerHTML = PLANS.map(planCard).join('');
  const canCancel = !!(SUB && SUB.status!=='canceled');
  const btn = document.getElementById('btn-cancel');
  btn.disabled = !canCancel; btn.classList.toggle('opacity-40', !canCancel);
}

async function load(){
  const [me,plans] = await Promise.all([
    api('/users/planes/api/me.php'),
    api('/users/planes/api/plans.php')
  ]);
  SUB = me.item||null;
  PLANS = (plans.items||[]).filter(x=>+x.active===1);
  render();
}

/* Crear suscripción y redirigir a PayPal */
document.addEventListener('click', async e=>{
  const btn = e.target.closest('button[data-plan]');
  if(!btn) return;
  btn.disabled = true; btn.classList.add('opacity-60');
  try{
    const plan_id = +btn.dataset.plan; if(!plan_id) return;
    const period = ANNUAL ? 'annual' : 'monthly';
    const res = await api('/ajax/paypal/create.php',{plan_id, period});
    if(res.approve_url){ window.location.href = res.approve_url; return; }
    alert('PP_NO_APPROVE');
  } catch(err){
    console.error(err);
  } finally {
    btn.disabled = false; btn.classList.remove('opacity-60');
  }
});

document.getElementById('btn-cancel').addEventListener('click', async ()=>{
  if(!(SUB && SUB.status!=='canceled')) return;
  if(!confirm('¿Cancelar la suscripción?')) return;
  await api('/users/planes/api/cancel.php',{});
  toast('Suscripción cancelada');
  await load();
});

document.getElementById('billing-toggle').addEventListener('change',e=>{ ANNUAL=!!e.target.checked; render(); });

load().catch(e=>{ alert('HTTP_FAIL'); console.error(e); });
</script>
</body>
</html>
