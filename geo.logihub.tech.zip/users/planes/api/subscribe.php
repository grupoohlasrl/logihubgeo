<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../../config/db.php';
header('Content-Type: application/json; charset=utf-8');
$in=json_decode(file_get_contents('php://input'),true) ?? [];
if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'auth']); exit; }
if (empty($in['csrf']) || $in['csrf']!==($_SESSION['csrf_api']??null)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'csrf']); exit; }
$uid=(int)$_SESSION['uid']; $plan_id=(int)($in['plan_id']??0);
if($plan_id<=0){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'bad_plan']); exit; }

try{
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);

  $p=$db->prepare("SELECT id FROM plans WHERE id=? AND active=1");
  $p->execute([$plan_id]); $plan=$p->fetch();
  if(!$plan){ http_response_code(404); echo json_encode(['ok'=>false,'error'=>'plan_not_found']); exit; }

  $db->beginTransaction();
  $exists=$db->prepare("SELECT id FROM subscriptions WHERE usuario_id=? ORDER BY id DESC LIMIT 1");
  $exists->execute([$uid]); $cur=$exists->fetch();
  $nextEnd=(new DateTimeImmutable('+1 month'))->setTime(23,59,59)->format('Y-m-d H:i:s');

  if($cur){
    $up=$db->prepare("UPDATE subscriptions SET plan_id=?, status='active', current_period_end=? WHERE id=?");
    $up->execute([$plan_id,$nextEnd,$cur['id']]);
  }else{
    $ins=$db->prepare("INSERT INTO subscriptions(usuario_id,plan_id,status,current_period_end) VALUES(?,?, 'active', ?)");
    $ins->execute([$uid,$plan_id,$nextEnd]);
  }
  $db->commit();
  echo json_encode(['ok'=>true]);
}catch(Throwable $e){ if($db && $db->inTransaction()) $db->rollBack(); http_response_code(500); echo json_encode(['ok'=>false,'error'=>'server']); }
