<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../../config/db.php';
header('Content-Type: application/json; charset=utf-8');
if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'auth']); exit; }
try{
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
  $q=$db->query("SELECT id,code,name,monthly_calls,rpm_limit,price_usd,overage_price_per_1k,features,active FROM plans ORDER BY price_usd ASC, id ASC");
  echo json_encode(['ok'=>true,'items'=>$q->fetchAll()]);
}catch(Throwable $e){ http_response_code(500); echo json_encode(['ok'=>false,'error'=>'server']); }
