<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../../config/db.php';
header('Content-Type: application/json; charset=utf-8');
if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'auth']); exit; }
$uid=(int)$_SESSION['uid'];
try{
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
  $sql="SELECT s.id as sub_id,s.usuario_id,s.plan_id,s.status,s.current_period_end,
              p.name as plan_name,p.price_usd,p.monthly_calls,p.rpm_limit,p.overage_price_per_1k,p.features,p.active
        FROM subscriptions s
        JOIN plans p ON p.id=s.plan_id
        WHERE s.usuario_id=? 
        ORDER BY s.id DESC LIMIT 1";
  $st=$db->prepare($sql); $st->execute([$uid]); $row=$st->fetch();
  if(!$row){
    $p=$db->query("SELECT id,name,price_usd,monthly_calls,rpm_limit,overage_price_per_1k,features,active FROM plans WHERE code='FREE' LIMIT 1")->fetch();
    $row=$p?[
      'sub_id'=>null,'usuario_id'=>$uid,'plan_id'=>$p['id'],'status'=>'trial','current_period_end'=>null,
      'plan_name'=>$p['name'],'price_usd'=>$p['price_usd'],'monthly_calls'=>$p['monthly_calls'],'rpm_limit'=>$p['rpm_limit'],
      'overage_price_per_1k'=>$p['overage_price_per_1k'],'features'=>$p['features'],'active'=>$p['active']
    ]:null;
  }
  echo json_encode(['ok'=>true,'item'=>$row]);
}catch(Throwable $e){ http_response_code(500); echo json_encode(['ok'=>false,'error'=>'server']); }
