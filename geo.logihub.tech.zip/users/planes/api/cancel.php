<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../../config/db.php';
header('Content-Type: application/json; charset=utf-8');
$in=json_decode(file_get_contents('php://input'),true) ?? [];
if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'auth']); exit; }
if (empty($in['csrf']) || $in['csrf']!==($_SESSION['csrf_api']??null)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'csrf']); exit; }
$uid=(int)$_SESSION['uid'];

try{
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
  $st=$db->prepare("UPDATE subscriptions SET status='canceled' WHERE usuario_id=? ORDER BY id DESC LIMIT 1");
  $st->execute([$uid]);
  echo json_encode(['ok'=>true]);
}catch(Throwable $e){ http_response_code(500); echo json_encode(['ok'=>false,'error'=>'server']); }
