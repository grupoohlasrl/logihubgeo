<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../../lib/paypal.php';
header('Content-Type: application/json; charset=utf-8');

$in=json_decode(file_get_contents('php://input'),true)??[];
if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'auth']); exit; }
if (empty($in['csrf']) || $in['csrf']!==($_SESSION['csrf_api']??null)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'csrf']); exit; }

try{
  if((int)cfg('paypal_active','0')!==1) throw new RuntimeException('paypal_disabled');
  $uid=(int)$_SESSION['uid']; $plan_id=(int)($in['plan_id']??0);
  $period = ($in['period']??'monthly')==='annual' ? 'annual':'monthly';
  if($plan_id<=0){ http_response_code(400); echo json_encode(['ok'=>false,'error'=>'bad_plan']); exit; }

  $pp=new PayPal();
  $r=$pp->createSubscription($uid,$plan_id,$period);
  echo json_encode(['ok'=>true,'id'=>$r['id'],'approve_url'=>$r['approve_url']]);
}catch(Throwable $e){
  http_response_code(500); echo json_encode(['ok'=>false,'error'=>'SERVER_ERROR']);
}
