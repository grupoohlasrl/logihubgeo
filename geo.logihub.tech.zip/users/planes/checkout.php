<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../../config/db.php';

if (empty($_SESSION['uid'])) { header('Location: /users/auth/login/'); exit; }
if (empty($_SESSION['selected_plan_id'])) { header('Location: /users/planes/index.php'); exit; }

/* DB + utils */
function pdo(): PDO {
  static $pdo;
  if ($pdo instanceof PDO) return $pdo;
  $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $pdo = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
  return $pdo;
}
function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf_token($k='csrf_checkout'){ if(empty($_SESSION[$k])) $_SESSION[$k]=bin2hex(random_bytes(16)); return $_SESSION[$k]; }
function csrf_check($t,$k='csrf_checkout'){ if(empty($_SESSION[$k])||!hash_equals($_SESSION[$k],$t)){ http_response_code(400); exit('CSRF'); } }

/* Cargar plan */
$db   = pdo();
$uid  = (int)$_SESSION['uid'];
$planId = (int)$_SESSION['selected_plan_id'];

$st = $db->prepare('SELECT id, code, name, price_usd, monthly_calls, rpm_limit FROM plans WHERE id=? AND active=1');
$st->execute([$planId]);
$plan = $st->fetch();
if (!$plan) { $_SESSION['flash_err']='Plan no válido'; header('Location:/users/planes/index.php'); exit; }

$isFree = ((float)$plan['price_usd']) <= 0.0;

/* POST */
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_check($_POST['csrf'] ?? '');

  if ($isFree) {
    try {
      $db->beginTransaction();

      // tomar la última suscripción creada al plan (estado trial o similar)
      $r = $db->prepare('SELECT id FROM subscriptions WHERE usuario_id=? AND plan_id=? ORDER BY id DESC LIMIT 1');
      $r->execute([$uid,$planId]);
      $sub = $r->fetch();

      if ($sub) {
        // solo cambia estado; no tocar columnas opcionales
        $db->prepare('UPDATE subscriptions SET status="active" WHERE id=?')
           ->execute([(int)$sub['id']]);
      } else {
        // crear si no existía
        $db->prepare('INSERT INTO subscriptions (usuario_id,plan_id,provider,status) VALUES (?,?, "free", "active")')
           ->execute([$uid,$planId]);
      }

      // no registrar pago para free
      $db->commit();
      $_SESSION['flash_ok']='Plan gratuito activado';
      header('Location: /users/panel/index.php'); exit;

    } catch (Throwable $e) {
      $db->rollBack();
      $_SESSION['flash_err']='No se pudo activar el plan gratuito';
      header('Location:/users/planes/index.php'); exit;
    }
  } else {
    // Plan de pago → crear orden PayPal
    header('Location: /users/planes/paypal-create.php'); exit;
  }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Checkout</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body{background:#0f172a}
    .card{border:0;border-radius:1rem;box-shadow:0 10px 30px rgba(0,0,0,.25)}
  </style>
</head>
<body class="text-light">
<div class="container py-4">
  <div class="row justify-content-center">
    <div class="col-lg-7">
      <div class="card p-4 bg-dark text-light">
        <h4 class="mb-3">Confirmar plan</h4>
        <div class="mb-3 d-flex justify-content-between">
          <div>
            <div class="h5 mb-1"><?=esc($plan['name'])?></div>
            <div class="text-secondary">Incluye <?= (int)$plan['monthly_calls'] ?> llamadas/mes · Límite <?= (int)$plan['rpm_limit'] ?> rpm</div>
          </div>
          <div class="text-end">
            <div class="display-6">$<?= number_format((float)$plan['price_usd'], 2) ?></div>
            <div class="text-secondary">USD</div>
          </div>
        </div>

        <form method="post" class="mt-3">
          <input type="hidden" name="csrf" value="<?=esc(csrf_token())?>">
          <button class="btn btn-primary btn-lg w-100" type="submit">
            <?= $isFree ? 'Activar gratis' : 'Pagar con PayPal' ?>
          </button>
        </form>

        <div class="text-center mt-3">
          <a class="link-light" href="/users/planes/index.php">Cambiar plan</a>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
