<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../lib/paypal.php';

if (empty($_SESSION['uid'])) { header('Location: /users/auth/login/'); exit; }
$db = pdo();
$uid = (int)$_SESSION['uid'];
$order_id = (string)($_GET['token'] ?? '');

if ($order_id) {
  $db->prepare('UPDATE payments SET status="canceled", updated_at=NOW() WHERE provider="paypal" AND provider_order_id=? AND usuario_id=?')
     ->execute([$order_id,$uid]);
}
$_SESSION['flash_err'] = 'Pago cancelado por el usuario';
header('Location: /users/planes/index.php'); exit;
