<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../lib/paypal.php';

function csrf_check($t,$k='csrf_checkout'){ if(empty($_SESSION[$k])||!hash_equals($_SESSION[$k],$t)){ http_response_code(400); exit('CSRF'); } }

if (empty($_SESSION['uid'])) { header('Location: /users/auth/login/'); exit; }
if ($_SERVER['REQUEST_METHOD']!=='POST') { header('Location: /users/planes/checkout.php'); exit; }
csrf_check($_POST['csrf']??'');

if (empty($_SESSION['selected_plan_id'])){ header('Location: /users/planes/index.php'); exit; }

$db = pdo();
$uid = (int)$_SESSION['uid'];
$plan_id = (int)$_SESSION['selected_plan_id'];

$st = $db->prepare('SELECT id,name,price_cents,currency,billing_interval FROM plans WHERE id=? AND active=1');
$st->execute([$plan_id]); $plan = $st->fetch();
if (!$plan) { $_SESSION['flash_err']='Plan inválido'; header('Location: /users/planes/index.php'); exit; }

$amount = number_format($plan['price_cents']/100, 2, '.', '');
$return = (string)cfg_get('paypal_return_url','/users/planes/paypal-return.php');
$cancel = (string)cfg_get('paypal_cancel_url','/users/planes/paypal-cancel.php');

try {
  $order = paypal_create_order($amount, $plan['currency'], $return, $cancel, (string)cfg_get('brand_name','Geo Logihub'));
  $order_id = $order['id'] ?? null;
  if (!$order_id) throw new RuntimeException('Orden sin ID');

  $db->prepare('INSERT INTO payments (usuario_id,plan_id,provider,provider_order_id,status,amount_usd,currency,details)
                VALUES (?,?,?,?,?,?,?,?)')
     ->execute([$uid,$plan_id,'paypal',$order_id, (string)($order['status'] ?? 'created'), $amount, $plan['currency'], json_encode($order)]);

  $approve = null;
  foreach (($order['links'] ?? []) as $ln) { if (($ln['rel'] ?? '') === 'approve') { $approve = $ln['href']; break; } }
  if (!$approve) throw new RuntimeException('Sin link de aprobación');
  header('Location: '.$approve); exit;

} catch (\Throwable $e) {
  $_SESSION['flash_err'] = 'PayPal: '.$e->getMessage();
  header('Location: /users/planes/index.php'); exit;
}
