<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../lib/paypal.php';

if (empty($_SESSION['uid'])) { header('Location: /users/auth/login/'); exit; }

$db = pdo();
$uid = (int)$_SESSION['uid'];
$order_id = (string)($_GET['token'] ?? ''); // PayPal v2 retorna ?token=ORDER-ID

if ($order_id === '') { $_SESSION['flash_err']='Token faltante'; header('Location: /users/planes/index.php'); exit; }

// verifica que exista un pago creado para este usuario
$pay = $db->prepare('SELECT id,plan_id,status FROM payments WHERE provider="paypal" AND provider_order_id=? AND usuario_id=? LIMIT 1');
$pay->execute([$order_id,$uid]); $payment = $pay->fetch();
if (!$payment) { $_SESSION['flash_err']='Orden desconocida'; header('Location: /users/planes/index.php'); exit; }

try {
  $cap = paypal_capture($order_id);
  $status = strtoupper((string)($cap['status'] ?? ''));
  $completed = ($status === 'COMPLETED');

  // actualizar pago
  $db->prepare('UPDATE payments SET status=?, details=?, updated_at=NOW() WHERE id=?')
     ->execute([$status ?: 'COMPLETED', json_encode($cap), (int)$payment['id']]);

  if ($completed) {
    // activar suscripción pendiente más reciente del usuario al plan
    $s = $db->prepare('SELECT id,billing_interval FROM plans WHERE id=?'); $s->execute([(int)$payment['plan_id']]);
    $pl = $s->fetch();
    $interval = $pl ? ($pl['billing_interval'] ?? 'month') : 'month';

    // cancela otras y activa esta
    $db->beginTransaction();
    try {
      $db->prepare('UPDATE subscriptions SET status="canceled" WHERE user_id=? AND status IN ("pending","active","past_due")')
         ->execute([$uid]);

      $db->prepare('INSERT INTO subscriptions (user_id,plan_id,provider,provider_subscription_id,status,current_period_start,current_period_end,last_payment_at)
                    VALUES (?,?, "paypal", ?, "active", NOW(), ?, NOW())')
         ->execute([$uid,(int)$payment['plan_id'],$order_id, period_end($interval)]);

      $db->commit();
    } catch (\Throwable $e) {
      $db->rollBack();
      // no romper al usuario si el cobro fue OK; deja pago en COMPLETED
    }
    $_SESSION['flash_ok'] = 'Pago completado';
    header('Location: /users/panel/index.php'); exit;
  } else {
    $_SESSION['flash_err'] = 'Estado PayPal: '.$status;
    header('Location: /users/planes/index.php'); exit;
  }

} catch (\Throwable $e) {
  $_SESSION['flash_err'] = 'Error al capturar: '.$e->getMessage();
  header('Location: /users/planes/index.php'); exit;
}
