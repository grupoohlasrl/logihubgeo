<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../../config/db.php';
if (empty($_SESSION['uid'])) { header('Location: /users/auth/login/'); exit; }

/* DB */
function pdo(): PDO {
  static $db=null; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]);
  return $db;
}
function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/* Marca desde app_settings */
function cfg(string $k,$d=null){ static $m=null; if($m===null){ $m=[];
  try{$r=pdo()->query('SELECT k,v FROM app_settings')->fetchAll(); foreach($r as $x){$m[$x['k']]=$x['v'];}}catch(Throwable $e){}
} return $m[$k]??$d; }
$brand=['name'=>cfg('site_name','Geo Logihub'),'logo'=>cfg('site_logo_url','/asset/logo.png'),'primary'=>cfg('brand_primary','#2563eb')];

/* Usuario */
$db=pdo();
$me=$db->prepare('SELECT id,name,email FROM users WHERE id=?'); $me->execute([(int)$_SESSION['uid']]); $me=$me->fetch() ?: ['name'=>'Usuario','email'=>''];
$user=['name'=>$me['name']??'Usuario','avatar'=>'https://placehold.co/40x40/7c3aed/ffffff?text='.urlencode(mb_substr($me['name']??'U',0,1))];

/* Suscripción + plan */
$sub=$db->prepare('SELECT s.status, p.name plan_name, p.price_usd, p.monthly_calls, p.rpm_limit
                   FROM subscriptions s JOIN plans p ON p.id=s.plan_id
                   WHERE s.usuario_id=? ORDER BY s.id DESC LIMIT 1');
$sub->execute([(int)$_SESSION['uid']]); $sub=$sub->fetch();
$planName = $sub['plan_name'] ?? 'Sin plan';
$planStatus = $sub['status'] ?? 'sin plan';
$monthlyCalls = max(0, (int)($sub['monthly_calls'] ?? 0));
$rpm = max(0, (int)($sub['rpm_limit'] ?? 0));
$priceUsd = (float)($sub['price_usd'] ?? 0);

/* Métricas demo */
$usoUltimos7 = [450,600,550,750,800,650,900];
$totalMes = array_sum($usoUltimos7);
$maxUso = max($usoUltimos7) ?: 1;
$tokensActivos = 0;
$progress = ($monthlyCalls>0) ? min(100, round(($totalMes/$monthlyCalls)*100)) : 0;

/* Sparkline */
$w=280; $h=60; $pad=4;
$step = count($usoUltimos7)>1 ? ($w-2*$pad)/(count($usoUltimos7)-1) : 0;
$points=[];
foreach($usoUltimos7 as $i=>$v){
  $x = $pad + $i*$step;
  $y = $pad + ($h-2*$pad)*(1-($v/$maxUso));
  $points[] = round($x,1).','.round($y,1);
}
$active='panel';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    :root{ --brand: <?=esc($brand['primary'])?>; }
    aside, main { transition: all .3s ease-in-out; }
    .sidebar-scroll::-webkit-scrollbar { display:none; }
    .sidebar-scroll { -ms-overflow-style:none; scrollbar-width:none; }
    @keyframes grow { from{transform:scaleY(0)} to{transform:scaleY(1)} }
    .chart-bar{ transform-origin:bottom; animation:grow .5s ease-out forwards; }
    .card{ box-shadow:0 10px 30px rgba(0,0,0,.06) }
    .ring{ width:64px;height:64px;border-radius:9999px;background:conic-gradient(var(--brand) calc(var(--p)*1%), #e5e7eb 0);display:grid;place-items:center;}
  </style>
</head>
<body class="bg-gray-100 font-sans">
  <div class="relative min-h-screen md:flex">
    <?php include __DIR__.'/../../asset/users/sidebar.php'; ?>

    <main id="main-content" class="flex-1 p-6 md:p-10">
      <div class="flex justify-between items-center mb-8">
        <button id="open-sidebar-mobile" class="md:hidden text-gray-600">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
        </button>
        <h1 class="text-3xl font-extrabold text-gray-800 tracking-tight">Dashboard de Uso</h1>
        <a href="/users/planes/index.php" class="hidden md:inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
          Cambiar plan
          <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m9 18 6-6-6-6"/></svg>
        </a>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white p-6 rounded-2xl card relative overflow-hidden">
          <div class="flex items-start justify-between">
            <div>
              <p class="text-sm font-medium text-gray-500">Plan Actual</p>
              <p class="text-2xl font-extrabold text-gray-900" id="planName"><?=esc($planName)?></p>
              <p class="text-xs text-gray-500 mt-1">Estado: <span class="font-medium"><?=esc($planStatus)?></span></p>
            </div>
            <div class="ring" style="--p: <?= (int)$progress ?>;">
              <div class="text-sm font-semibold"><?= (int)$progress ?>%</div>
            </div>
          </div>
          <p class="mt-3 text-xs text-gray-500">Uso mensual vs límite <?= $monthlyCalls ?: 0 ?> req.</p>
          <?php if (strtolower($planName)==='free' || $priceUsd<=0): ?>
            <a href="/users/planes/index.php" class="inline-flex mt-3 text-blue-600 hover:text-blue-700 text-sm font-medium">Mejorar plan</a>
          <?php endif; ?>
        </div>

        <div class="bg-white p-6 rounded-2xl card">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm font-medium text-gray-500">Tokens Activos</p>
              <p class="text-2xl font-extrabold text-gray-900"><span data-count="<?= (int)$tokensActivos ?>">0</span></p>
            </div>
            <div class="bg-green-100 p-3 rounded-full">
              <svg class="w-6 h-6 text-green-600" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M2 18v3c0 .6.4 1 1 1h4v-3h3v-3h2l1.4-1.4a6.5 6.5 0 1 0-4-4Z"/><circle cx="16.5" cy="7.5" r=".5"/></svg>
            </div>
          </div>
          <p class="mt-3 text-xs text-gray-500">Límite del plan: <?= $monthlyCalls ? number_format($monthlyCalls) : '—' ?> / mes · <?= $rpm ?> rpm</p>
        </div>

        <div class="bg-white p-6 rounded-2xl card">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm font-medium text-gray-500">Uso del Mes</p>
              <p class="text-2xl font-extrabold text-gray-900"><span data-count="<?= (int)$totalMes ?>">0</span></p>
              <p class="text-xs text-gray-500 mt-1">Requests</p>
            </div>
            <div class="bg-indigo-100 p-3 rounded-full">
              <svg class="w-6 h-6 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
          </div>
        </div>

        <div class="bg-white p-6 rounded-2xl card">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm font-medium text-gray-500">Costo Estimado</p>
              <p class="text-2xl font-extrabold text-gray-900">$<span data-count-decimal="<?= number_format(0,2,'.','') ?>">0.00</span></p>
              <p class="text-xs text-gray-500 mt-1">USD</p>
            </div>
            <div class="bg-yellow-100 p-3 rounded-full">
              <svg class="w-6 h-6 text-yellow-600" viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="12" x2="12" y1="2" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
          </div>
        </div>
      </div>

      <div class="bg-white p-6 rounded-2xl card mb-8">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-lg font-semibold text-gray-800">Uso de API (Últimos 7 días)</h3>
          <div class="hidden sm:flex items-center gap-2 text-xs text-gray-500">
            <span class="inline-block w-3 h-3 rounded bg-blue-500/80"></span> Requests
          </div>
        </div>

        <div class="mb-4">
          <svg width="<?= $w ?>" height="<?= $h ?>" viewBox="0 0 <?= $w ?> <?= $h ?>">
            <polyline points="<?= esc(implode(' ',$points)) ?>" fill="none" stroke="rgba(59,130,246,0.6)" stroke-width="2"/>
          </svg>
        </div>

        <div class="flex items-end justify-between h-56 space-x-2 sm:space-x-4">
          <?php
            $labels=['Hace 7d','Hace 6d','Hace 5d','Hace 4d','Hace 3d','Ayer','Hoy'];
            foreach($usoUltimos7 as $i=>$v):
              $pct = max(6, (int)round(($v/$maxUso)*92));
          ?>
            <div class="flex flex-col items-center w-full">
              <div class="chart-bar w-full bg-blue-500/80 rounded-t-md" style="height: <?= $pct ?>%;"></div>
              <p class="text-xs text-gray-500 mt-2"><?= esc($labels[$i]) ?></p>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <a href="/users/api/index.php" class="bg-white rounded-xl card p-5 hover:shadow-lg transition flex items-center justify-between">
          <div>
            <div class="font-semibold text-gray-800">Crear API Key</div>
            <div class="text-sm text-gray-500">Genera un nuevo token</div>
          </div>
          <svg class="w-6 h-6 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
        </a>
        <a href="/users/planes/index.php" class="bg-white rounded-xl card p-5 hover:shadow-lg transition flex items-center justify-between">
          <div>
            <div class="font-semibold text-gray-800">Ver planes</div>
            <div class="text-sm text-gray-500">Cámbiate cuando quieras</div>
          </div>
          <svg class="w-6 h-6 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m9 18 6-6-6-6"/></svg>
        </a>
        <a href="/users/soporte/" class="bg-white rounded-xl card p-5 hover:shadow-lg transition flex items-center justify-between">
          <div>
            <div class="font-semibold text-gray-800">Soporte</div>
            <div class="text-sm text-gray-500">Abre un ticket</div>
          </div>
          <svg class="w-6 h-6 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h10"/><path d="M16 5h2"/><path d="M19 8h-2"/></svg>
        </a>
      </div>

    </main>
  </div>

  <script>
  document.querySelectorAll('[data-count]').forEach(el=>{
    const target = parseInt(el.getAttribute('data-count'),10)||0;
    const dur = 600; const start = performance.now();
    function tick(t){
      const p = Math.min(1, (t-start)/dur);
      el.textContent = Math.round(target*p).toLocaleString();
      if(p<1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  });
  document.querySelectorAll('[data-count-decimal]').forEach(el=>{
    const target = parseFloat(el.getAttribute('data-count-decimal'))||0;
    const dur = 600; const start = performance.now();
    function tick(t){
      const p = Math.min(1, (t-start)/dur);
      el.textContent = (target*p).toFixed(2);
      if(p<1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  });
  </script>
</body>
</html>
