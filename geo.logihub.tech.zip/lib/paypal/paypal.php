<?php
// /paypal/lib/paypal.php
declare(strict_types=1);
require_once __DIR__.'/../../config/db.php';

final class PayPal {
  private string $env; private string $client; private string $secret; private string $base;

  public function __construct() {
    $pdo = $this->pdo();
    $this->env = $this->getCfg($pdo,'paypal_env','sandbox') ?? 'sandbox';
    if ($this->env!=='live') $this->env='sandbox';
    $this->client = $this->env==='live'
      ? (string)($this->getCfg($pdo,'paypal_client_id_live','') ?? '')
      : (string)($this->getCfg($pdo,'paypal_client_id_sandbox','') ?? '');
    $this->secret = $this->env==='live'
      ? (string)($this->getCfg($pdo,'paypal_client_secret_live','') ?? '')
      : (string)($this->getCfg($pdo,'paypal_client_secret_sandbox','') ?? '');
    $this->base = $this->env==='live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
    if ($this->client==='' || $this->secret==='') throw new RuntimeException('MISSING_CREDENTIALS');
  }
  public function env(): string { return $this->env; }

  /* API core */
  private function token(): string {
    $ch=curl_init($this->base.'/v1/oauth2/token');
    curl_setopt_array($ch,[
      CURLOPT_POST=>true,
      CURLOPT_POSTFIELDS=>'grant_type=client_credentials',
      CURLOPT_USERPWD=>$this->client.':'.$this->secret,
      CURLOPT_RETURNTRANSFER=>true,
      CURLOPT_TIMEOUT=>20,
    ]);
    $res=curl_exec($ch); if($res===false) throw new RuntimeException('TOKEN_CURL');
    $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
    $j=json_decode($res,true) ?: [];
    if($code!==200 || empty($j['access_token'])) throw new RuntimeException('TOKEN_HTTP '.$code);
    return $j['access_token'];
  }
  private function req(string $method, string $path, array $body=null): array {
    $tk=$this->token();
    $ch=curl_init($this->base.$path);
    $hdr=['Authorization: Bearer '.$tk,'Content-Type: application/json'];
    curl_setopt_array($ch,[
      CURLOPT_CUSTOMREQUEST=>$method,
      CURLOPT_RETURNTRANSFER=>true,
      CURLOPT_HTTPHEADER=>$hdr,
      CURLOPT_TIMEOUT=>25,
    ]);
    if($body!==null){ curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($body,JSON_UNESCAPED_SLASHES)); }
    $res=curl_exec($ch); if($res===false) throw new RuntimeException('REQ_CURL');
    $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
    $j=json_decode($res,true) ?: [];
    if($code>=300){ throw new RuntimeException('REQ_HTTP '.$code.': '.($j['name'] ?? '')); }
    return $j;
  }

  /* Public API */
  public function createSubscription(string $ppPlanId, string $customId, string $returnUrl, string $cancelUrl): array {
    $body=[
      'plan_id'=>$ppPlanId,
      'custom_id'=>$customId,
      'application_context'=>[
        'brand_name'=>$this->brand(),
        'user_action'=>'SUBSCRIBE_NOW',
        'return_url'=>$returnUrl,
        'cancel_url'=>$cancelUrl,
      ],
    ];
    return $this->req('POST','/v1/billing/subscriptions',$body);
  }
  public function getSubscription(string $id): array {
    return $this->req('GET','/v1/billing/subscriptions/'.rawurlencode($id));
  }

  public function verifyWebhook(array $hdr, array $event): bool {
    // opcional: confiar en IPN/Webhook ID. Aquí solo valida que el ID configurado exista.
    $pdo=$this->pdo();
    $wh = $this->env==='live'
      ? (string)($this->getCfg($pdo,'paypal_webhook_id_live','') ?? '')
      : (string)($this->getCfg($pdo,'paypal_webhook_id_sandbox','') ?? '');
    return $wh!=='' && !empty($event['id']);
  }

  private function brand(): string {
    try {
      $st=$this->pdo()->query("SELECT value FROM app_settings WHERE `k`='site_name'"); $v=$st->fetchColumn();
      return $v ? (string)$v : 'Geo Logihub';
    } catch(Throwable $_) { return 'Geo Logihub'; }
  }

  private function pdo(): PDO {
    static $db; if ($db instanceof PDO) return $db;
    $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
    $db=new PDO($dsn, DB_USER, DB_PASS, [
      PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
    ]); return $db;
  }
  private function getCfg(PDO $pdo, string $k, ?string $def=null): ?string {
    $st=$pdo->prepare("SELECT value FROM config_global WHERE `key`=?"); $st->execute([$k]);
    $v=$st->fetchColumn(); return $v!==false ? (string)$v : $def;
  }
}
