<?php
// /lib/paypal.php
declare(strict_types=1);

final class PayPal {
  private string $env;
  private string $clientId;
  private string $secret;
  private string $currency;
  private ?string $webhookId;
  private ?string $accessToken = null;
  private int $tokenExpTs = 0;
  private ?\PDO $db = null;

  public function __construct(
    ?string $env=null, ?string $clientId=null, ?string $secret=null,
    ?string $currency=null, ?string $webhookId=null
  ){
    if ($env && $clientId && $secret) {
      $this->env = ($env==='live')?'live':'sandbox';
      $this->clientId=$clientId; $this->secret=$secret;
      $this->currency=strtoupper($currency?:'USD'); $this->webhookId=$webhookId;
      return;
    }
    [$env2,$cur,$cid_sb,$sec_sb,$cid_lv,$sec_lv,$wh_sb,$wh_lv] = [
      $this->cfg('paypal_env','sandbox'), strtoupper($this->cfg('paypal_currency','USD')??'USD'),
      $this->cfg('paypal_client_id_sandbox',''), $this->cfg('paypal_client_secret_sandbox',''),
      $this->cfg('paypal_client_id_live',''),   $this->cfg('paypal_client_secret_live',''),
      $this->cfg('paypal_webhook_id_sandbox',''), $this->cfg('paypal_webhook_id_live',''),
    ];
    $this->env = ($env2==='live')?'live':'sandbox';
    $this->currency = $cur ?: 'USD';
    if ($this->env==='live'){ $this->clientId=(string)$cid_lv; $this->secret=(string)$sec_lv; $this->webhookId=$wh_lv?:null; }
    else { $this->clientId=(string)$cid_sb; $this->secret=(string)$sec_sb; $this->webhookId=$wh_sb?:null; }
  }

  public function createSubscription(string $planId, string $returnUrl, string $cancelUrl, string $custom=''): array {
    $this->ensureToken();
    $p=['plan_id'=>$planId,'application_context'=>[
      'brand_name'=>$this->cfg('site_name','Geo Logihub')??'Geo Logihub',
      'user_action'=>'SUBSCRIBE_NOW','return_url'=>$returnUrl,'cancel_url'=>$cancelUrl]];
    if($custom!=='') $p['custom_id']=$custom;
    return $this->request('POST','/v1/billing/subscriptions',$p);
  }
  public function getSubscription(string $sid): array {
    $this->ensureToken(); return $this->request('GET','/v1/billing/subscriptions/'.rawurlencode($sid));
  }
  public function cancelSubscription(string $sid,string $reason=''): bool {
    $this->ensureToken(); $this->request('POST','/v1/billing/subscriptions/'.rawurlencode($sid).'/cancel',$reason?['reason'=>$reason]:new \stdClass()); return true;
  }
  public function verifyWebhook(array $headers,array $event): bool {
    $this->ensureToken(); $h=[]; foreach($headers as $k=>$v){$h[strtolower($k)]=$v;}
    $wid=$this->webhookId?:($this->env==='live'?$this->cfg('paypal_webhook_id_live',''):$this->cfg('paypal_webhook_id_sandbox','')); if($wid==='') return false;
    $p=['auth_algo'=>$h['paypal-auth-algo']??'','cert_url'=>$h['paypal-cert-url']??'','transmission_id'=>$h['paypal-transmission-id']??'','transmission_sig'=>$h['paypal-transmission-sig']??'','transmission_time'=>$h['paypal-transmission-time']??'','webhook_id'=>$wid,'webhook_event'=>$event];
    $r=$this->request('POST','/v1/notifications/verify-webhook-signature',$p);
    return strtoupper((string)($r['verification_status']??''))==='SUCCESS';
  }

  private function base(): string { return $this->env==='live'?'https://api-m.paypal.com':'https://api-m.sandbox.paypal.com'; }
  private function ensureToken(): void {
    if($this->accessToken && time() < $this->tokenExpTs-30) return;
    $ch=curl_init($this->base().'/v1/oauth2/token');
    curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>'grant_type=client_credentials',CURLOPT_HTTPAUTH=>CURLAUTH_BASIC,CURLOPT_USERPWD=>$this->clientId.':'.$this->secret,CURLOPT_RETURNTRANSFER=>true]);
    $raw=curl_exec($ch); if($raw===false) throw new \RuntimeException('OAuth curl: '.curl_error($ch));
    $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
    if($code<200||$code>=300) throw new \RuntimeException('OAuth HTTP '.$code.' '.$raw);
    $j=json_decode($raw,true)?:[]; $this->accessToken=(string)($j['access_token']??''); $this->tokenExpTs=time()+max(60,(int)($j['expires_in']??300));
    if($this->accessToken==='') throw new \RuntimeException('OAuth no token');
  }
  private function request(string $method,string $path,$body=null,array $headers=[]): array {
    $ch=curl_init($this->base().$path);
    $hdr=array_merge(['Content-Type: application/json','Authorization: Bearer '.$this->accessToken], array_map(fn($k,$v)=>$k.': '.$v,array_keys($headers),$headers));
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$hdr]);
    if($method!=='GET' && $body!==null){ curl_setopt($ch,CURLOPT_POSTFIELDS,is_string($body)?$body:json_encode($body,JSON_UNESCAPED_SLASHES)); }
    $raw=curl_exec($ch); if($raw===false) throw new \RuntimeException('HTTP curl: '.curl_error($ch));
    $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
    if($code<200||$code>=300){ throw new \RuntimeException('HTTP '.$code.' '.$raw); }
    $j=json_decode($raw,true); return is_array($j)?$j:[];
  }

  private function cfg(string $k,?string $def=null): ?string {
    try{ $pdo=$this->db(); $st=$pdo->prepare("SELECT `value` FROM config_global WHERE `key`=?"); $st->execute([$k]); $v=$st->fetchColumn(); if($v!==false) return (string)$v;
         $st=$pdo->prepare("SELECT `v` FROM app_settings WHERE `k`=?"); $st->execute([$k]); $v=$st->fetchColumn(); if($v!==false) return (string)$v; }catch(\Throwable $e){}
    return $def;
  }
  private function db(): \PDO {
    if($this->db instanceof \PDO) return $this->db;
    require_once __DIR__.'/../config/db.php';
    $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4',DB_HOST,DB_NAME);
    return $this->db=new \PDO($dsn,DB_USER,DB_PASS,[\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION,\PDO::ATTR_DEFAULT_FETCH_MODE=>\PDO::FETCH_ASSOC]);
  }
}
