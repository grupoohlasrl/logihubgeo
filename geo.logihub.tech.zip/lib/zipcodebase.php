<?php
declare(strict_types=1);

/**
 * /lib/zipcodebase.php
 * Cliente Zipcodebase con validaciones, reintentos, rate-limit y logging opcional.
 * Requiere: tabla config_global (provider='zipcodebase').
 */

if (!function_exists('zipcodebase_config')) {
    function zipcodebase_config(PDO $pdo): array {
        $st = $pdo->prepare("
            SELECT api_base_url, api_key, request_timeout_ms, rate_limit_ms
            FROM config_global
            WHERE provider='zipcodebase' AND active=1
            LIMIT 1
        ");
        $st->execute();
        $cfg = $st->fetch(PDO::FETCH_ASSOC) ?: [];
        $base = trim((string)($cfg['api_base_url'] ?? ''));
        $key  = trim((string)($cfg['api_key'] ?? ''));
        $to   = (int)($cfg['request_timeout_ms'] ?? 6000);
        $rl   = (int)($cfg['rate_limit_ms'] ?? 250);

        if ($base === '' || stripos($base, 'http') !== 0) {
            throw new RuntimeException('Zipcodebase: api_base_url inválida');
        }
        if ($key === '' || strlen($key) > 128) {
            throw new RuntimeException('Zipcodebase: API key inválida o ausente');
        }
        if ($to < 1000) $to = 1000;
        if ($rl < 0)    $rl = 0;

        return [
            'api_base_url'       => rtrim($base, '/'),
            'api_key'            => $key,
            'request_timeout_ms' => $to,
            'rate_limit_ms'      => $rl,
        ];
    }
}

if (!function_exists('zipcodebase_has_table')) {
    function zipcodebase_has_table(PDO $pdo, string $table): bool {
        try {
            $db = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
            $st = $pdo->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=? AND TABLE_NAME=?");
            $st->execute([$db, $table]);
            return (bool)$st->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('zipcodebase_log')) {
    function zipcodebase_log(PDO $pdo, string $endpoint, int $http_status, int $elapsed_ms, ?int $quota_remaining = null): void {
        if (!zipcodebase_has_table($pdo, 'zipcode_api_logs')) return;
        try {
            $st = $pdo->prepare("
                INSERT INTO zipcode_api_logs (endpoint, http_status, elapsed_ms, quota_remaining, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $st->execute([$endpoint, $http_status, $elapsed_ms, $quota_remaining]);
        } catch (Throwable $e) {
            // silenciar
        }
    }
}

if (!function_exists('zipcodebase_http_get')) {
    function zipcodebase_http_get(string $url, int $timeout_ms): array {
        $headers = [];
        $capture = static function($ch, string $line) use (&$headers): int {
            $trim = trim($line);
            if ($trim !== '' && strpos($trim, ':') !== false) {
                [$k, $v] = explode(':', $trim, 2);
                $headers[strtolower(trim($k))] = trim($v);
            }
            return strlen($line);
        };
        $ua = 'LogiHubZipcode/1.0 (+https://geo.logihub.tech)';

        $t0 = microtime(true);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT_MS     => $timeout_ms,
            CURLOPT_CONNECTTIMEOUT_MS => min(1000, $timeout_ms),
            CURLOPT_FAILONERROR    => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HEADERFUNCTION => $capture,
            CURLOPT_HTTPHEADER     => [
                'Accept: application/json',
                'User-Agent: '.$ua,
                'Cache-Control: no-cache'
            ],
        ]);
        $body = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        $elapsed_ms = (int)round((microtime(true) - $t0) * 1000);

        return [
            'code'    => $code,
            'body'    => $body,
            'err'     => $err,
            'headers' => $headers,
            'elapsed_ms' => $elapsed_ms,
        ];
    }
}

/**
 * Llama endpoint Zipcodebase con validaciones, rate-limit y reintentos.
 * $opts:
 *   - retries:int  (default 2)
 *   - backoff_ms:int (default rate_limit_ms*2, min 200)
 *   - cache_ttl:int segundos (opcional, si hay Redis)
 */
if (!function_exists('zipcodebase_call')) {
    function zipcodebase_call(PDO $pdo, string $endpoint, array $params, array $opts = []): array {
        static $whitelist = ['search','code/city','code/state','radius','distance','match'];
        if (!in_array($endpoint, $whitelist, true)) {
            return ['ok'=>false, 'err'=>'endpoint no permitido', 'status'=>0];
        }

        $cfg = zipcodebase_config($pdo);

        // Sanea params y añade apikey
        $params = array_filter($params, static fn($v) => $v !== null && $v !== '');
        $params['apikey'] = $cfg['api_key'];

        // Construye URL
        $qs  = http_build_query($params, '', '&', PHP_QUERY_RFC3986);
        $url = $cfg['api_base_url'].'/'.$endpoint.'?'.$qs;

        // Rate-limit básico
        if ($cfg['rate_limit_ms'] > 0) {
            usleep($cfg['rate_limit_ms'] * 1000);
        }

        // Cache opcional con Redis
        $cache_ttl = (int)($opts['cache_ttl'] ?? 0);
        $cache_key = null; $redis = null;
        if ($cache_ttl > 0 && class_exists('Redis')) {
            try {
                $redis = new Redis();
                if (getenv('REDIS_URL')) {
                    $u = parse_url(getenv('REDIS_URL'));
                    $host=$u['host']??'127.0.0.1'; $port=(int)($u['port']??6379); $pass=$u['pass']??null; $dbi=isset($u['path'])?(int)trim($u['path'],'/'):0;
                    $redis->connect($host,$port,1.0);
                    if($pass) $redis->auth($pass);
                    if($dbi)  $redis->select($dbi);
                } else {
                    $host=getenv('REDIS_HOST')?:'127.0.0.1'; $port=(int)(getenv('REDIS_PORT')?:6379); $pass=getenv('REDIS_PASSWORD')?:null;
                    $redis->connect($host,$port,1.0);
                    if($pass) $redis->auth($pass);
                    if($d=getenv('REDIS_DB')) $redis->select((int)$d);
                }
                $cache_key = 'zcbase:'.substr(hash('sha256', $endpoint.'|'.$qs), 0, 48);
                $hit = $redis->get($cache_key);
                if ($hit) {
                    $json = json_decode($hit, true);
                    if (is_array($json)) {
                        return ['ok'=>true, 'status'=>200, 'data'=>$json, 'cached'=>true];
                    }
                }
            } catch (Throwable $e) {
                $redis = null;
            }
        }

        // Reintentos
        $retries = max(0, (int)($opts['retries'] ?? 2));
        $backoff = (int)($opts['backoff_ms'] ?? max(200, min(5000, $cfg['rate_limit_ms'] * 2 ?: 500)));
        $attempt = 0;

        do {
            $attempt++;

            $res = zipcodebase_http_get($url, (int)$cfg['request_timeout_ms']);
            $code = (int)$res['code'];
            $body = $res['body'];
            $err  = $res['err'];
            $headers = $res['headers'];
            $elapsed = $res['elapsed_ms'];

            $quota_remaining = null;
            foreach (['x-ratelimit-remaining','x-rate-limit-remaining'] as $h) {
                if (isset($headers[$h])) { $quota_remaining = (int)$headers[$h]; break; }
            }

            // Parseo JSON
            $json = null;
            if ($body !== false && $body !== null && $body !== '') {
                $tmp = json_decode($body, true);
                if (is_array($tmp)) $json = $tmp;
            }

            zipcodebase_log($pdo, $endpoint, $code ?: 0, $elapsed, $quota_remaining);

            // Éxito
            if ($code >= 200 && $code < 300 && is_array($json)) {
                if ($redis && $cache_key && $cache_ttl > 0) {
                    try { $redis->setex($cache_key, $cache_ttl, json_encode($json, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); } catch (Throwable $e) {}
                }
                return ['ok'=>true, 'status'=>$code, 'data'=>$json, 'headers'=>$headers];
            }

            // Error transitorio: 429/5xx o fallo CURL
            $transient = ($code === 429 || $code >= 500 || ($code === 0 && $err));
            if (!$transient || $attempt > $retries) {
                $msg = $json['message'] ?? $json['error'] ?? ($err ?: 'http');
                return ['ok'=>false, 'status'=>$code, 'err'=>$msg, 'headers'=>$headers];
            }

            // Backoff
            usleep($backoff * 1000);
            // aumenta backoff lineal
            $backoff = min($backoff + 250, 5000);
        } while (true);
    }
}

/* --------- Normalizadores útiles --------- */

if (!function_exists('zipcodebase_normalize_code_city')) {
    function zipcodebase_normalize_code_city(array $payload): array {
        // Zipcodebase puede devolver bajo "results" o plano
        $rows = $payload['results'] ?? $payload;
        if (!is_array($rows)) return [];
        $out = [];
        foreach ($rows as $r) {
            if (!is_array($r)) continue;
            $out[] = [
                'country_code' => strtoupper((string)($r['country_code'] ?? '')),
                'state_name'   => $r['state'] ?? ($r['state_name'] ?? null),
                'state_code'   => $r['state_code'] ?? null,
                'city'         => $r['city'] ?? null,
                'postal_code'  => (string)($r['postal_code'] ?? $r['code'] ?? ''),
                'latitude'     => isset($r['latitude']) ? (float)$r['latitude'] : (isset($r['lat'])?(float)$r['lat']:null),
                'longitude'    => isset($r['longitude'])? (float)$r['longitude']: (isset($r['lng'])?(float)$r['lng']:null),
            ];
        }
        return $out;
    }
}

if (!function_exists('zipcodebase_normalize_search')) {
    function zipcodebase_normalize_search(array $payload): array {
        // "results" suele ser map code => [ ... ]
        $res = $payload['results'] ?? $payload;
        $out = [];
        if (is_array($res)) {
            foreach ($res as $code => $list) {
                if (is_array($list)) {
                    foreach ($list as $r) {
                        $out[] = [
                            'query_code'   => (string)$code,
                            'country_code' => strtoupper((string)($r['country_code'] ?? '')),
                            'state_name'   => $r['state'] ?? ($r['state_name'] ?? null),
                            'state_code'   => $r['state_code'] ?? null,
                            'city'         => $r['city'] ?? null,
                            'postal_code'  => (string)($r['postal_code'] ?? $r['code'] ?? ''),
                            'latitude'     => isset($r['latitude']) ? (float)$r['latitude'] : (isset($r['lat'])?(float)$r['lat']:null),
                            'longitude'    => isset($r['longitude'])? (float)$r['longitude']: (isset($r['lng'])?(float)$r['lng']:null),
                        ];
                    }
                }
            }
        }
        return $out;
    }
}

/* --------- Wrappers convenientes --------- */

if (!function_exists('zipcodebase_code_city')) {
    /**
     * city -> códigos para país ISO2
     */
    function zipcodebase_code_city(PDO $pdo, string $city, string $country_iso2, array $opts = []): array {
        $city = trim($city);
        $country_iso2 = strtoupper(trim($country_iso2));
        if ($city === '' || strlen($country_iso2) !== 2) {
            return ['ok'=>false, 'err'=>'parámetros inválidos', 'status'=>0];
        }
        $r = zipcodebase_call($pdo, 'code/city', [
            'city'    => $city,
            'country' => strtolower($country_iso2),
        ], $opts);
        if (!$r['ok']) return $r;
        return ['ok'=>true, 'status'=>$r['status'], 'data'=>zipcodebase_normalize_code_city($r['data'])];
    }
}

if (!function_exists('zipcodebase_search_codes')) {
    /**
     * codes -> location. $codes puede ser array|string (separado por coma).
     */
    function zipcodebase_search_codes(PDO $pdo, $codes, ?string $country_iso2 = null, array $opts = []): array {
        if (is_array($codes)) {
            $codes = implode(',', array_filter(array_map('trim', $codes), fn($v)=>$v!==''));
        } else {
            $codes = trim((string)$codes);
        }
        if ($codes === '') {
            return ['ok'=>false, 'err'=>'codes vacío', 'status'=>0];
        }
        $params = ['codes' => $codes];
        if ($country_iso2 && strlen($country_iso2) === 2) {
            $params['country'] = strtolower($country_iso2);
        }
        $r = zipcodebase_call($pdo, 'search', $params, $opts);
        if (!$r['ok']) return $r;
        return ['ok'=>true, 'status'=>$r['status'], 'data'=>zipcodebase_normalize_search($r['data'])];
    }
}

if (!function_exists('zipcodebase_radius')) {
    /**
     * ZIPs dentro de radio (km). code base y country requerido por API.
     */
    function zipcodebase_radius(PDO $pdo, string $code, int $radius_km, string $country_iso2, array $opts=[]): array {
        $code = trim($code);
        $radius_km = max(1, $radius_km);
        $country_iso2 = strtoupper(trim($country_iso2));
        if ($code === '' || strlen($country_iso2)!==2) return ['ok'=>false,'err'=>'parámetros inválidos','status'=>0];
        return zipcodebase_call($pdo, 'radius', [
            'code'    => $code,
            'radius'  => $radius_km,
            'country' => strtolower($country_iso2),
        ], $opts);
    }
}

if (!function_exists('zipcodebase_distance')) {
    /**
     * Distancia entre un ZIP y comparación con varios ZIPs.
     * $compare puede ser array|string coma-separada.
     */
    function zipcodebase_distance(PDO $pdo, string $code, $compare, string $country_iso2, array $opts=[]): array {
        $code = trim($code);
        if (is_array($compare)) {
            $compare = implode(',', array_filter(array_map('trim', $compare), fn($v)=>$v!==''));
        } else {
            $compare = trim((string)$compare);
        }
        $country_iso2 = strtoupper(trim($country_iso2));
        if ($code === '' || $compare === '' || strlen($country_iso2)!==2) return ['ok'=>false,'err'=>'parámetros inválidos','status'=>0];
        return zipcodebase_call($pdo, 'distance', [
            'code'    => $code,
            'compare' => $compare,
            'country' => strtolower($country_iso2),
        ], $opts);
    }
}
