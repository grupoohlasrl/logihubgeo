<?php
// Configuración de conexión
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'geologihub');
define('DB_USER', 'geologihub');
define('DB_PASS', 'zdbtDLHTBcaEpfnE');
define('DB_CHARSET', 'utf8mb4');

try {
    $pdo = new PDO(
        "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            // Habilita emulación para permitir placeholders repetidos (:iso, :iso)
            PDO::ATTR_EMULATE_PREPARES   => true,
        ]
    );
} catch (PDOException $e) {
    die("Error de conexión a la base de datos: ".$e->getMessage());
}
