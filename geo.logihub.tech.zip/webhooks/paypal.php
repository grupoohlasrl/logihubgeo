<?php
declare(strict_types=1);
// Endpoint para webhooks. Configurar URL en PayPal y poner el "webhook_id" en config_global.

require_once __DIR__.'/../lib/paypal.php';

// Lee payload crudo
$body = file_get_contents('php://input') ?: '{}';
$headers = array_change_key_case(getallheaders() ?: [], CASE_UPPER);

$webhook_id = (string)cfg_get('paypal_webhook_id','');
if ($webhook_id === '') { http_response_code(200); exit('OK'); } // sin verificación

try {
  // Verificación de firma
  $verify = paypal_api('POST','/v1/notifications/verify-webhook-signature', [
    'auth_algo'         => $headers['PAYPAL-AUTH-ALGO'] ?? '',
    'cert_url'          => $headers['PAYPAL-CERT-URL'] ?? '',
    'transmission_id'   => $headers['PAYPAL-TRANSMISSION-ID'] ?? '',
    'transmission_sig'  => $headers['PAYPAL-TRANSMISSION-SIG'] ?? '',
    'transmission_time' => $headers['PAYPAL-TRANSMISSION-TIME'] ?? '',
    'webhook_id'        => $webhook_id,
    'webhook_event'     => json_decode($body,true),
  ]);
  if (strtoupper((string)($verify['verification_status'] ?? '')) !== 'SUCCESS') {
    http_response_code(400); exit('Invalid');
  }

  $event = json_decode($body,true);
  $type  = (string)($event['event_type'] ?? '');
  $res   = $event['resource'] ?? [];

  // Manejo mínimo: COMPLETED actualiza pago si existe
  if ($type === 'PAYMENT.CAPTURE.COMPLETED') {
    $order_id = (string)($res['supplementary_data']['related_ids']['order_id'] ?? '');
    $amount   = (string)($res['amount']['value'] ?? '0.00');
    $currency = (string)($res['amount']['currency_code'] ?? 'USD');

    if ($order_id) {
      $db = pdo();
      $db->prepare('UPDATE payments SET status="COMPLETED", amount_usd=?, currency=?, details=? WHERE provider="paypal" AND provider_order_id=?')
         ->execute([$amount,$currency,$body,$order_id]);
    }
  }

  http_response_code(200);
  echo 'OK';
} catch (\Throwable $e) {
  http_response_code(200); // No reintentos infinitos
  echo 'OK';
}
