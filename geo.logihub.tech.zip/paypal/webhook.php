<?php
declare(strict_types=1);
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/lib/paypal.php';
header('Content-Type: application/json');

function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]); return $db;
}

$raw=file_get_contents('php://input'); $evt=json_decode($raw,true) ?: [];
$hdr=array_change_key_case(function_exists('getallheaders')?getallheaders():[], CASE_LOWER);

try{
  $pp=new PayPal();
  if(!$pp->verifyWebhook($hdr,$evt)){ http_response_code(400); echo json_encode(['ok'=>false]); exit; }

  $type=$evt['event_type'] ?? '';
  $sid=$evt['resource']['id'] ?? ($evt['resource']['billing_agreement_id'] ?? '');

  if($type==='BILLING.SUBSCRIPTION.ACTIVATED'){
    $up=pdo()->prepare("UPDATE payments SET status='completed', details=JSON_SET(COALESCE(details,'{}'),'$.evt','ACTIVATED') WHERE provider='paypal' AND provider_subscription_id=?");
    $up->execute([$sid]);
  } elseif($type==='BILLING.SUBSCRIPTION.CANCELLED'){
    $up=pdo()->prepare("UPDATE payments SET status='canceled', details=JSON_SET(COALESCE(details,'{}'),'$.evt','CANCELLED') WHERE provider='paypal' AND provider_subscription_id=?");
    $up->execute([$sid]);
    $su=pdo()->prepare("UPDATE subscriptions SET status='canceled' WHERE usuario_id IN (SELECT usuario_id FROM payments WHERE provider='paypal' AND provider_subscription_id=?)");
    $su->execute([$sid]);
  } elseif($type==='PAYMENT.SALE.COMPLETED'){
    $amount=$evt['resource']['amount']['total'] ?? '0.00';
    $cur=$evt['resource']['amount']['currency'] ?? 'USD';
    $up=pdo()->prepare("UPDATE payments SET amount_usd=?, currency=? WHERE provider='paypal' AND provider_subscription_id=? AND amount_usd=0");
    $up->execute([$amount,$cur,$sid]);
  }

  echo json_encode(['ok'=>true]);
}catch(Throwable $e){
  error_log('PP_WEBHOOK_ERR '.$e->getMessage());
  http_response_code(500); echo json_encode(['ok'=>false]);
}
