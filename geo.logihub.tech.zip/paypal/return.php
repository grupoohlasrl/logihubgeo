<?php
declare(strict_types=1);
session_start();
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/lib/paypal.php';

function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]); return $db;
}

$subId = $_GET['subscription_id'] ?? $_GET['token'] ?? '';
if (!$subId) { header('Location: /users/planes/?e=missing'); exit; }

try{
  $pp = new PayPal();
  $info = $pp->getSubscription($subId);

  $status = strtoupper($info['status'] ?? '');
  $custom = (string)($info['custom_id'] ?? '');
  parse_str(str_replace(['|',':'], ['&','='], $custom), $kv);
  $uid = (int)($kv['usr'] ?? ($_SESSION['uid'] ?? 0));
  $plan_id = (int)($kv['plan'] ?? 0);

  $u = pdo()->prepare("UPDATE payments SET status=?, details=JSON_SET(COALESCE(details,'{}'),'$.pp_status',?) WHERE provider='paypal' AND provider_subscription_id=?");
  $u->execute([strtolower($status), $status, $subId]);

  if ($status==='ACTIVE' && $uid && $plan_id){
    $next = $info['billing_info']['next_billing_time'] ?? null;
    $end = $next ? (new DateTimeImmutable($next))->format('Y-m-d H:i:s') : (new DateTimeImmutable('+1 month'))->format('Y-m-d H:i:s');

    $ex=pdo()->prepare("SELECT id FROM subscriptions WHERE usuario_id=? ORDER BY id DESC LIMIT 1");
    $ex->execute([$uid]); $cur=$ex->fetch();
    if($cur){
      $q=pdo()->prepare("UPDATE subscriptions SET plan_id=?, status='active', current_period_end=? WHERE id=?");
      $q->execute([$plan_id,$end,$cur['id']]);
    }else{
      $q=pdo()->prepare("INSERT INTO subscriptions(usuario_id,plan_id,status,current_period_end) VALUES(?,?,'active',?)");
      $q->execute([$uid,$plan_id,$end]);
    }
  }
  header('Location: /users/planes/?ok=1');
}catch(Throwable $e){
  error_log('PP_RETURN_ERR '.$e->getMessage());
  header('Location: /users/planes/?e=pp');
}
