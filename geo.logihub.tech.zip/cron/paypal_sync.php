<?php
// /cron/paypal_sync.php?key=XXXXX
declare(strict_types=1);
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../paypal/lib/paypal.php';

function pdo(): PDO {
  static $db; if ($db instanceof PDO) return $db;
  $dsn=sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
  $db=new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]); return $db;
}
function getCfg(string $k, ?string $def=null): ?string {
  $st=pdo()->prepare("SELECT value FROM config_global WHERE `key`=?"); $st->execute([$k]);
  $v=$st->fetchColumn(); return $v!==false ? (string)$v : $def;
}

$secret = getCfg('cron_secret','');
if ($secret==='') {
  $secret = bin2hex(random_bytes(8));
  $st=pdo()->prepare("INSERT INTO config_global(`key`,`value`) VALUES('cron_secret',?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)"); $st->execute([$secret]);
}
if (($_GET['key'] ?? '') !== $secret) { http_response_code(403); echo "forbidden"; exit; }

try{
  $pp=new PayPal();
  // sincroniza últimas 100 suscripciones PayPal en estado no cancelado
  $rows = pdo()->query("SELECT provider_subscription_id, usuario_id, plan_id FROM payments WHERE provider='paypal' AND status IN ('pending','approved','completed','active') ORDER BY id DESC LIMIT 100")->fetchAll();
  foreach($rows as $r){
    $sid=$r['provider_subscription_id']; if(!$sid) continue;
    try{
      $info=$pp->getSubscription($sid);
      $st=strtolower($info['status'] ?? '');
      $up=pdo()->prepare("UPDATE payments SET status=? WHERE provider='paypal' AND provider_subscription_id=?");
      $up->execute([$st,$sid]);

      if($st==='active'){
        $next=$info['billing_info']['next_billing_time'] ?? null;
        $end = $next ? (new DateTimeImmutable($next))->format('Y-m-d H:i:s') : (new DateTimeImmutable('+1 month'))->format('Y-m-d H:i:s');
        $s=pdo()->prepare("UPDATE subscriptions SET status='active', plan_id=?, current_period_end=? WHERE usuario_id=?");
        $s->execute([(int)$r['plan_id'],$end,(int)$r['usuario_id']]);
      }
      if(in_array($st,['cancelled','suspended'],true)){
        $s=pdo()->prepare("UPDATE subscriptions SET status='canceled' WHERE usuario_id=?");
        $s->execute([(int)$r['usuario_id']]);
      }
    }catch(Throwable $e){ /* continúa */ }
  }
  echo "ok";
}catch(Throwable $e){
  http_response_code(500); echo "err";
}
