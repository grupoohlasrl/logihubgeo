<?php
declare(strict_types=1);

/* ---------- headers ---------- */
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('X-Robots-Tag: noindex');

/* ---------- localizar raíz ---------- */
function find_root(string $start, int $max_up=6): string {
  $d = rtrim($start, DIRECTORY_SEPARATOR);
  for ($i=0; $i<=$max_up; $i++) {
    if (is_file($d.'/config/db.php')) return $d;
    $d = dirname($d);
  }
  return rtrim($start, DIRECTORY_SEPARATOR);
}
$ROOT = find_root(__DIR__, 6);

/* ---------- cargar DB y lib ---------- */
$dbPath  = $ROOT.'/config/db.php';
if (!is_file($dbPath)) { http_response_code(500); exit("Missing config: $dbPath\n"); }
require_once $dbPath;

$libPath = $ROOT.'/lib/zipcodebase.php';
if (!is_file($libPath)) {
  foreach ([dirname(__DIR__,2).'/lib/zipcodebase.php', dirname(__DIR__).'/lib/zipcodebase.php', $_SERVER['DOCUMENT_ROOT'].'/lib/zipcodebase.php'] as $p) {
    if (is_file($p)) { $libPath = $p; break; }
  }
}
if (!is_file($libPath)) { http_response_code(500); exit("Missing lib: $libPath\n"); }
require_once $libPath;

/* ---------- Redis ---------- */
function redisConnect(): ?Redis {
  if (!class_exists('Redis')) return null;
  $r = new Redis();
  try {
    $url = getenv('REDIS_URL');
    if ($url) { $u=parse_url($url);
      $r->connect($u['host']??'127.0.0.1',(int)($u['port']??6379),1.5);
      if(!empty($u['pass'])) $r->auth($u['pass']);
      if(!empty($u['path'])) $r->select((int)trim($u['path'],'/'));
    } else {
      $r->connect(getenv('REDIS_HOST')?:'127.0.0.1',(int)(getenv('REDIS_PORT')?:6379),1.5);
      if($p=getenv('REDIS_PASSWORD')) $r->auth($p);
      if($d=getenv('REDIS_DB')) $r->select((int)$d);
    }
    return $r;
  } catch(Throwable $e){ return null; }
}
function acquireLock(PDO $pdo, ?Redis $redis, string $key, int $ttl_ms): bool {
  if ($redis) return (bool)$redis->set($key, '1', ['NX','PX'=>$ttl_ms]);
  $st=$pdo->prepare('SELECT GET_LOCK(:k,0)'); $st->execute([':k'=>$key]); return (int)$st->fetchColumn()===1;
}
function releaseLock(PDO $pdo, ?Redis $redis, string $key): void {
  if ($redis) { try{$redis->del($key);}catch(Throwable $e){} return; }
  try { $pdo->query("DO RELEASE_LOCK(".$pdo->quote($key).")"); } catch(Throwable $e) {}
}

/* ---------- util ---------- */
function detectZG(PDO $pdo): string {
  try {
    $db=(string)$pdo->query('SELECT DATABASE()')->fetchColumn();
    $st=$pdo->prepare("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
      WHERE TABLE_SCHEMA=? AND TABLE_NAME IN ('Zonas_global','zonas_global') LIMIT 1");
    $st->execute([$db]); return $st->fetchColumn() ?: 'Zonas_global';
  } catch(Throwable $e){ return 'Zonas_global'; }
}
function timeExceeded(float $ts0,int $max_ms): bool { return (microtime(true)-$ts0)*1000 >= $max_ms; }

/* ---------- params + auth ---------- */
$country = strtoupper(trim($_GET['country'] ?? '')); // recomendado
$batch   = max(1, min(100, (int)($_GET['batch'] ?? 25)));
$max_ms  = max(1000, min(55000, (int)($_GET['max_ms'] ?? 25000)));
$auto    = (int)($_GET['auto_enqueue'] ?? 0);

$row = $pdo->query("SELECT cron_token FROM config_global WHERE provider='zipcodebase' AND active=1 LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: [];
$cronToken = (string)($row['cron_token'] ?? '');
if ($cronToken === '' || !hash_equals($cronToken, (string)($_GET['token'] ?? ''))) { http_response_code(403); exit("Forbidden\n"); }

/* ---------- lock ---------- */
$redis = redisConnect();
$lockKey = 'cron:zipcode:lock';
if (!acquireLock($pdo,$redis,$lockKey,$max_ms+3000)) exit("locked\n");

/* ---------- main ---------- */
$ts0 = microtime(true);
$ZG  = detectZG($pdo);

/* selección (ambos tipos) */
$where  = "WHERE status='pending'".($country!=='' ? " AND country_iso2 = :iso" : "");
$selSql = "SELECT id,country_iso2,city_name,zip_code,job_type FROM zipcode_jobs $where ORDER BY id LIMIT :lim";
$sel = $pdo->prepare($selSql);
if ($country!=='') $sel->bindValue(':iso',$country,PDO::PARAM_STR);
$sel->bindValue(':lim',(int)$batch,PDO::PARAM_INT);
$sel->execute();
$jobs=$sel->fetchAll(PDO::FETCH_ASSOC);

/* auto-enqueue si vacío y hay country (city_to_zip) */
if (!$jobs && $auto===1 && $country!=='') {
  $ins=$pdo->prepare("
    INSERT IGNORE INTO zipcode_jobs (country_iso2, city_name, job_type)
    SELECT ?, city, 'city_to_zip' FROM `$ZG`
    WHERE country_iso2=? AND (postal_code IS NULL OR postal_code='')
      AND city IS NOT NULL AND city<>''
    GROUP BY city
  ");
  $ins->execute([$country,$country]);
  $sel=$pdo->prepare($selSql);
  if ($country!=='') $sel->bindValue(':iso',$country,PDO::PARAM_STR);
  $sel->bindValue(':lim',(int)$batch,PDO::PARAM_INT);
  $sel->execute();
  $jobs=$sel->fetchAll(PDO::FETCH_ASSOC);
}

/* heartbeat siempre, incluso sin jobs */
$heartbeat = function(int $done,int $nf,int $err) use ($redis) {
  if ($redis) { try {
    $redis->setex('cron:zipcode:progress', 600, json_encode(['ts'=>date('c'),'done'=>$done,'not_found'=>$nf,'errors'=>$err]));
  } catch(Throwable $e){} }
};

if (!$jobs) { $heartbeat(0,0,0); releaseLock($pdo,$redis,$lockKey); exit("no-pending\n"); }

/* marca running */
$ids=array_map('intval',array_column($jobs,'id'));
$in=implode(',',array_fill(0,count($ids),'?'));
$pdo->prepare("UPDATE zipcode_jobs SET status='running', updated_at=NOW() WHERE id IN ($in)")->execute($ids);

/* statements */
$insCache=$pdo->prepare("
  INSERT IGNORE INTO zipcode_cache
  (country_iso2,state_name,state_code,city_name,zip,lat,lng,source_endpoint,source_response)
  VALUES (:c,:sn,:sc,:ci,:z,:lat,:lng,:src,:resp)
");
$selExist=$pdo->prepare("SELECT 1 FROM `$ZG` WHERE country_iso2=? AND city=? AND postal_code=? LIMIT 1");
$upsertZG=$pdo->prepare("
  INSERT INTO `$ZG`
  (country_iso2,country_name,region_name,region_code,province_name,province_code,city,postal_code,lat,lng)
  VALUES (:c,:cn,:rn,:rc,:pn,:pc,:ci,:z,:lat,:lng)
  ON DUPLICATE KEY UPDATE
    lat = IFNULL(VALUES(lat), lat),
    lng = IFNULL(VALUES(lng), lng)
");
$upZG_by_zip=$pdo->prepare("
  UPDATE `$ZG` SET lat=IFNULL(lat, ?), lng=IFNULL(lng, ?)
  WHERE country_iso2=? AND postal_code=? AND (lat IS NULL OR lng IS NULL)
");

/* loop */
$done=0; $nf=0; $err=0;
foreach($jobs as $j){
  if (timeExceeded($ts0,$max_ms)) break;

  $jid=(int)$j['id']; $iso=$j['country_iso2']; $type=$j['job_type']?:'city_to_zip';
  try{
    if($type==='code_to_location'){
      $zip=trim((string)$j['zip_code']); if($zip==='') throw new RuntimeException('zip vacío');
      $resp=zipcodebase_search_codes($pdo,$zip,$iso,['cache_ttl'=>3600]);
      if(!$resp['ok']) throw new RuntimeException($resp['err']??'api');
      $rows=$resp['data']??[];
      if(!$rows){ $pdo->prepare("UPDATE zipcode_jobs SET status='not_found', attempts=attempts+1, updated_at=NOW() WHERE id=?")->execute([$jid]); $nf++; continue; }
      foreach($rows as $r){
        $pc=(string)($r['postal_code']??$zip); if($pc==='') continue;
        $lat=$r['latitude']??null; $lng=$r['longitude']??null;
        $insCache->execute([
          ':c'=>strtoupper($r['country_code']??$iso), ':sn'=>$r['state_name']??null, ':sc'=>$r['state_code']??null,
          ':ci'=>$r['city']??null, ':z'=>$pc, ':lat'=>$lat, ':lng'=>$lng,
          ':src'=>'search', ':resp'=>json_encode($r,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)
        ]);
        if($lat!==null && $lng!==null){ $upZG_by_zip->execute([$lat,$lng,$iso,$pc]); }
      }
    }else{
      $city=(string)$j['city_name']; if($city==='') throw new RuntimeException('city vacío');
      $resp=zipcodebase_call($pdo,'code/city',['city'=>$city,'country'=>strtolower($iso)],['cache_ttl'=>3600]);
      if(!$resp['ok']) throw new RuntimeException($resp['err']??'api');
      $list=$resp['data']['results']??($resp['data']??[]);
      if(!$list){ $pdo->prepare("UPDATE zipcode_jobs SET status='not_found', attempts=attempts+1, updated_at=NOW() WHERE id=?")->execute([$jid]); $nf++; continue; }
      foreach($list as $row){
        if(!is_array($row)) continue;
        $z=(string)($row['postal_code']??$row['code']??''); if($z==='') continue;
        $ci=$row['city']??$city; $sn=$row['state']??($row['state_name']??null); $sc=$row['state_code']??null;
        $lat=isset($row['latitude'])?(float)$row['latitude']:(isset($row['lat'])?(float)$row['lat']:null);
        $lng=isset($row['longitude'])?(float)$row['longitude']:(isset($row['lng'])?(float)$row['lng']:null);
        $insCache->execute([':c'=>$iso,':sn'=>$sn,':sc'=>$sc,':ci'=>$ci,':z'=>$z,':lat'=>$lat,':lng'=>$lng,':src'=>'code/city',
          ':resp'=>json_encode($row,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
        $selExist->execute([$iso,$ci,$z]);
        $upsertZG->execute([':c'=>$iso,':cn'=>$iso,':rn'=>$sn,':rc'=>$sc,':pn'=>$sn,':pc'=>$sc,':ci'=>$ci,':z'=>$z,':lat'=>$lat,':lng'=>$lng]);
      }
    }
    $pdo->prepare("UPDATE zipcode_jobs SET status='done', completed_at=NOW(), updated_at=NOW() WHERE id=?")->execute([$jid]); $done++;
  }catch(Throwable $e){
    $pdo->prepare("UPDATE zipcode_jobs SET status='error', attempts=attempts+1, last_error=?, updated_at=NOW() WHERE id=?")
        ->execute([substr($e->getMessage(),0,250),$jid]); $err++;
  }
}

/* progreso */
$heartbeat($done,$nf,$err);

/* fin */
releaseLock($pdo,$redis,$lockKey);
echo "processed=$done not_found=$nf errors=$err\n";
