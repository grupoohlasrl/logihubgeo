<?php
declare(strict_types=1);
header('Content-Type: text/plain; charset=utf-8');
require_once __DIR__.'/../../config/db.php';
$tok=$_GET['token']??''; $dbTok=$pdo->query("SELECT cron_token FROM config_global WHERE provider='zipcodebase' AND active=1 LIMIT 1")->fetchColumn();
if(!$dbTok || !hash_equals($dbTok,$tok)){ http_response_code(403); exit("Forbidden\n"); }
$done=[];
if(class_exists('Redis')){
  try{$r=new Redis(); $r->connect(getenv('REDIS_HOST')?:'127.0.0.1',(int)(getenv('REDIS_PORT')?:6379),1.0);
    if($p=getenv('REDIS_PASSWORD'))$r->auth($p); if($d=getenv('REDIS_DB'))$r->select((int)$d);
    $r->del('cron:zipcode:lock'); $done[]='redis'; }catch(Throwable $e){}
}
try{$pdo->query("DO RELEASE_LOCK('cron:zipcode:lock')"); $done[]='mysql';}catch(Throwable $e){}
echo "unlock: ".implode(',',$done)."\n";
